// Vercel Serverless entry point — delegates all requests to the Express app
import app from '../server';
export default app;
