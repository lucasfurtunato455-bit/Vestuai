import React, { useState, useEffect, useRef } from 'react';
import { 
  ShoppingBag, 
  ChevronRight, 
  Sparkles, 
  Plus, 
  Minus, 
  Trash2, 
  User, 
  Package, 
  AlertTriangle, 
  Check, 
  Star, 
  MapPin, 
  ExternalLink,
  MessageCircle,
  X,
  Lock,
  ChevronLeft
} from 'lucide-react';
import { Store, Product, Review } from '../types';
import { TEMPLATES_LIST, FashionTemplate } from './StoreTemplates';

interface StorefrontViewProps {
  slug: string;
  onNavigateHome: () => void;
}

export function StorefrontView({ slug, onNavigateHome }: StorefrontViewProps) {
  const [store, setStore] = useState<Store | null>(null);
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Active profile selection: 'retail' | 'wholesale' | null
  const [profileType, setProfileType] = useState<string | null>(null);
  const [currentTemplate, setCurrentTemplate] = useState<FashionTemplate>(TEMPLATES_LIST[3]); // Clean minimal as default

  // Selected product detail view
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);

  // Search, category filters and sorting
  const [searchQuery, setSearchQuery] = useState('');
  const [activeCategory, setActiveCategory] = useState<string>('Todos');
  const [sortBy, setSortBy] = useState<string>('recent');

  // Shopping cart client-side
  const [cart, setCart] = useState<{ product: Product; quantity: number }[]>([]);
  const [isCartOpen, setIsCartOpen] = useState(false);

  // Checkout info
  const [customerName, setCustomerName] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [isCheckoutModalOpen, setIsCheckoutModalOpen] = useState(false);
  const [orderCompleted, setOrderCompleted] = useState(false);

  // Review popup form
  const [showReviewForm, setShowReviewForm] = useState(false);
  const [reviewName, setReviewName] = useState('');
  const [reviewRating, setReviewRating] = useState(5);
  const [reviewComment, setReviewComment] = useState('');
  const [reviewSuccess, setReviewSuccess] = useState(false);
  const [reviews, setReviews] = useState<Review[]>([]);

  // Gate Modal State — pre-initialised to TRUE to prevent flash
  // (will be corrected to false once store loads if gate is not enabled)
  const [showGate, setShowGate] = useState(true);
  const [gateSelection, setGateSelection] = useState<string | null>(null);
  const [gateSubmitting, setGateSubmitting] = useState(false);

  // Block ESC key while gate is shown
  useEffect(() => {
    const blockEsc = (e: KeyboardEvent) => {
      if (showGate && e.key === 'Escape') {
        e.preventDefault();
        e.stopPropagation();
      }
    };
    window.addEventListener('keydown', blockEsc, { capture: true });
    return () => window.removeEventListener('keydown', blockEsc, { capture: true });
  }, [showGate]);

  // Track initial storefront visit
  const trackedVisit = useRef(false);

  // 1. Load Store and Setup profile settings
  useEffect(() => {
    async function loadStore() {
      setLoading(true);
      setError(null);
      try {
        const res = await fetch(`/api/store/${slug}`);
        if (!res.ok) {
          const errData = await res.json();
          throw new Error(errData.error || 'Erro ao carregar a loja.');
        }
        const data = await res.json();
        const loadedStore = data.store as Store;
        setStore(loadedStore);

        // If gate not enabled, immediately remove the pre-show state
        if (!loadedStore.gateEnabled) {
          setShowGate(false);
        }

        // Map template styling
        const mappedTpl = TEMPLATES_LIST.find(t => t.id === loadedStore.templateId) || TEMPLATES_LIST[3];
        setCurrentTemplate(mappedTpl);

        // Gate evaluation
        const storageKey = `gate_${loadedStore.slug}`;
        let cached = null;
        try {
          const cachedRaw = localStorage.getItem(storageKey) || sessionStorage.getItem(storageKey);
          if (cachedRaw) {
            const parsed = JSON.parse(cachedRaw);
            if (!parsed.expiresAt || parsed.expiresAt > Date.now()) {
              cached = parsed.type;
            }
          }
        } catch (_) {}

        if (loadedStore.gateEnabled && !cached) {
          setShowGate(true); // already true from initial state — no flash
        } else {
          setShowGate(false); // gate not enabled or already have session
          const activeProf = cached || 'retail';
          setProfileType(activeProf);
          fetchProducts(activeProf, loadedStore.slug);
        }

        // Fetch approved reviews list
        fetchReviews(loadedStore.slug);

      } catch (err: any) {
        setError(err.message || 'Esta vitrine não está disponível neste momento.');
      } finally {
        setLoading(false);
      }
    }

    loadStore();
  }, [slug]);

  // Log visitor visit metric
  useEffect(() => {
    if (store && !trackedVisit.current) {
      trackedVisit.current = true;
      fetch('/api/analytics/visit', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          slug: store.slug,
          device: window.innerWidth < 768 ? 'mobile' : 'desktop',
          source: document.referrer ? 'other' : 'direct',
        })
      }).catch(e => console.error("Visits metric log failed", e));
    }
  }, [store]);

  async function fetchProducts(type: string, storeSlug: string) {
    try {
      const res = await fetch(`/api/store/${storeSlug}/products?profileType=${type}`);
      if (res.ok) {
        const data = await res.json();
        setProducts(data.products || []);
      }
    } catch (e) {
      console.error("Products acquisition error", e);
    }
  }

  async function fetchReviews(storeSlug: string) {
    try {
      const res = await fetch(`/api/store/${storeSlug}/reviews`);
      if (res.ok) {
        const data = await res.json();
        setReviews(data.reviews || []);
      }
    } catch (e) {}
  }

  // 2. Handle Profile confirmation under Gate modal
  const handleConfirmGate = () => {
    if (!gateSelection || !store) return;
    setGateSubmitting(true);

    setTimeout(() => {
      // Setup Storage expiry based on gateSessionDuration
      const expiryOffset = 
        store.gateSessionDuration === '24h' ? 24 * 60 * 60 * 1000 :
        store.gateSessionDuration === '7d' ? 7 * 24 * 60 * 60 * 1000 :
        store.gateSessionDuration === 'forever' ? 365 * 24 * 60 * 60 * 1000 : null;

      const savePayload = {
        type: gateSelection,
        expiresAt: expiryOffset ? Date.now() + expiryOffset : null
      };

      const storageKey = `gate_${store.slug}`;
      if (store.gateSessionDuration === 'session') {
        sessionStorage.setItem(storageKey, JSON.stringify(savePayload));
      } else {
        localStorage.setItem(storageKey, JSON.stringify(savePayload));
      }

      setProfileType(gateSelection);
      setShowGate(false);
      setGateSubmitting(false);
      fetchProducts(gateSelection, store.slug);
    }, 600);
  };

  const handleResetProfile = () => {
    if (!store) return;
    const storageKey = `gate_${store.slug}`;
    localStorage.removeItem(storageKey);
    sessionStorage.removeItem(storageKey);
    setProfileType(null);
    setCart([]); // Clear cart to avoid mismatching pricing matrix
    setShowGate(true);
    setGateSelection(null);
  };

  // Cart operations
  const addToCart = (product: Product) => {
    const minQty = (profileType === 'wholesale' && product.wholesaleMinQty) ? product.wholesaleMinQty : 1;
    const existing = cart.find(item => item.product.id === product.id);
    
    if (existing) {
      setCart(cart.map(item => 
        item.product.id === product.id 
          ? { ...item, quantity: item.quantity + 1 } 
          : item
      ));
    } else {
      setCart([...cart, { product, quantity: minQty }]);
    }
    setIsCartOpen(true);
  };

  const updateCartQuantity = (productId: string, delta: number) => {
    const item = cart.find(i => i.product.id === productId);
    if (!item) return;

    const minQty = (profileType === 'wholesale' && item.product.wholesaleMinQty) ? item.product.wholesaleMinQty : 1;
    const nextQty = item.quantity + delta;

    if (nextQty < minQty) {
      // Remove item
      setCart(cart.filter(i => i.product.id !== productId));
    } else {
      setCart(cart.map(i => 
        i.product.id === productId 
          ? { ...i, quantity: nextQty } 
          : i
      ));
    }
  };

  // Submit dynamic review
  const handleSubmitReview = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!reviewName || !store) return;

    try {
      const res = await fetch(`/api/store/${store.slug}/review`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          productId: selectedProduct?.id || null,
          customerName: reviewName,
          rating: reviewRating,
          comment: reviewComment
        })
      });
      if (res.ok) {
        setReviewSuccess(true);
        setTimeout(() => {
          setShowReviewForm(false);
          setReviewName('');
          setReviewComment('');
          setReviewSuccess(false);
        }, 3000);
      }
    } catch (err) {}
  };

  // Checkout deep link construct
  const handleCompleteOrder = async () => {
    if (!store || cart.length === 0) return;

    const total = cart.reduce((sum, item) => {
      const itemPrice = (profileType === 'wholesale' && item.product.wholesalePrice) 
        ? item.product.wholesalePrice 
        : (item.product.salePrice || item.product.price);
      return sum + (itemPrice * item.quantity);
    }, 0);

    // 1. Inform Server database to register order and platform fee estimates
    try {
      await fetch('/api/orders', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          storeId: store.id,
          customerName,
          customerPhone,
          items: cart.map(item => ({
            productId: item.product.id,
            productName: item.product.name,
            quantity: item.quantity,
            price: (profileType === 'wholesale' && item.product.wholesalePrice) ? item.product.wholesalePrice : (item.product.salePrice || item.product.price),
          })),
          totalAmount: total
        })
      });

      // Update analytics conversion metric inside server async
      await fetch('/api/analytics/visit', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          slug: store.slug,
          isRedirect: true
        })
      });

    } catch (e) {
      console.error("Order server logging failed", e);
    }

    // 2. Format a highly polished WhatsApp text receipt message
    let orderListText = '';
    cart.forEach((item, index) => {
      const itemPrice = (profileType === 'wholesale' && item.product.wholesalePrice) 
        ? item.product.wholesalePrice 
        : (item.product.salePrice || item.product.price);
      
      orderListText += `${index + 1}. *${item.product.name}* (Qtd: ${item.quantity}) - R$ ${(itemPrice * item.quantity).toFixed(2)}\n`;
    });

    const intro = `Olá! Vim através da plataforma *VestuAI* e gostaria de fechar o seguinte pedido no perfil *${profileType === 'wholesale' ? 'ATACADO' : 'VAREJO'}*:\n\n`;
    const details = `\n*TOTAL DO PEDIDO: R$ ${total.toFixed(2)}*\n\n`;
    const contact = `*Dados do Comprador:*\nNome: ${customerName || 'Não informado'}\nTelefone: ${customerPhone || 'Não informado'}\n`;
    const outro = `\n_Aguardando instruções de pagamento e frete!_`;

    const fullMsg = encodeURIComponent(intro + orderListText + details + contact + outro);
    const whatsappUrl = `https://wa.me/${store.phone}?text=${fullMsg}`;

    setOrderCompleted(true);
    setCart([]);
    setIsCheckoutModalOpen(false);

    // Redirect
    window.open(whatsappUrl, '_blank');
  };

  // Rendering loading or layout errors
  if (loading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-slate-50 py-12 px-4 sm:px-6 lg:px-8">
        <div className="text-center space-y-4">
          <div className="mx-auto h-12 w-12 animate-spin rounded-full border-4 border-[#6366f1] border-t-transparent" />
          <p className="text-sm font-semibold text-slate-600">Ajustando cabides e configurando vitrine profissional...</p>
        </div>
      </div>
    );
  }

  if (error || !store) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-slate-50 py-12 px-4 sm:px-6 lg:px-8">
        <div className="text-center space-y-6 max-w-md">
          <div className="mx-auto h-16 w-16 text-rose-500 rounded-full bg-rose-50 flex items-center justify-center">
            <AlertTriangle className="h-9 w-9" />
          </div>
          <h2 className="text-2xl font-bold text-slate-800">Ops! Loja Indisponível</h2>
          <p className="text-sm text-slate-500">{error || 'Esta vitrine não se encontra ativa no momento.'}</p>
          <button 
            onClick={onNavigateHome}
            className="w-full rounded-xl bg-slate-800 py-3 text-sm font-bold text-white hover:bg-[#6366f1] transition cursor-pointer"
          >
            Voltar para a VestuAI
          </button>
        </div>
      </div>
    );
  }

  // Categories list extracted from products catalog
  const categories = ['Todos', ...new Set(products.map(p => p.category))];

  // Client filtering
  const filteredProducts = products.filter(p => {
    const matchesSearch = p.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          p.tags.some(t => t.toLowerCase().includes(searchQuery.toLowerCase()));
    const matchesCategory = activeCategory === 'Todos' || p.category === activeCategory;
    return matchesSearch && matchesCategory;
  }).sort((a, b) => {
    const priceA = (profileType === 'wholesale' && a.wholesalePrice) ? a.wholesalePrice : (a.salePrice || a.price);
    const priceB = (profileType === 'wholesale' && b.wholesalePrice) ? b.wholesalePrice : (b.salePrice || b.price);
    if (sortBy === 'lowest') return priceA - priceB;
    if (sortBy === 'highest') return priceB - priceA;
    return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime(); // recent default
  });

  return (
    <div className={`${currentTemplate.className} selection:bg-neutral-500 selection:text-white transition-all`}>
      
      {/* 1. BLURRED SECURITY COVER ACTIVE GATE PANEL */}
      {showGate && (
        <div className="fixed inset-0 z-[1000] flex items-center justify-center bg-slate-950/85 p-4 backdrop-blur-md" onClick={(e) => e.stopPropagation()}>
          <div className="w-full max-w-lg rounded-3xl bg-white p-6 shadow-2xl text-slate-800 space-y-6">
            <div className="text-center space-y-2">
              <div className="mx-auto h-12 w-12 rounded-2xl bg-[#6366f1]/10 flex items-center justify-center text-[#6366f1]">
                <Lock className="h-6 w-6" />
              </div>
              <h2 className="text-xl sm:text-2xl font-bold tracking-tight text-slate-900">{store.gateTitle}</h2>
              <p className="text-xs sm:text-sm text-slate-500">{store.gateSubtitle}</p>
            </div>

            {/* Profile choices */}
            <div className="grid grid-cols-1 min-[480px]:grid-cols-2 gap-4">
              
              <div 
                onClick={() => setGateSelection('retail')}
                className={`relative cursor-pointer rounded-2xl border-2 p-4 transition-all duration-300 ${
                  gateSelection === 'retail' 
                    ? 'border-[#6366f1] bg-[#6366f1]/5 shadow-inner' 
                    : 'border-slate-100 bg-slate-50 hover:bg-slate-100 hover:border-slate-200'
                }`}
              >
                <div className="flex items-center space-x-2 text-[#6366f1] font-bold text-sm">
                  <User className="h-4 w-4" />
                  <span>{store.gateRetailLabel || 'Comprar em Varejo'}</span>
                </div>
                <p className="text-[11px] text-slate-500 mt-2 leading-relaxed">{store.gateRetailDescription || 'Destinado a compras casuais individuais com menor volume de itens.'}</p>
                {gateSelection === 'retail' && (
                  <div className="absolute top-3 right-3 h-4 w-4 bg-[#6366f1] rounded-full flex items-center justify-center text-white">
                    <Check className="h-2.5 w-2.5" />
                  </div>
                )}
              </div>

              <div 
                onClick={() => setGateSelection('wholesale')}
                className={`relative cursor-pointer rounded-2xl border-2 p-4 transition-all duration-300 ${
                  gateSelection === 'wholesale' 
                    ? 'border-[#8b5cf6] bg-[#8b5cf6]/5 shadow-inner' 
                    : 'border-slate-100 bg-slate-50 hover:bg-slate-100 hover:border-slate-200'
                }`}
              >
                <div className="flex items-center space-x-2 text-[#8b5cf6] font-bold text-sm">
                  <Package className="h-4 w-4" />
                  <span>{store.gateWholesaleLabel || 'Comprar em Atacado'}</span>
                </div>
                <p className="text-[11px] text-slate-500 mt-2 leading-relaxed">{store.gateWholesaleDescription || 'Preços de revenda altamente qualificados para fardos mínimos de vestuários.'}</p>
                {gateSelection === 'wholesale' && (
                  <div className="absolute top-3 right-3 h-4 w-4 bg-[#8b5cf6] rounded-full flex items-center justify-center text-white">
                    <Check className="h-2.5 w-2.5" />
                  </div>
                )}
              </div>

            </div>

            {/* Warning alerts dynamically displayed inside Gate scope */}
            {gateSelection === 'wholesale' && (
              <div className="rounded-xl bg-amber-50 border border-amber-200 p-3 flex space-x-3 text-amber-800 text-[11px] leading-relaxed">
                <AlertTriangle className="h-5 w-5 text-amber-500 shrink-0" />
                <div>
                  <span className="font-bold">Atenção ao Pedido Mínimo:</span> Os produtos no atacado possuem requisitos mínimos estipulados de unidades por modelo comercializados no carrinho para fechamento.
                </div>
              </div>
            )}

            <button 
              onClick={(e) => { (e.currentTarget as HTMLButtonElement).disabled = true; handleConfirmGate(); }}
              disabled={!gateSelection || gateSubmitting}
              className={`w-full rounded-xl py-3 text-xs font-bold text-white transition duration-300 cursor-pointer ${
                !gateSelection 
                  ? 'bg-slate-300 cursor-not-allowed' 
                  : gateSelection === 'retail' 
                    ? 'bg-[#6366f1] hover:bg-[#4f46e5]' 
                    : 'bg-[#8b5cf6] hover:bg-[#7c3aed]'
              }`}
            >
              {gateSubmitting ? 'Verificando segurança do perfil...' : 'Confirmar e Acessar Vitrine'}
            </button>
          </div>
        </div>
      )}

      {/* 2. MAIN STOREFRONT VIEWPORT */}
      <div className={showGate ? "blur-md pointer-events-none select-none" : ""}>
        
        {/* Dynamic header navigation */}
        <header className={`${currentTemplate.headerClass} py-4 px-4 sm:px-6 lg:px-8 border-b transition-all`}>
          <div className="mx-auto max-w-7xl flex items-center justify-between">
            <div className="flex items-center space-x-3">
              {store.logoUrl ? (
                <img 
                  src={store.logoUrl} 
                  alt={store.name} 
                  referrerPolicy="no-referrer"
                  className="h-10 w-10 sm:h-12 sm:w-12 rounded-full object-cover shadow-sm bg-neutral-200" 
                />
              ) : (
                <div className="flex h-10 w-10 sm:h-12 sm:w-12 items-center justify-center rounded-2xl bg-neutral-800 text-white font-black text-xs shadow-md">
                  V
                </div>
              )}
              <div>
                <h1 className="text-base sm:text-lg font-black tracking-tight">{store.name}</h1>
                <p className="text-[10px] opacity-75">{store.physicalAddress || 'Loja Online'}</p>
              </div>
            </div>

            {/* Profile badge and reset selector */}
            <div className="flex items-center space-x-3">
              {profileType && store.gateEnabled && (
                <div className="hidden sm:flex items-center space-x-2 bg-black/10 px-3 py-1.5 rounded-full text-xs font-semibold">
                  <span className="capitalize">{profileType === 'wholesale' ? 'Atacado' : 'Varejo'}</span>
                  <button 
                    onClick={handleResetProfile}
                    className="text-[10px] text-[#6366f1] hover:underline ml-1 cursor-pointer"
                  >
                    Trocar
                  </button>
                </div>
              )}

              {/* Home Navigation fallback */}
              <button 
                onClick={onNavigateHome}
                className="hidden md:block text-xs font-medium border border-current hover:opacity-75 px-3 py-1.5 rounded-xl cursor-pointer"
              >
                Ver plataforma VestuAI
              </button>

              {/* Shopping bag with items count bubble */}
              <button 
                onClick={() => setIsCartOpen(true)}
                className="relative p-2 rounded-full bg-black/5 hover:bg-black/10 transition cursor-pointer"
              >
                <ShoppingBag className="h-5.5 w-5.5" />
                {cart.length > 0 && (
                  <span className="absolute -top-1 -right-1 h-5 w-5 bg-[#6366f1] hover:bg-[#6366f1] text-[10px] font-bold text-white rounded-full flex items-center justify-center animate-bounce">
                    {cart.reduce((sum, i) => sum + i.quantity, 0)}
                  </span>
                )}
              </button>
            </div>
          </div>
        </header>

        {/* Home Cover Banner if any exists */}
        {store.bannerUrl && (
          <div className="w-full h-44 sm:h-64 md:h-80 relative overflow-hidden bg-neutral-900 border-b border-black/10">
            <img 
              src={store.bannerUrl} 
              alt={store.name} 
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover object-center opacity-85" 
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent flex items-end justify-start p-4 sm:p-8">
              <div className="text-white max-w-xl space-y-1">
                <span className="bg-gradient-to-tr from-[#6366f1] to-[#a855f7] text-[11px] font-bold uppercase tracking-wider px-2.5 py-1 rounded-full">
                  Lançamento de Estilo
                </span>
                <p className="text-xs sm:text-sm text-neutral-200 mt-2">Visite nossas coleções e garanta produtos de qualidade em poucos cliques.</p>
              </div>
            </div>
          </div>
        )}

        {/* Multi storefront promo strips */}
        <div className="bg-gradient-to-r from-[#6366f1] to-[#4f46e5] text-white py-2 px-4 shadow text-center text-xs font-bold flex items-center justify-center space-x-2">
          <Sparkles className="h-4 w-4 animate-spin-slow" />
          <span>Atendimento acelerado via WhatsApp redirecionado de primeira!</span>
          {profileType === 'wholesale' && (
            <span className="bg-white/25 px-2 py-0.5 rounded ml-2">Preços Atacados Ativos</span>
          )}
        </div>

        {/* 3. PRODUCT CATALOG GRID */}
        <main className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-8 space-y-8">
          
          {/* Filters & search line */}
          <div className="bg-white/10 p-4 rounded-3xl border border-black/5 flex flex-col sm:flex-row gap-4 items-center justify-between">
            <input 
              type="text"
              placeholder="Buscar roupas, calçados e coleções..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full sm:max-w-md rounded-2xl border-2 border-slate-100 bg-white/50 px-4 py-2.5 text-xs text-slate-800 placeholder-slate-400 focus:border-[#6366f1] focus:ring-0 outline-none"
            />

            <div className="flex items-center space-x-2 w-full sm:w-auto overflow-x-auto justify-end">
              <span className="text-xs font-bold text-slate-400 shrink-0">Ordenar:</span>
              <select 
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value)}
                className="rounded-2xl border-2 border-slate-100 bg-white/50 px-3 py-2 text-xs text-slate-700 focus:border-[#6366f1] outline-none"
              >
                <option value="recent">Mais Recentes</option>
                <option value="lowest">Menor Preço</option>
                <option value="highest">Maior Preço</option>
              </select>
            </div>
          </div>

          {/* Categories Tab scrolling view */}
          {categories.length > 2 && (
            <div className="flex items-center space-x-2 overflow-x-auto pb-2 scrollbar-none">
              {categories.map(cat => (
                <button 
                  key={cat}
                  onClick={() => setActiveCategory(cat)}
                  className={`px-4 py-2 rounded-2xl text-xs font-bold tracking-tight shrink-0 transition cursor-pointer ${
                    activeCategory === cat 
                      ? 'bg-neutral-800 text-white' 
                      : 'bg-white text-slate-600 border border-slate-100 hover:bg-slate-50'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>
          )}

          {/* Product Items mapping Grid */}
          {filteredProducts.length === 0 ? (
            <div className="text-center py-16 bg-white/20 rounded-3xl border border-dashed border-slate-200">
              <ShoppingBag className="mx-auto h-12 w-12 text-slate-300" />
              <h3 className="text-base font-bold text-slate-600 mt-4">Nenhum produto localizado</h3>
              <p className="text-xs text-slate-400 mt-1 max-w-xs mx-auto">Tente reajustar seus termos de busca ou mudar a categoria ativa.</p>
            </div>
          ) : (
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 sm:gap-6">
              {filteredProducts.map(prod => {
                const isWholesale = profileType === 'wholesale';
                const hasPromo = prod.isPromotion && prod.salePrice && !isWholesale;
                const activePrice = isWholesale ? (prod.wholesalePrice || prod.price) : (prod.salePrice || prod.price);

                return (
                  <div 
                    key={prod.id}
                    className={`${currentTemplate.cardClass} flex flex-col h-full transform transition duration-300 hover:shadow-xl`}
                  >
                    {/* Visual Card cover */}
                    <div 
                      onClick={() => setSelectedProduct(prod)}
                      className="relative aspect-square w-full overflow-hidden bg-neutral-100 cursor-pointer"
                    >
                      <img 
                        src={prod.photos[0]} 
                        alt={prod.name} 
                        referrerPolicy="no-referrer"
                        className="h-full w-full object-cover object-center transition duration-500 hover:scale-105" 
                      />
                      {/* Promos tags */}
                      {hasPromo && (
                        <span className="absolute top-2 left-2 rounded bg-rose-500 px-2 py-0.5 text-[9px] font-black text-white uppercase shadow">
                          Promo
                        </span>
                      )}
                      {prod.isFeatured && (
                        <span className="absolute top-2 right-2 rounded bg-indigo-500 px-2 py-0.5 text-[9px] font-black text-white uppercase shadow">
                          Destaque
                        </span>
                      )}
                      
                      {isWholesale && prod.wholesaleMinQty && (
                        <span className="absolute bottom-2 left-2 rounded bg-purple-600 px-2.5 py-0.5 text-[8px] font-black text-white uppercase shadow">
                          Mínimo: {prod.wholesaleMinQty}pçs
                        </span>
                      )}
                    </div>

                    {/* Meta info card */}
                    <div className="p-3 sm:p-4 flex-1 flex flex-col justify-between">
                      <div className="space-y-1">
                        <span className="text-[10px] text-slate-400 uppercase tracking-widest font-mono">
                          {prod.category}
                        </span>
                        <h3 
                          onClick={() => setSelectedProduct(prod)}
                          className="text-xs sm:text-sm font-bold tracking-tight text-current hover:underline cursor-pointer truncate"
                        >
                          {prod.name}
                        </h3>
                        
                        <div className="pt-1">
                          {hasPromo ? (
                            <div className="flex items-center space-x-1.5">
                              <span className="text-xs sm:text-sm font-black text-rose-500">R$ {prod.salePrice?.toFixed(2)}</span>
                              <span className="text-[10px] line-through text-slate-400">R$ {prod.price.toFixed(2)}</span>
                            </div>
                          ) : (
                            <span className="text-xs sm:text-sm font-black text-current">
                              R$ {activePrice.toFixed(2)}
                              {isWholesale && <span className="text-[9px] font-semibold text-purple-600 ml-1">Atacado</span>}
                            </span>
                          )}
                        </div>
                      </div>

                      <button 
                        onClick={() => addToCart(prod)}
                        className="w-full inline-flex items-center justify-center space-x-1.5 rounded-xl bg-slate-900 py-2 px-3 text-xs font-semibold text-white hover:bg-[#6366f1] transition duration-300 shadow-sm hover:shadow mt-3 cursor-pointer"
                      >
                        <Plus className="h-3 w-3" />
                        <span>Adicionar</span>
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}

        </main>

        <footer className="bg-black/10 py-8 px-4 text-center text-xs opacity-70 border-t border-black/5 mt-16">
          <p className="font-bold">{store.name} — Todos os direitos reservados.</p>
          <div className="mt-2 text-[10px] inline-flex items-center space-x-1 justify-center">
            <span>Criado e hospedado via</span>
            <span className="font-sans font-bold text-[#6366f1] inline-flex items-center">
              <Sparkles className="h-3.5 w-3.5 mr-0.5 text-[#6366f1]" />
              VestuAI
            </span>
          </div>
        </footer>

      </div>

      {/* 4. PRODUCT DETAIL OVERLAY POPUP */}
      {selectedProduct && (
        <div className="fixed inset-0 z-[1100] flex items-center justify-center bg-slate-950/70 p-4 backdrop-blur-sm">
          <div className="relative w-full max-w-2xl rounded-3xl bg-white p-5 sm:p-6 text-slate-800 shadow-2xl flex flex-col md:flex-row gap-6 scrollbar-none max-h-[90vh] overflow-y-auto">
            
            <button 
              onClick={() => setSelectedProduct(null)}
              className="absolute top-4 right-4 p-2 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-500 cursor-pointer"
            >
              <X className="h-4.5 w-4.5" />
            </button>

            {/* Photo galleries */}
            <div className="w-full md:w-1/2 space-y-2">
              <div className="aspect-square w-full rounded-2xl overflow-hidden bg-neutral-100 border">
                <img 
                  src={selectedProduct.photos[0]} 
                  alt={selectedProduct.name}
                  referrerPolicy="no-referrer"
                  className="h-full w-full object-cover" 
                />
              </div>
              <div className="grid grid-cols-4 gap-2">
                {selectedProduct.photos.map((ph, idx) => (
                  <div key={idx} className="aspect-square rounded-xl overflow-hidden bg-slate-50 border">
                    <img src={ph} alt="" referrerPolicy="no-referrer" className="h-full w-full object-cover" />
                  </div>
                ))}
              </div>
            </div>

            {/* Information panel */}
            <div className="w-full md:w-1/2 space-y-4">
              <span className="text-[10px] font-black uppercase tracking-widest bg-slate-150 px-2.5 py-1 rounded-full text-[#6366f1]">
                {selectedProduct.category}
              </span>
              
              <h2 className="text-base sm:text-lg font-black tracking-tight text-slate-900 mt-2">{selectedProduct.name}</h2>
              
              <div className="pt-1">
                {(selectedProduct.isPromotion && selectedProduct.salePrice && profileType !== 'wholesale') ? (
                  <div className="flex items-center space-x-2">
                    <span className="text-lg sm:text-xl font-black text-rose-500">R$ {selectedProduct.salePrice.toFixed(2)}</span>
                    <span className="text-xs line-through text-slate-400">R$ {selectedProduct.price.toFixed(2)}</span>
                  </div>
                ) : (
                  <span className="text-lg sm:text-xl font-black text-slate-900">
                    R$ {((profileType === 'wholesale' && selectedProduct.wholesalePrice) ? selectedProduct.wholesalePrice : selectedProduct.price).toFixed(2)}
                    {profileType === 'wholesale' && <span className="text-xs text-purple-600 font-bold ml-1.5">(Preço Atacado)</span>}
                  </span>
                )}
              </div>

              <div className="border-t border-slate-100 pt-3">
                <h4 className="text-xs font-bold text-slate-400">Descrição do Produto:</h4>
                <p className="text-xs text-slate-500 mt-1 leading-relaxed">{selectedProduct.description || 'Nenhuma descrição providenciada para o produto.'}</p>
              </div>

              {profileType === 'wholesale' && selectedProduct.wholesaleMinQty && (
                <div className="rounded-xl bg-purple-50 p-2.5 flex space-x-2 border border-purple-100 text-purple-800 text-[11px] leading-snug">
                  <Package className="h-4 w-4 text-purple-500 shrink-0" />
                  <div>
                    <span className="font-bold">Mínimo Atacado:</span> Deve-se comprar pelo menos {selectedProduct.wholesaleMinQty} exemplares deste modelo para qualificar o pedido.
                  </div>
                </div>
              )}

              {/* Approval status block reviews lists */}
              <div className="border-t border-slate-100 pt-3">
                <div className="flex items-center justify-between">
                  <h4 className="text-xs font-bold text-slate-500">Avaliações de Clientes</h4>
                  <button 
                    onClick={() => setShowReviewForm(!showReviewForm)}
                    className="text-[10px] text-[#6366f1] font-bold hover:underline cursor-pointer"
                  >
                    Avaliar Produto
                  </button>
                </div>
                
                {/* Embedded Review Write form */}
                {showReviewForm ? (
                  <form onSubmit={handleSubmitReview} className="mt-2 space-y-2.5 p-3 bg-slate-50 rounded-xl border">
                    <div className="flex items-center justify-between">
                      <span className="text-[10px] font-bold text-slate-500">Dar nota de 1 a 5:</span>
                      <div className="flex items-center space-x-1">
                        {[1, 2, 3, 4, 5].map(n => (
                          <Star 
                            key={n} 
                            onClick={() => setReviewRating(n)}
                            className={`h-4.5 w-4.5 cursor-pointer ${n <= reviewRating ? 'fill-amber-400 text-amber-400' : 'text-slate-300'}`} 
                          />
                        ))}
                      </div>
                    </div>
                    <input 
                      type="text" 
                      placeholder="Seu nome completo"
                      value={reviewName}
                      onChange={(e) => setReviewName(e.target.value)}
                      required
                      className="w-full rounded-lg border bg-white px-3 py-1.5 text-xs outline-none"
                    />
                    <textarea 
                      placeholder="Fale um pouco sobre o caimento, cores e entrega..."
                      value={reviewComment}
                      onChange={(e) => setReviewComment(e.target.value)}
                      rows={2}
                      className="w-full rounded-lg border bg-white p-2 text-xs outline-none"
                    />
                    {reviewSuccess && (
                      <div className="text-[10px] text-emerald-600 font-bold">Avaliação enviada! Aguardando aprovação para visualização na vitrine.</div>
                    )}
                    <div className="flex justify-end space-x-2">
                      <button 
                        type="button" 
                        onClick={() => setShowReviewForm(false)}
                        className="rounded-lg bg-slate-200 text-slate-600 text-[10px] px-3 py-1 cursor-pointer"
                      >
                        Cancelar
                      </button>
                      <button 
                        type="submit" 
                        className="rounded-lg bg-[#6366f1] text-white text-[10px] font-bold px-4 py-1 cursor-pointer"
                      >
                        Enviar avaliação
                      </button>
                    </div>
                  </form>
                ) : (
                  <div className="mt-2 space-y-2 max-h-32 overflow-y-auto pr-1">
                    {reviews.filter(r => r.productId === selectedProduct.id).length === 0 ? (
                      <p className="text-[10px] text-slate-400 italic">Nenhum comentário para este produto.</p>
                    ) : (
                      reviews.filter(r => r.productId === selectedProduct.id).map(r => (
                        <div key={r.id} className="text-[11px] p-2 bg-slate-50 rounded-xl space-y-1">
                          <div className="flex items-center justify-between">
                            <span className="font-bold text-slate-700">{r.customerName}</span>
                            <div className="flex items-center space-x-0.5">
                              {Array.from({ length: r.rating }).map((_, i) => (
                                <Star key={i} className="h-3 w-3 fill-amber-400 text-amber-400" />
                              ))}
                            </div>
                          </div>
                          <p className="text-slate-500">{r.comment}</p>
                        </div>
                      ))
                    )}
                  </div>
                )}
              </div>

              <div className="pt-2">
                <button 
                  onClick={() => {
                    addToCart(selectedProduct);
                    setSelectedProduct(null);
                  }}
                  className="w-full rounded-xl bg-slate-900 py-3 text-xs font-bold text-white hover:bg-[#6366f1] transition cursor-pointer"
                >
                  Adicionar ao Carrinho de Compras
                </button>
              </div>

            </div>

          </div>
        </div>
      )}

      {/* 5. SHOPPING CART OFF-DRAWER PANEL */}
      {isCartOpen && (
        <div className="fixed inset-0 z-[1200] flex justify-end bg-slate-950/60 backdrop-blur-xs">
          {/* Click shadow block */}
          <div onClick={() => setIsCartOpen(false)} className="flex-1" />
          
          <div className="w-full max-w-md bg-white h-full p-6 text-slate-800 shadow-2xl flex flex-col justify-between animate-slide-in">
            
            <div className="space-y-4 flex-1 flex flex-col min-h-0">
              <div className="flex items-center justify-between border-b pb-4">
                <div className="flex items-center space-x-2 text-slate-900 font-black">
                  <ShoppingBag className="h-5 w-5 text-[#6366f1]" />
                  <span>Sacola de Pedidos</span>
                </div>
                <button 
                  onClick={() => setIsCartOpen(false)}
                  className="p-1.5 rounded-full hover:bg-slate-100 text-slate-500 cursor-pointer"
                >
                  <X className="h-4.5 w-4.5" />
                </button>
              </div>

              {/* Items List scroll container */}
              <div className="flex-1 overflow-y-auto space-y-4 pr-1">
                {cart.length === 0 ? (
                  <div className="text-center py-20 space-y-2">
                    <ShoppingBag className="mx-auto h-12 w-12 text-slate-200" />
                    <p className="text-sm font-bold text-slate-500">Sua sacola está vazia</p>
                    <p className="text-xs text-slate-400">Adicione vestidos, blusas ou coleções para fechar seu fardo.</p>
                  </div>
                ) : (
                  cart.map(item => {
                    const itemPrice = (profileType === 'wholesale' && item.product.wholesalePrice) 
                      ? item.product.wholesalePrice 
                      : (item.product.salePrice || item.product.price);
                    
                    const minQty = (profileType === 'wholesale' && item.product.wholesaleMinQty) ? item.product.wholesaleMinQty : 1;

                    return (
                      <div key={item.product.id} className="flex space-x-3 p-3 bg-slate-50 rounded-2xl border items-start">
                        <img 
                          src={item.product.photos[0]} 
                          alt="" 
                          referrerPolicy="no-referrer"
                          className="h-14 w-14 rounded-xl object-cover bg-neutral-100 shrink-0" 
                        />
                        <div className="flex-1 space-y-1">
                          <h4 className="text-xs font-bold text-slate-800 line-clamp-1">{item.product.name}</h4>
                          <span className="text-[10px] text-slate-400">{item.product.category}</span>
                          <div className="flex items-center justify-between pt-1">
                            {/* Actions counter with wholesale limits safeguard */}
                            <div className="flex items-center space-x-2 bg-white rounded-lg border px-1 py-0.5 shadow-xs">
                              <button 
                                onClick={() => updateCartQuantity(item.product.id, -1)}
                                className="p-1 hover:text-rose-500 text-slate-400 cursor-pointer"
                              >
                                <Minus className="h-3 w-3" />
                              </button>
                              <span className="text-xs font-bold px-1 text-slate-700">{item.quantity}</span>
                              <button 
                                onClick={() => updateCartQuantity(item.product.id, 1)}
                                className="p-1 hover:text-[#6366f1] text-slate-400 cursor-pointer"
                              >
                                <Plus className="h-3 w-3" />
                              </button>
                            </div>

                            <span className="text-xs font-black text-slate-900">R$ {(itemPrice * item.quantity).toFixed(2)}</span>
                          </div>
                        </div>
                      </div>
                    );
                  })
                )}
              </div>
            </div>

            {/* Calculations & Checkout action buttons */}
            {cart.length > 0 && (
              <div className="border-t pt-4 space-y-4 bg-white">
                <div className="flex items-center justify-between text-base font-black text-slate-900">
                  <span>Subtotal Geral:</span>
                  <span>
                    R$ {cart.reduce((sum, item) => {
                      const itemPrice = (profileType === 'wholesale' && item.product.wholesalePrice) 
                        ? item.product.wholesalePrice 
                        : (item.product.salePrice || item.product.price);
                      return sum + (itemPrice * item.quantity);
                    }, 0).toFixed(2)}
                  </span>
                </div>

                <div className="p-3 rounded-2xl bg-indigo-50/50 text-[#6366f1] text-[10px] leading-relaxed flex items-start space-x-2">
                  <Sparkles className="h-4.5 w-4.5 text-[#6366f1] shrink-0" />
                  <div>
                    Ao avançar, geramos o espelho de faturamento e abriremos o WhatsApp com a sua mensagem pré-formatada com o lojista.
                  </div>
                </div>

                <button 
                  onClick={() => setIsCheckoutModalOpen(true)}
                  className="w-full rounded-xl bg-slate-900 py-3 text-xs font-bold text-white hover:bg-[#6366f1] transition duration-300 flex items-center justify-center space-x-1.5 cursor-pointer"
                >
                  <MessageCircle className="h-4 w-4" />
                  <span>Avançar para o WhatsApp</span>
                </button>
              </div>
            )}

          </div>
        </div>
      )}

      {/* 6. WHATSAPP CHECKOUT MODAL FORM POPUP */}
      {isCheckoutModalOpen && (
        <div className="fixed inset-0 z-[1300] flex items-center justify-center bg-slate-950/60 backdrop-blur-sm p-4">
          <div className="w-full max-w-md rounded-3xl bg-white p-5 sm:p-6 text-slate-850 shadow-2xl relative space-y-4">
            
            <button 
              onClick={() => setIsCheckoutModalOpen(false)}
              className="absolute top-4 right-4 p-1.5 rounded-full hover:bg-slate-100 text-slate-400 cursor-pointer"
            >
              <X className="h-4.5 w-4.5" />
            </button>

            <div className="text-center space-y-1">
              <h3 className="text-base sm:text-lg font-black tracking-tight text-slate-900">Dados do Contato (Opcional)</h3>
              <p className="text-xs text-slate-500">Preencha os campos para que o lojista te conheça e acelere o envio dos produtos!</p>
            </div>

            <div className="space-y-3">
              <div className="space-y-1">
                <label className="text-[10px] uppercase font-bold text-slate-400">Seu Nome Completo</label>
                <input 
                  type="text" 
                  placeholder="Ex: Amanda Silva"
                  value={customerName}
                  onChange={(e) => setCustomerName(e.target.value)}
                  className="w-full rounded-xl border bg-slate-50 px-3.5 py-2.5 text-xs text-slate-800 outline-none focus:border-[#6366f1] focus:bg-white"
                />
              </div>

              <div className="space-y-1">
                <label className="text-[10px] uppercase font-bold text-slate-400">Seu WhatsApp de Atendimento</label>
                <input 
                  type="tel" 
                  placeholder="Ex: 5511999998888"
                  value={customerPhone}
                  onChange={(e) => setCustomerPhone(e.target.value)}
                  className="w-full rounded-xl border bg-slate-50 px-3.5 py-2.5 text-xs text-slate-800 outline-none focus:border-[#6366f1] focus:bg-white"
                />
              </div>
            </div>

            <button 
              onClick={handleCompleteOrder}
              className="w-full rounded-xl bg-gradient-to-tr from-[#12a865] to-[#22c55e] py-3 text-xs font-black text-white hover:opacity-90 shadow flex items-center justify-center space-x-1.5 cursor-pointer"
            >
              <MessageCircle className="h-4 w-4" />
              <span>Redirecionar para WhatsApp Oficial</span>
            </button>
            <p className="text-[10px] text-slate-400 text-center">Garantia VestuAI de segurança na sua mensagem.</p>
          </div>
        </div>
      )}

    </div>
  );
}
