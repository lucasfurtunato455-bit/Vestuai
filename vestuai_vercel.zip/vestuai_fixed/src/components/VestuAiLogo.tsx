import React from 'react';

interface LogoProps {
  className?: string;
  size?: number;
  showText?: boolean;
  variant?: 'primary' | 'dark' | 'light';
}

export function VestuAiLogo({ className = '', size = 200, showText = true, variant = 'primary' }: LogoProps) {
  const isLight = variant === 'light';
  
  // Choose colors based on the theme variant (light background/dark background)
  const leftArmColor = isLight ? '#0f172a' : '#ffffff'; // Black/dark slate for light background, white/silver for dark/primary
  const textPrimaryColor = isLight ? 'text-slate-900' : 'text-white';
  const subtextColor = isLight ? 'text-slate-500' : 'text-slate-400';

  return (
    <div className={`flex flex-col items-center justify-center text-center ${className}`} style={{ width: size }}>
      {/* SVG Emblem matching the new modern geometric logo */}
      <svg
        viewBox="100 40 340 340"
        className="w-full h-auto"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
      >
        <defs>
          {/* Blue Gradient matching the user's request */}
          <linearGradient id="vestu-new-blue-grad" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#60a5fa" /> {/* light blue-400 */}
            <stop offset="50%" stopColor="#2563eb" /> {/* blue-600 */}
            <stop offset="100%" stopColor="#1d4ed8" /> {/* blue-700 */}
          </linearGradient>
          
          {/* Soft background glow if dark or primary */}
          <radialGradient id="vestu-glow" cx="270" cy="200" r="160">
            <stop offset="0%" stopColor="#2563eb" stopOpacity="0.12" />
            <stop offset="100%" stopColor="#2563eb" stopOpacity="0" />
          </radialGradient>
        </defs>

        {/* Ambient background glow if on dark or primary */}
        {!isLight && (
          <circle cx="270" cy="200" r="160" fill="url(#vestu-glow)" />
        )}

        {/* MODERN GEOMETRIC V SYMBOL */}
        <g id="modern-v-logo-group">
          {/* Left Arm: Sleek, tilted black/white slab with rounded ends */}
          <path
            d="M 125 100 
               C 125 88, 137 78, 150 78 
               L 182 78 
               C 195 78, 208 86, 222 106 
               L 300 220 
               C 314 240, 314 254, 300 274 
               L 262 328 
               C 248 348, 235 348, 222 328 
               L 137 206 
               C 125 186, 125 172, 125 152 
               Z"
            fill={leftArmColor}
          />

          {/* Right Arm: Skewed, parallel blue gradient slab */}
          <path
            d="M 268 214 
               C 264 202, 272 192, 285 192 
               L 354 112 
               C 364 100, 378 88, 396 88 
               L 418 88 
               C 428 88, 432 96, 426 106 
               L 326 250 
               C 316 264, 302 272, 288 272 
               L 268 272 
               C 258 272, 254 264, 258 254 
               Z"
            fill="url(#vestu-new-blue-grad)"
          />
        </g>
      </svg>

      {/* Brand Text labels below symbol */}
      {showText && (
        <div className="mt-3 select-none flex flex-col items-center">
          <h1 className="text-3xl font-black tracking-tight font-sans">
            <span className={textPrimaryColor}>Vestu</span>
            <span className="bg-gradient-to-r from-blue-500 to-indigo-500 bg-clip-text text-transparent">AI</span>
          </h1>
          <p className={`text-[9px] uppercase tracking-[0.25em] font-medium mt-1.5 ${subtextColor}`}>
            E-commerce de Moda Inteligente
          </p>
        </div>
      )}
    </div>
  );
}

interface SymbolProps {
  className?: string;
  size?: number;
  variant?: 'primary' | 'dark' | 'light';
}

export function VestuAiSymbol({ className = '', size = 36, variant = 'primary' }: SymbolProps) {
  const isLight = variant === 'light';
  
  // Choose colors based on the theme variant
  const leftArmColor = isLight ? '#0f172a' : '#ffffff';

  return (
    <svg
      viewBox="100 40 340 340"
      className={`shrink-0 ${className}`}
      style={{ width: size, height: size }}
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <defs>
        {/* Blue gradient for the right arm of the V */}
        <linearGradient id="sym-new-blue-grad" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#60a5fa" />
          <stop offset="50%" stopColor="#2563eb" />
          <stop offset="100%" stopColor="#1d4ed8" />
        </linearGradient>
      </defs>

      {/* Left Arm: Sleek, tilted black/white slab with rounded ends */}
      <path
        d="M 125 100 
           C 125 88, 137 78, 150 78 
           L 182 78 
           C 195 78, 208 86, 222 106 
           L 300 220 
           C 314 240, 314 254, 300 274 
           L 262 328 
           C 248 348, 235 348, 222 328 
           L 137 206 
           C 125 186, 125 172, 125 152 
           Z"
        fill={leftArmColor}
      />

      {/* Right Arm: Skewed, parallel blue gradient slab */}
      <path
        d="M 268 214 
           C 264 202, 272 192, 285 192 
           L 354 112 
           C 364 100, 378 88, 396 88 
           L 418 88 
           C 428 88, 432 96, 426 106 
           L 326 250 
           C 316 264, 302 272, 288 272 
           L 268 272 
           C 258 272, 254 264, 258 254 
           Z"
        fill="url(#sym-new-blue-grad)"
      />
    </svg>
  );
}
