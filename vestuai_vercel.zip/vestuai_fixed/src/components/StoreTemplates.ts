export interface FashionTemplate {
  id: string;
  name: string;
  style: string;
  className: string; // Tailwind wrapper class
  cardClass: string; // Card element class
  headerClass: string; // Header wrapper class
  fontFamily: string; // font style name
  primaryColor: string; // hex defaults
  accentColor: string;
}

export const TEMPLATES_LIST: FashionTemplate[] = [
  {
    id: 'luxe_noir',
    name: 'Luxe Noir',
    style: 'Dark luxury, high fashion editorial, gold accents, bold serif fonts',
    className: 'bg-[#121212] text-[#f5f5f5] min-h-screen font-serif',
    cardClass: 'bg-[#1a1a1a] border border-[#d4af37]/30 rounded-none shadow-2xl hover:border-[#d4af37] transition',
    headerClass: 'bg-[#121212]/90 border-b border-[#d4af37]/20 sticky top-0 z-50 backdrop-blur-md text-[#d4af37]',
    fontFamily: 'serif',
    primaryColor: '#121212',
    accentColor: '#d4af37'
  },
  {
    id: 'bloom_pastel',
    name: 'Bloom',
    style: 'Soft pastels, feminine, rounded cards, script + sans-serif pairing',
    className: 'bg-[#fff5f5] text-[#4a3535] min-h-screen font-sans',
    cardClass: 'bg-white rounded-3xl shadow-sm border border-[#ffe3e3] hover:shadow-lg transition-all',
    headerClass: 'bg-[#fff5f5]/90 border-b border-[#ffe3e3] sticky top-0 z-50 backdrop-blur-md text-[#b85a5a]',
    fontFamily: 'sans-serif',
    primaryColor: '#fff5f5',
    accentColor: '#ec4899'
  },
  {
    id: 'urban_edge',
    name: 'Urban Edge',
    style: 'Streetwear, dark + neon, grid layout, monospace font accents',
    className: 'bg-[#0f172a] text-[#f8fafc] min-h-screen font-mono',
    cardClass: 'bg-[#1e293b] border-2 border-[#10b981] hover:bg-[#10b981]/10 rounded-sm hover:-translate-y-1 transition-all',
    headerClass: 'bg-[#0f172a]/95 border-b-2 border-[#10b981] sticky top-0 z-50 text-[#10b981]',
    fontFamily: 'monospace',
    primaryColor: '#0f172a',
    accentColor: '#10b981'
  },
  {
    id: 'clean_minimal',
    name: 'Clean',
    style: 'Ultra-minimal white, generous spacing, thin font, no borders',
    className: 'bg-[#fafafa] text-[#171717] min-h-screen font-sans tracking-tight',
    cardClass: 'bg-white rounded-none border border-[#e5e5e5] hover:border-[#171717] transition-all duration-300',
    headerClass: 'bg-white/90 border-b border-[#e5e5e5] sticky top-0 z-50 text-[#171717]',
    fontFamily: 'sans-serif',
    primaryColor: '#ffffff',
    accentColor: '#171717'
  },
  {
    id: 'vibrant_pop',
    name: 'Pop',
    style: 'Maximalist colors, bold typography, overlapping elements, Gen-Z energy',
    className: 'bg-[#ffe600] text-black min-h-screen font-extrabold',
    cardClass: 'bg-white border-4 border-black shadow-[8px_8px_0px_0px_#000000] rounded-none hover:translate-x-1 hover:translate-y-1 transition-all',
    headerClass: 'bg-white border-b-4 border-black sticky top-0 z-50 text-black',
    fontFamily: 'sans-serif',
    primaryColor: '#ffe600',
    accentColor: '#ff007f'
  },
  {
    id: 'coastal_breeze',
    name: 'Coastal',
    style: 'Beach vibes, sand tones, wave-inspired dividers, relaxed layout',
    className: 'bg-[#f7f5f0] text-[#2c3e50] min-h-screen font-sans',
    cardClass: 'bg-white rounded-xl shadow-md border-b-4 border-[#d5cbb4] hover:shadow-xl transition-all',
    headerClass: 'bg-[#ebdcb9]/80 border-b border-[#d5cbb4] sticky top-0 z-50 backdrop-blur-md text-[#2c3e50]',
    fontFamily: 'sans-serif',
    primaryColor: '#ebdcb9',
    accentColor: '#3498db'
  },
  {
    id: 'botanical',
    name: 'Botanical',
    style: 'Nature-inspired, leaf motifs, earth tones, organic card shapes',
    className: 'bg-[#f4f7f4] text-[#1e2f1e] min-h-screen font-sans',
    cardClass: 'bg-white rounded-t-3xl rounded-br-3xl shadow-md hover:shadow-lg hover:border-[#2e7d32] border border-transparent transition-all',
    headerClass: 'bg-[#e8efe8] border-b border-[#2e7d32]/20 sticky top-0 z-50 text-[#2e7d32]',
    fontFamily: 'sans-serif',
    primaryColor: '#e8efe8',
    accentColor: '#2e7d32'
  },
  {
    id: 'retro_mod',
    name: 'Retro',
    style: '70s mod revival, warm terracotta + mustard, funky typography',
    className: 'bg-[#f9e9d6] text-[#692d19] min-h-screen font-serif',
    cardClass: 'bg-[#f6ebd1] rounded-2xl border-2 border-[#d36135] shadow-md hover:bg-[#ffd1a3] transition',
    headerClass: 'bg-[#d36135] sticky top-0 z-50 text-white border-b-2 border-[#692d19]',
    fontFamily: 'serif',
    primaryColor: '#d36135',
    accentColor: '#eea243'
  },
  {
    id: 'neon_night',
    name: 'Neon Night',
    style: 'Dark background, neon accents, cyberpunk grid lines',
    className: 'bg-[#05050a] text-[#e2e8f0] min-h-screen font-mono',
    cardClass: 'bg-[#0f0f1d] border border-[#f43f5e] shadow-[0_0_10px_rgba(244,63,94,0.3)] rounded-lg hover:shadow-[0_0_20px_rgba(244,63,94,0.6)] transition-all',
    headerClass: 'bg-[#05050a]/95 border-b border-[#f43f5e] sticky top-0 z-50 text-[#f43f5e]',
    fontFamily: 'monospace',
    primaryColor: '#05050a',
    accentColor: '#f43f5e'
  },
  {
    id: 'editorial_mag',
    name: 'Editorial',
    style: 'Magazine layout, asymmetric grids, pull quotes, serif headlines',
    className: 'bg-white text-[#1c1c1c] min-h-screen font-serif p-0',
    cardClass: 'bg-[#fafafa] rounded-none border border-black hover:bg-neutral-50 transition-colors',
    headerClass: 'bg-white border-b-2 border-black sticky top-0 z-50 text-black px-6 py-4',
    fontFamily: 'serif',
    primaryColor: '#ffffff',
    accentColor: '#000000'
  },
  {
    id: 'soft_blush',
    name: 'Blush',
    style: 'Blush pink + white, lingerie/intimate feel, soft shadows',
    className: 'bg-[#fff0f3] text-[#5c3d46] min-h-screen font-sans',
    cardClass: 'bg-white/80 rounded-2xl shadow-xl shadow-[#ffccd5]/10 hover:shadow-[#ffccd5]/30 border border-[#ffccd5] transition-all',
    headerClass: 'bg-[#fff0f3] border-b border-[#ffccd5] sticky top-0 z-50 text-[#c9184a]',
    fontFamily: 'sans-serif',
    primaryColor: '#fff0f3',
    accentColor: '#ff4d6d'
  },
  {
    id: 'monochrome',
    name: 'Mono',
    style: 'Black and white only, strong contrast, architectural spacing',
    className: 'bg-[#ffffff] text-[#000000] min-h-screen font-sans',
    cardClass: 'bg-[#ffffff] rounded-none border border-black hover:bg-black hover:text-white duration-300 transition-all',
    headerClass: 'bg-[#ffffff] border-b-2 border-black sticky top-0 z-50 text-black',
    fontFamily: 'sans-serif',
    primaryColor: '#ffffff',
    accentColor: '#000000'
  },
  {
    id: 'art_deco',
    name: 'Deco',
    style: 'Art deco geometry, gold lines, midnight blue, ornate frames',
    className: 'bg-[#0f1d36] text-[#e4fbff] min-h-screen font-serif',
    cardClass: 'bg-[#1f3050] border-2 border-[#c5a880] shadow-md rounded-none hover:shadow-cyan-100 transition-all',
    headerClass: 'bg-[#0f1d36] border-b-2 border-[#c5a880] sticky top-0 z-50 text-[#c5a880]',
    fontFamily: 'serif',
    primaryColor: '#0f1d36',
    accentColor: '#c5a880'
  },
  {
    id: 'sporty_fit',
    name: 'Active',
    style: 'Fitness/athletic, bold diagonal lines, electric blue + black',
    className: 'bg-[#0a0a0c] text-[#f4f4f5] min-h-screen font-sans font-bold',
    cardClass: 'bg-[#18181c] border-l-4 border-l-[#2563eb] rounded-r-lg hover:bg-neutral-800 transition',
    headerClass: 'bg-[#0a0a0c] border-b border-neutral-800 sticky top-0 z-50 text-[#2563eb]',
    fontFamily: 'sans-serif',
    primaryColor: '#0a0a0c',
    accentColor: '#2563eb'
  },
  {
    id: 'cottagecore',
    name: 'Cottage',
    style: 'Cozy floral, linen textures, vintage feel, handwritten font',
    className: 'bg-[#f5ebe0] text-[#4f3b25] min-h-screen font-serif',
    cardClass: 'bg-[#e3d5ca] rounded-2xl shadow-sm border border-[#d5bdaf]/50 hover:shadow-lg transition-all',
    headerClass: 'bg-[#f5ebe0]/90 border-b border-[#e3d5ca] sticky top-0 z-50 text-[#4f3b25]',
    fontFamily: 'serif',
    primaryColor: '#f5ebe0',
    accentColor: '#a3b18a'
  },
  {
    id: 'sleek_tech',
    name: 'Sleek',
    style: 'Tech-inspired, glassmorphism cards, cool blues, data-clean layout',
    className: 'bg-[#eef2f6] text-[#1e293b] min-h-screen font-sans',
    cardClass: 'bg-white/70 backdrop-blur-md rounded-2xl shadow-md border border-white hover:border-[#3b82f6]/30 transition-all duration-300',
    headerClass: 'bg-white/80 border-b border-[#e2e8f0] sticky top-0 z-50 backdrop-blur-md text-[#2563eb]',
    fontFamily: 'sans-serif',
    primaryColor: '#eef2f6',
    accentColor: '#3b82f6'
  },
  {
    id: 'boho_wanderer',
    name: 'Boho',
    style: 'Bohemian, warm amber + rust, macramé-inspired borders',
    className: 'bg-[#fbf4eb] text-[#5c3e35] min-h-screen font-sans',
    cardClass: 'bg-white rounded-3xl border border-[#ebd8c3] hover:shadow-lg shadow-[#5c3e35]/5 transition',
    headerClass: 'bg-[#fbf4eb] border-b border-[#ebd8c3] sticky top-0 z-50 text-[#c07a51]',
    fontFamily: 'sans-serif',
    primaryColor: '#fbf4eb',
    accentColor: '#c07a51'
  },
  {
    id: 'sakura',
    name: 'Sakura',
    style: 'Japanese minimalism, cherry blossom pinks, clean grid, kanji-inspired spacing',
    className: 'bg-[#fff5f6] text-[#4a2e30] min-h-screen font-sans tracking-widest',
    cardClass: 'bg-white rounded-none border border-[#fbcdd3] hover:border-[#d90429] duration-300 transition-all',
    headerClass: 'bg-[#fff5f6] border-b border-[#fbcdd3] sticky top-0 z-50 text-[#d90429]',
    fontFamily: 'sans-serif',
    primaryColor: '#fff5f6',
    accentColor: '#d90429'
  },
  {
    id: 'jewel_tones',
    name: 'Jewel',
    style: 'Deep jewel tones (emerald, sapphire, amethyst), rich textures',
    className: 'bg-[#0d1b15] text-[#d1fae5] min-h-screen font-serif',
    cardClass: 'bg-[#112d21] border border-[#047857]/50 hover:bg-[#065f46]/40 rounded-xl transition',
    headerClass: 'bg-[#0d1b15] border-b border-[#047857]/30 sticky top-0 z-50 text-[#10b981]',
    fontFamily: 'serif',
    primaryColor: '#0d1b15',
    accentColor: '#10b981'
  },
  {
    id: 'gradient_flow',
    name: 'Flow',
    style: 'Fluid gradients, morphing blobs, modern but soft',
    className: 'bg-[#f3f4f6] text-[#111827] min-h-screen font-sans',
    cardClass: 'bg-white rounded-[2rem] shadow-xl hover:shadow-[#6366f1]/10 shadow-[#6366f1]/5 transition-all duration-300 border border-neutral-100',
    headerClass: 'bg-[#f3f4f6] border-b border-neutral-200 sticky top-0 z-50 text-[#6366f1]',
    fontFamily: 'sans-serif',
    primaryColor: '#f3f4f6',
    accentColor: '#6366f1'
  },
  {
    id: 'brutalist',
    name: 'Raw',
    style: 'Brutalist web design, stark borders, oversized type, raw layout',
    className: 'bg-white text-black min-h-screen font-mono p-4',
    cardClass: 'bg-white border-4 border-black rounded-none shadow-[4px_4px_0_0_rgba(0,0,0,1)] hover:shadow-none hover:translate-x-1 hover:translate-y-1 transition-all',
    headerClass: 'bg-white border-4 border-black text-black select-none px-6 py-2 sticky top-0 z-50',
    fontFamily: 'monospace',
    primaryColor: '#ffffff',
    accentColor: '#000000'
  },
  {
    id: 'sunset_warm',
    name: 'Sunset',
    style: 'Warm orange gradient, golden hour feeling, rounded everything',
    className: 'bg-[#fffcf7] text-[#4f1e00] min-h-screen font-sans',
    cardClass: 'bg-white rounded-2xl shadow-xl hover:scale-105 transition border border-[#fed7aa]',
    headerClass: 'bg-[#ffedd5] border-b border-[#fed7aa] sticky top-0 z-50 text-[#c2410c]',
    fontFamily: 'sans-serif',
    primaryColor: '#ffedd5',
    accentColor: '#ea580c'
  },
  {
    id: 'ice_queen',
    name: 'Ice',
    style: 'Cool blues + white, crystalline feel, sharp geometric elements',
    className: 'bg-[#fafcfe] text-[#1e3a5f] min-h-screen font-sans',
    cardClass: 'bg-[#ffffff] rounded-lg shadow-sm border border-[#bfdbfe] hover:border-[#1e3a5f] transition-all',
    headerClass: 'bg-[#eff6ff] border-b border-[#bfdbfe] sticky top-0 z-50 text-[#1e3a5f]',
    fontFamily: 'sans-serif',
    primaryColor: '#eff6ff',
    accentColor: '#3b82f6'
  },
  {
    id: 'heritage_craft',
    name: 'Heritage',
    style: 'Artisan/craft feel, natural textures, stamps and labels aesthetic',
    className: 'bg-[#f4efe8] text-[#3e2c1c] min-h-screen font-serif',
    cardClass: 'bg-white rounded-none border border-b-4 border-r-4 border-[#8b5a2b] shadow-sm hover:translate-y-0.5 transition',
    headerClass: 'bg-[#e9ded0] border-b-2 border-[#8b5a2b] sticky top-0 z-50 text-[#8b5a2b]',
    fontFamily: 'serif',
    primaryColor: '#e9ded0',
    accentColor: '#8b5a2b'
  },
  {
    id: 'future_bold',
    name: 'Future',
    style: 'Bold typography-first, oversized headers, minimal color, futuristic',
    className: 'bg-black text-white min-h-screen font-sans tracking-tighter',
    cardClass: 'bg-[#111111] rounded-none border-b-2 border-white/20 hover:border-white transition-all',
    headerClass: 'bg-black border-b border-white/10 sticky top-0 z-50 text-white font-black',
    fontFamily: 'sans-serif',
    primaryColor: '#000000',
    accentColor: '#ffffff'
  }
];
