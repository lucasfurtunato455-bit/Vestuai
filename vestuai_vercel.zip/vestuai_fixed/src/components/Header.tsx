import { ArrowRight } from 'lucide-react';
import { VestuAiSymbol } from './VestuAiLogo';

interface HeaderProps {
  onNavigate: (route: string) => void;
}

export function Header({ onNavigate }: HeaderProps) {
  return (
    <header className="sticky top-0 z-50 w-full border-b border-[#0f172a]/10 bg-[#fafafa]/80 backdrop-blur-md">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-4 sm:px-6 lg:px-8">
        {/* Logo */}
        <div 
          onClick={() => onNavigate('/')} 
          className="flex cursor-pointer items-center space-x-2 text-xl font-black tracking-tight text-[#0f172a]"
        >
          <VestuAiSymbol size={32} variant="light" />
          <span className="font-sans">Vestu<span className="text-[#2563eb]">AI</span></span>
        </div>

        {/* Desktop Navigation */}
        <nav className="hidden md:flex items-center space-x-8 text-sm font-medium text-slate-600">
          <a href="#funcionalidades" className="hover:text-[#6366f1] transition-colors">Funcionalidades</a>
          <a href="#modelos" className="hover:text-[#6366f1] transition-colors">Pre-Visualização</a>
          <a href="#precos" className="hover:text-[#6366f1] transition-colors">Preços & Planos</a>
          <a href="#faq" className="hover:text-[#6366f1] transition-colors">FAQ</a>
        </nav>

        {/* Actions */}
        <div className="flex items-center space-x-3">
          <button 
            onClick={() => onNavigate('/entrar')} 
            className="text-sm font-semibold text-slate-700 hover:text-[#6366f1] px-3 py-2 transition-all cursor-pointer"
          >
            Entrar
          </button>
          <button 
            onClick={() => onNavigate('/cadastro')} 
            className="inline-flex items-center justify-center space-x-2 rounded-xl bg-[#0f172a] px-4 py-2.5 text-xs font-semibold text-white hover:bg-[#6366f1] shadow-sm hover:shadow transition-all cursor-pointer"
          >
            <span>Criar loja grátis</span>
            <ArrowRight className="h-3 w-3" />
          </button>
        </div>
      </div>
    </header>
  );
}
