import { VestuAiSymbol } from './VestuAiLogo';

export function Footer() {
  return (
    <footer className="w-full bg-[#1e293b] text-slate-300 py-12 border-t border-slate-800">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 grid grid-cols-1 md:grid-cols-4 gap-8">
        <div className="md:col-span-2 space-y-4">
          <div className="flex items-center space-x-2 text-xl font-black text-white">
            <VestuAiSymbol size={32} variant="dark" />
            <span>Vestu<span className="text-[#2563eb]">AI</span></span>
          </div>
          <p className="text-sm text-slate-400 max-w-sm">
            A primeira plataforma brasileira que une inteligência artificial generativa com a simplicidade das vendas por WhatsApp para o sucesso do varejo e atacado de moda.
          </p>
          <div className="text-xs text-slate-500 pt-2">
            © 2026 VestuAI. Todos os direitos reservados.
          </div>
        </div>

        <div>
          <h4 className="text-sm font-semibold text-white mb-4">Legal</h4>
          <ul className="space-y-2.5 text-sm text-slate-400">
            <li><a href="#" className="hover:text-white transition-colors">Termos de Uso</a></li>
            <li><a href="#" className="hover:text-white transition-colors">Política de Privacidade</a></li>
            <li><a href="#" className="hover:text-white transition-colors">Política de Reembolso</a></li>
            <li><a href="#" className="hover:text-white transition-colors">Trabalhe Conosco</a></li>
          </ul>
        </div>

        <div>
          <h4 className="text-sm font-semibold text-white mb-4">Suporte</h4>
          <ul className="space-y-2.5 text-sm text-slate-400">
            <li><a href="#" className="hover:text-white transition-colors">Central de Ajuda</a></li>
            <li><a href="#" className="hover:text-white transition-colors">WhatsApp Suporte</a></li>
            <li><a href="#" className="hover:text-white transition-colors">Status do Servidor</a></li>
            <li><a href="#" className="hover:text-white transition-colors">Contato Comercial</a></li>
          </ul>
        </div>
      </div>
    </footer>
  );
}
