import { useState, useEffect } from 'react';
import { 
  Shield, 
  Store, 
  Users, 
  DollarSign, 
  Sparkles, 
  TrendingUp, 
  Power, 
  Trash2, 
  Eye, 
  ArrowLeftRight, 
  Clock, 
  Search, 
  Filter, 
  CheckCircle,
  AlertTriangle,
  ArrowRight
} from 'lucide-react';
import { User, Store as StoreType, AiUsageLog } from '../types';

interface SuperadminPanelProps {
  onBackToApp: () => void;
  onImpersonate: (token: string, user: User, store: StoreType | null) => void;
}

export function SuperadminPanel({ onBackToApp, onImpersonate }: SuperadminPanelProps) {
  const [stats, setStats] = useState<any>(null);
  const [stores, setStores] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [planFilter, setPlanFilter] = useState('');
  const [statusFilter, setStatusFilter] = useState('');
  const [feedback, setFeedback] = useState<string | null>(null);

  // Load superadmin dashboard info
  useEffect(() => {
    loadAdminData();
  }, []);

  async function loadAdminData() {
    setLoading(true);
    try {
      const token = localStorage.getItem('vestu_token') || '';
      
      const statsRes = await fetch('/api/admin/stats', {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      const statsData = await statsRes.json();
      setStats(statsData);

      const storesRes = await fetch('/api/admin/stores', {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      const storesData = await storesRes.json();
      setStores(storesData.stores || []);
    } catch (e) {
      console.error("Superadmin load failed", e);
    } finally {
      setLoading(false);
    }
  }

  // Edit store plan or status
  const handleUpdateStore = async (storeId: string, payload: any) => {
    try {
      const token = localStorage.getItem('vestu_token') || '';
      const res = await fetch(`/api/admin/stores/${storeId}`, {
        method: 'PUT',
        headers: { 
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify(payload)
      });
      if (res.ok) {
        setFeedback("Loja atualizada com sucesso!");
        loadAdminData();
        setTimeout(() => setFeedback(null), 3000);
      }
    } catch (err) {}
  };

  // Impersonate logged lojista
  const handleImpersonateClick = async (userId: string) => {
    try {
      const token = localStorage.getItem('vestu_token') || '';
      const res = await fetch(`/api/admin/impersonate/${userId}`, {
        method: 'POST',
        headers: { 'Authorization': `Bearer ${token}` }
      });
      if (res.ok) {
        const data = await res.json();
        // Trigger parent impersonate callback
        onImpersonate(data.token, data.user, data.store);
      }
    } catch (e) {}
  };

  // Filtered lists
  const filteredStores = stores.filter(item => {
    const s = item.store as StoreType;
    const o = item.owner as User;
    
    const matchesSearch = s.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          (o && o.name.toLowerCase().includes(searchTerm.toLowerCase())) ||
                          s.slug.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesPlan = !planFilter || s.planId === planFilter;
    const matchesStatus = !statusFilter || s.status === statusFilter;

    return matchesSearch && matchesPlan && matchesStatus;
  });

  if (loading) {
    return (
      <div className="flex h-screen items-center justify-center bg-slate-900 text-white">
        <div className="text-center space-y-4">
          <div className="mx-auto h-12 w-12 animate-spin rounded-full border-4 border-[#6366f1] border-t-transparent" />
          <p className="text-sm">Carregando painel superadministrador VestuAI...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans">
      
      {/* Superadmin Header */}
      <header className="border-b border-slate-800 bg-slate-900 py-4 px-6 flex items-center justify-between shadow-md">
        <div className="flex items-center space-x-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-tr from-rose-500 to-amber-500 text-white shadow-lg">
            <Shield className="h-5 w-5" />
          </div>
          <div>
            <h1 className="text-lg font-black tracking-tight flex items-center space-x-1.5">
              <span>VestuAI Master Panel</span>
              <span className="text-[9px] uppercase tracking-widest bg-amber-500/25 text-amber-400 px-2 py-0.5 rounded-full font-mono font-bold">ROOT</span>
            </h1>
            <p className="text-xs text-slate-400">Controle operacional e financeiro do multi-inquilinato SaaS.</p>
          </div>
        </div>

        <button 
          onClick={onBackToApp}
          className="rounded-xl border border-slate-700 bg-slate-800 px-4 py-2 text-xs font-bold text-slate-300 hover:bg-slate-700 hover:text-white transition cursor-pointer"
        >
          Sair do Admin
        </button>
      </header>

      {fdbkNotice(feedback)}

      <main className="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6 lg:p-8 space-y-8">
        
        {/* Core Financial & AI KPI Widgets */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          
          <div className="rounded-3xl border border-slate-800 bg-slate-900 p-6 flex items-center justify-between shadow-xl">
            <div className="space-y-1">
              <span className="text-xs font-medium text-slate-400 uppercase tracking-widest">Plano Mensal (MRR)</span>
              <h3 className="text-2xl font-black text-rose-400">R$ {stats?.totalMRR?.toFixed(2)}</h3>
              <p className="text-[10px] text-slate-500 leading-snug">Estimativa recorrente bruta atual</p>
            </div>
            <div className="h-12 w-12 rounded-2xl bg-rose-500/15 flex items-center justify-center text-rose-400">
              <DollarSign className="h-6 w-6" />
            </div>
          </div>

          <div className="rounded-3xl border border-slate-800 bg-slate-900 p-6 flex items-center justify-between shadow-xl">
            <div className="space-y-1">
              <span className="text-xs font-medium text-slate-400 uppercase tracking-widest">Taxas Capturadas</span>
              <h3 className="text-2xl font-black text-emerald-400">R$ {stats?.totalPlatformFees?.toFixed(2)}</h3>
              <p className="text-[10px] text-slate-500 leading-snug">Cobrança de comissões por checkout</p>
            </div>
            <div className="h-12 w-12 rounded-2xl bg-emerald-500/15 flex items-center justify-center text-emerald-400">
              <TrendingUp className="h-6 w-6" />
            </div>
          </div>

          <div className="rounded-3xl border border-slate-800 bg-slate-900 p-6 flex items-center justify-between shadow-xl">
            <div className="space-y-1">
              <span className="text-xs font-medium text-slate-400 uppercase tracking-widest">Lojas Registradas</span>
              <h3 className="text-2xl font-black text-indigo-400">{stats?.storesLength}</h3>
              <div className="flex space-x-2 text-[10px] text-slate-500">
                <span>{stats?.activeCount} Ativas</span>
                <span>•</span>
                <span>{stats?.suspendedCount} Suspensas</span>
              </div>
            </div>
            <div className="h-12 w-12 rounded-2xl bg-indigo-500/15 flex items-center justify-center text-indigo-400">
              <Store className="h-6 w-6" />
            </div>
          </div>

          <div className="rounded-3xl border border-slate-800 bg-slate-900 p-6 flex items-center justify-between shadow-xl">
            <div className="space-y-1">
              <span className="text-xs font-medium text-slate-400 uppercase tracking-widest">Gerações de IA</span>
              <h3 className="text-2xl font-black text-[#a855f7]">{stats?.totalAiGenerations}</h3>
              <p className="text-[10px] text-slate-500 leading-snug">Imagens e descrições na plataforma</p>
            </div>
            <div className="h-12 w-12 rounded-2xl bg-[#a855f7]/15 flex items-center justify-center text-[#a855f7]">
              <Sparkles className="h-6 w-6" />
            </div>
          </div>

        </div>

        {/* Dynamic graphics and reports layout */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          
          {/* Revenue share visually represented */}
          <div className="lg:col-span-1 rounded-3xl border border-slate-800 bg-slate-900 p-6 space-y-6 flex flex-col justify-between shadow-xl">
            <div>
              <h4 className="text-sm font-bold tracking-tight text-white flex items-center space-x-1.5">
                <span>Participação de Assinaturas</span>
              </h4>
              <p className="text-xs text-slate-400">Divisão de receita por tipo de plano ativo hoje.</p>
            </div>

            {/* Custom vector donut rendering visually appealing */}
            <div className="flex items-center justify-center py-4">
              <svg className="w-36 h-36 transform -rotate-90">
                <circle cx="72" cy="72" r="50" fill="transparent" stroke="#1e293b" strokeWidth="16" />
                <circle cx="72" cy="72" r="50" fill="transparent" stroke="#6366f1" strokeWidth="16" strokeDasharray="314.15" strokeDashoffset="78.5" />
                <circle cx="72" cy="72" r="50" fill="transparent" stroke="#8b5cf6" strokeWidth="16" strokeDasharray="314.15" strokeDashoffset="157" />
                <circle cx="72" cy="72" r="50" fill="transparent" stroke="#ec4899" strokeWidth="16" strokeDasharray="314.15" strokeDashoffset="235.6" />
              </svg>
            </div>

            <div className="grid grid-cols-2 gap-2 text-[10px] text-slate-400 border-t border-slate-800 pt-4">
              <div className="flex items-center space-x-1.5">
                <div className="h-2 w-2 rounded-full bg-[#6366f1]" />
                <span>Plano Pro (R$ 50)</span>
              </div>
              <div className="flex items-center space-x-1.5">
                <div className="h-2 w-2 rounded-full bg-[#8b5cf6]" />
                <span>Pro Max (R$ 100)</span>
              </div>
              <div className="flex items-center space-x-1.5">
                <div className="h-2 w-2 rounded-full bg-[#ec4899]" />
                <span>Plano Ultra (R$ 350)</span>
              </div>
              <div className="flex items-center space-x-1.5">
                <div className="h-2 w-2 rounded-full bg-[#64748b]" />
                <span>Grátis (R$ 0)</span>
              </div>
            </div>
          </div>

          {/* Audit trace actions */}
          <div className="lg:col-span-2 rounded-3xl border border-slate-800 bg-slate-900 p-6 space-y-4 shadow-xl flex flex-col justify-between">
            <div>
              <h4 className="text-sm font-bold tracking-tight text-white flex items-center space-x-1.5">
                <span>Histórico Operacional Recente</span>
              </h4>
              <p className="text-xs text-slate-400">Atividades de geração de imagens com IA monitoradas na plataforma.</p>
            </div>

            <div className="flex-1 space-y-3 max-h-[220px] overflow-y-auto pr-1">
              {stats?.recentLogs?.length === 0 ? (
                <p className="text-xs text-slate-500 italic py-6 text-center">Nenhuma inteligência artificial acionada recentemente.</p>
              ) : (
                stats?.recentLogs?.map((log: AiUsageLog) => (
                  <div key={log.id} className="text-xs p-3 rounded-2xl bg-slate-950 border border-slate-800/50 flex items-start justify-between space-x-3">
                    <div className="space-y-1 font-mono">
                      <div className="flex items-center space-x-1 text-slate-300">
                        <span className="text-slate-400 font-bold uppercase shrink-0">Loja ID:</span>
                        <span className="truncate max-w-[80px] text-indigo-400">{log.storeId}</span>
                        <span className="text-slate-600 shrink-0">|</span>
                        <span className="bg-purple-600/20 text-purple-400 px-1.5 py-0.5 rounded text-[9px] uppercase shrink-0 font-bold">{log.type}</span>
                      </div>
                      <p className="text-[10px] text-slate-500 line-clamp-1">{log.prompt}</p>
                    </div>
                    <span className="text-[10px] text-slate-500 whitespace-nowrap shrink-0">{new Date(log.createdAt).toLocaleTimeString()}</span>
                  </div>
                ))
              )}
            </div>
            
            <p className="text-[10px] text-slate-500 italic">Logs auditados e mantidos por 30 dias para faturamento de servidores fal.ai.</p>
          </div>

        </div>

        {/* Stores Master directory Table lists */}
        <div className="rounded-3xl border border-slate-800 bg-slate-900 p-6 space-y-6 shadow-xl">
          
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
            <div>
              <h3 className="text-base font-bold text-white">Inquilinos e Lojas Registradas</h3>
              <p className="text-xs text-slate-400">Gerencie as assinaturas comerciais, suspenda contas ou navegue neles como lojista.</p>
            </div>

            <div className="flex flex-wrap items-center gap-3">
              <input 
                type="text" 
                placeholder="Busque por loja ou dono..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="rounded-2xl border border-slate-800 bg-slate-950 px-3 py-2 text-xs text-slate-300 outline-none focus:border-indigo-500"
              />

              <select 
                value={planFilter}
                onChange={(e) => setPlanFilter(e.target.value)}
                className="rounded-2xl border border-slate-800 bg-slate-950 px-3 py-2 text-xs text-slate-400 outline-none"
              >
                <option value="">Todos Planos</option>
                <option value="free">Grátis</option>
                <option value="pro">Pro</option>
                <option value="pro_max">Pro Max</option>
                <option value="ultra">Ultra</option>
              </select>

              <select 
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
                className="rounded-2xl border border-slate-800 bg-slate-950 px-3 py-2 text-xs text-slate-400 outline-none"
              >
                <option value="">Todos Status</option>
                <option value="active">Ativas</option>
                <option value="suspended">Suspensas</option>
              </select>
            </div>
          </div>

          <div className="overflow-x-auto w-full border border-slate-800 rounded-3xl">
            <table className="w-full text-xs text-left text-slate-300 border-collapse">
              <thead className="bg-slate-950 text-slate-400 uppercase text-[10px] font-mono border-b border-slate-800">
                <tr>
                  <th className="p-4">Identificação Loja</th>
                  <th className="p-4">Proprietário / Email</th>
                  <th className="p-4 text-center">Plano Ativo</th>
                  <th className="p-4 text-center">Cadastros</th>
                  <th className="p-4 text-center">Cliques / Visitas</th>
                  <th className="p-4 text-center">Vendas Gerais</th>
                  <th className="p-4 text-center">Status</th>
                  <th className="p-4 text-right">Controles</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800">
                {filteredStores.map(item => {
                  const s = item.store as StoreType;
                  const o = item.owner as User;
                  
                  return (
                    <tr key={s.id} className="hover:bg-slate-900/50">
                      
                      <td className="p-4">
                        <p className="font-bold text-white">{s.name}</p>
                        <p className="text-[10px] text-slate-500 font-mono">slug: {s.slug}</p>
                        {s.customDomain && (
                          <span className="text-[9px] text-[#6366f1] font-bold font-mono">{s.customDomain}</span>
                        )}
                      </td>

                      <td className="p-4">
                        <p>{s.ownerName}</p>
                        <p className="text-[10px] text-slate-500">{o?.email || s.email}</p>
                      </td>

                      <td className="p-4 text-center">
                        <span className={`px-2 py-0.5 rounded text-[9px] font-bold uppercase ${
                          s.planId === 'ultra' ? 'bg-pink-500/20 text-pink-400 border border-pink-500/30' :
                          s.planId === 'pro_max' ? 'bg-purple-500/20 text-purple-400 border border-purple-500/30' :
                          s.planId === 'pro' ? 'bg-indigo-500/20 text-indigo-400 border border-indigo-500/30' :
                          'bg-slate-500/20 text-slate-400'
                        }`}>
                          {s.planId}
                        </span>
                      </td>

                      <td className="p-4 text-center text-slate-400 font-mono">
                        {item.productsCount} produtos
                      </td>

                      <td className="p-4 text-center text-slate-400 font-mono">
                         {item.clicks30d} <span className="opacity-50">/</span> {item.visits30d}
                      </td>

                      <td className="p-4 text-center space-y-0.5">
                        <p className="font-bold text-emerald-400 font-mono">R$ {item.estimatedVolume?.toFixed(2)}</p>
                        <p className="text-[9px] text-slate-500">Comissão: R$ {item.feesCaptured?.toFixed(2)}</p>
                      </td>

                      <td className="p-4 text-center">
                        <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                          s.status === 'active' 
                            ? 'bg-emerald-500/10 text-emerald-400' 
                            : 'bg-rose-500/10 text-rose-400'
                        }`}>
                          {s.status === 'active' ? 'Ativo' : 'Suspenso'}
                        </span>
                      </td>

                      <td className="p-4 text-right">
                        <div className="flex items-center justify-end space-x-2.5">
                          {/* Impersonation toggle */}
                          {o && (
                            <button 
                              onClick={() => handleImpersonateClick(o.id)}
                              title="Impersonificar lojista (Login como dono)"
                              className="p-1.5 rounded-lg bg-slate-800 text-amber-400 hover:bg-amber-500 hover:text-black transition cursor-pointer"
                            >
                              <ArrowLeftRight className="h-4 w-4" />
                            </button>
                          )}

                          {/* Plan toggler select */}
                          <select 
                            value={s.planId}
                            onChange={(e) => handleUpdateStore(s.id, { planId: e.target.value })}
                            className="bg-slate-950 border border-slate-800 rounded px-1.5 py-1 text-[10px] outline-none"
                          >
                            <option value="free">Mudar para Grátis</option>
                            <option value="pro">Pro</option>
                            <option value="pro_max">Pro Max</option>
                            <option value="ultra">Ultra</option>
                          </select>

                          {/* Suspend block toggle */}
                          <button 
                            onClick={() => handleUpdateStore(s.id, { status: s.status === 'active' ? 'suspended' : 'active' })}
                            className={`p-1.5 rounded-lg transition cursor-pointer ${
                              s.status === 'active' 
                                ? 'bg-rose-950/40 text-rose-400 hover:bg-rose-500 hover:text-white' 
                                : 'bg-emerald-950/40 text-emerald-400 hover:bg-emerald-500 hover:text-white'
                            }`}
                            title={s.status === 'active' ? 'Suspender Loja' : 'Reativar Loja'}
                          >
                            <Power className="h-4 w-4" />
                          </button>
                        </div>
                      </td>

                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

        </div>

      </main>

    </div>
  );
}

function fdbkNotice(feedback: string | null) {
  if (!feedback) return null;
  return (
    <div className="bg-emerald-500 text-white p-3 text-center text-xs font-bold animate-ping-once">
      ✓ {feedback}
    </div>
  );
}
