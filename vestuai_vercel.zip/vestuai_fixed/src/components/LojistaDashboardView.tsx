import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { VestuAiSymbol, VestuAiLogo } from './VestuAiLogo';
import { 
  LayoutDashboard, 
  Package, 
  Layers, 
  Sparkles, 
  Palette, 
  Megaphone, 
  BarChart2, 
  Star, 
  Settings, 
  Copy, 
  ExternalLink, 
  CheckSquare, 
  Plus, 
  PlusCircle, 
  ChevronRight, 
  ArrowLeft, 
  FileText, 
  StarHalf, 
  Video, 
  Eye, 
  Lock, 
  Compass, 
  Upload, 
  Image as ImageIcon,
  Check,
  Percent,
  Trash2,
  AlertTriangle,
  Globe,
  X
} from 'lucide-react';
import { Store, Product, Collection, Order, Review, AiUsageLog } from '../types';
import { TEMPLATES_LIST } from './StoreTemplates';

interface LojistaDashboardViewProps {
  store: Store;
  user: any;
  onLogout: () => void;
  onRefreshSession: () => void;
  onChangeView: (view: string) => void;
  onNavigateToStorefront: (slug: string) => void;
}

export function LojistaDashboardView({ 
  store, 
  user, 
  onLogout, 
  onRefreshSession, 
  onChangeView,
  onNavigateToStorefront
}: LojistaDashboardViewProps) {
  const [activeTab, setActiveTab] = useState('visão-geral');
  const [metrics, setMetrics] = useState<any>(null);
  const [products, setProducts] = useState<Product[]>([]);
  const [collections, setCollections] = useState<Collection[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [reviews, setReviews] = useState<Review[]>([]);
  const [aiLogs, setAiLogs] = useState<AiUsageLog[]>([]);
  const [loading, setLoading] = useState(true);

  // New product form states
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [isAddingProduct, setIsAddingProduct] = useState(false);
  const [pName, setPName] = useState('');
  const [pDescription, setPDescription] = useState('');
  const [pPrice, setPPrice] = useState('');
  const [pSalePrice, setPSalePrice] = useState('');
  const [pWholesalePrice, setPWholesalePrice] = useState('');
  const [pWholesaleMinQty, setPWholesaleMinQty] = useState('');
  const [pCostPrice, setPCostPrice] = useState('');
  const [pStock, setPStock] = useState('20');
  const [pCategory, setPCategory] = useState('Blusas');
  const [pTags, setPTags] = useState('');
  const [pIsFeatured, setPIsFeatured] = useState(false);
  const [pIsPromotion, setPIsPromotion] = useState(false);
  const [pPhotos, setPPhotos] = useState<string[]>([
    'https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?auto=format&fit=crop&w=600&q=80'
  ]);
  const [photoUrlInput, setPhotoUrlInput] = useState('');
  const [isDragActive, setIsDragActive] = useState(false);

  // Claude Helper states
  const [aiDescOptions, setAiDescOptions] = useState<string[]>([]);
  const [aiDescLoading, setAiDescLoading] = useState(false);

  // AI Studio states
  const [aiStyle, setAiStyle] = useState('Modelo UGC feminino');
  const [aiScenario, setAiScenario] = useState('Estúdio branco minimalista');
  const [aiCustomSec, setAiCustomSec] = useState('');
  const [aiPose, setAiPose] = useState('Em pé frontal');
  const [aiExpression, setAiExpression] = useState('Sorrindo');
  const [aiImageStatus, setAiImageStatus] = useState<string | null>(null);
  const [aiResultUrl, setAiResultUrl] = useState<string | null>(null);
  const [aiStudioPhoto, setAiStudioPhoto] = useState<string>('');

  // Video Generator state
  const [showVideoModal, setShowVideoModal] = useState(false);

  // Customizer state
  const [stName, setStName] = useState(store.name);
  const [stPhone, setStPhone] = useState(store.phone);
  const [stLogo, setStLogo] = useState(store.logoUrl || '');
  const [stBanner, setStBanner] = useState(store.bannerUrl || '');
  const [stPrimary, setStPrimary] = useState(store.primaryColor);
  const [stAccent, setStAccent] = useState(store.accentColor);
  const [stTemplate, setStTemplate] = useState(store.templateId);
  const [stGateEnabled, setStGateEnabled] = useState(store.gateEnabled);
  const [stDomain, setStDomain] = useState(store.customDomain || '');
  const [stAddress, setStAddress] = useState(store.physicalAddress || '');

  // Feedbacks
  const [feedback, setFeedback] = useState<string | null>(null);
  const [errFeedback, setErrFeedback] = useState<string | null>(null);

  // Load Lojista Workspace Data — once on mount; explicit refresh when data changes
  useEffect(() => {
    loadLojistaData();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function loadLojistaData() {
    setLoading(true);
    try {
      const token = localStorage.getItem('vestu_token') || '';
      
      const metricsRes = await fetch('/api/dashboard/analytics', {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      const mData = await metricsRes.json();
      setMetrics(mData);

      const productsRes = await fetch('/api/dashboard/products', {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      const pData = await productsRes.json();
      setProducts(pData.products || []);

      const collsRes = await fetch('/api/dashboard/collections', {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      const cData = await collsRes.json();
      setCollections(cData.collections || []);

      const ordersRes = await fetch('/api/dashboard/orders', {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      const oData = await ordersRes.json();
      setOrders(oData.orders || []);

      const revsRes = await fetch('/api/dashboard/reviews', {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      const rData = await revsRes.json();
      setReviews(rData.reviews || []);

      const logsRes = await fetch('/api/ai/usage', {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      const lData = await logsRes.json();
      setAiLogs(lData.logs || []);

    } catch (e) {
      console.error("Workspace details loaded failed", e);
    } finally {
      setLoading(false);
    }
  }

  // Trial countdown — days remaining
  const trialDaysRemaining = store.trialEndsAt
    ? Math.max(0, Math.ceil((new Date(store.trialEndsAt).getTime() - Date.now()) / (1000 * 60 * 60 * 24)))
    : null;
  const showTrialWarning = trialDaysRemaining !== null && trialDaysRemaining <= 3 && trialDaysRemaining >= 0;
  const isTrialActive = trialDaysRemaining !== null && trialDaysRemaining > 0;

  // Active onboarding calculations
  const setupChecklist = [
    { title: 'Definir Nome da Loja', done: !!store.name },
    { title: 'Adicionar Logo ou Banner', done: !!store.logoUrl || !!store.bannerUrl },
    { title: 'Cadastrar Primeiro Produto', done: products.length > 0 },
    { title: 'Configurar WhatsApp de Vendas', done: !!store.phone },
    { title: 'Escolher um Modelo de Estilo', done: !!store.templateId },
    { title: 'Visitar sua Vitrine Pública', done: metrics?.totalVisits > 0 },
  ];
  const completedStepsCount = setupChecklist.filter(c => c.done).length;
  const onboardingCompletionPercent = Math.round((completedStepsCount / setupChecklist.length) * 100);

  // Claude Helper description executor
  const triggerClaudeHelper = async () => {
    if (!pName) {
      setErrFeedback('Favor introduzir o nome do produto para gerarmos.');
      return;
    }
    setAiDescLoading(true);
    setAiDescOptions([]);
    setErrFeedback(null);
    try {
      const token = localStorage.getItem('vestu_token') || '';
      const res = await fetch('/api/ai/generate-description', {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({ name: pName, category: pCategory })
      });
      if (res.ok) {
        const data = await res.json();
        setAiDescOptions(data.options || []);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setAiDescLoading(false);
    }
  };

  // AI Studio Image Generation Executor
  const triggerAiGenerator = async () => {
    setAiImageStatus('Ajustando a iluminação técnica...');
    setAiResultUrl(null);
    
    // Fun loading messages to show step-by-step
    const steps = [
      'Escolhendo a pose comercial do modelo...',
      'Renderizando o cenário de fundo selecionado...',
      'Unindo textura da roupa e gerando visual premium...',
      'Finalizando filtros de alta fidelidade 4K...'
    ];

    let currentStep = 0;
    const interval = setInterval(() => {
      if (currentStep < steps.length) {
        setAiImageStatus(steps[currentStep]);
        currentStep++;
      }
    }, 1500);

    try {
      const token = localStorage.getItem('vestu_token') || '';
      const res = await fetch('/api/ai/generate-image', {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({
          style: aiStyle,
          scenario: aiScenario,
          pose: aiPose,
          expression: aiExpression,
          customScenario: aiCustomSec,
          productImageBase64: aiStudioPhoto
            ? aiStudioPhoto.replace(/^data:image\/[^;]+;base64,/, '')
            : ''
        })
      });

      clearInterval(interval);
      if (res.ok) {
        const data = await res.json();
        setAiResultUrl(data.resultUrl);
        setFeedback("Foto gerada com maestria no Estúdio IA!");
        onRefreshSession(); // Reload limits count
      } else {
        const err = await res.json();
        setErrFeedback(err.error || 'Falha ao processar servidor fal.ai.');
      }
    } catch (e) {
      clearInterval(interval);
      setErrFeedback('Serviço temporariamente congestionado.');
    } finally {
      setAiImageStatus(null);
    }
  };
  
  // Photo multi-upload handlers
  const addPhotoFiles = (files: File[]) => {
    const remainingSlots = 5 - pPhotos.length;
    if (remainingSlots <= 0) {
      setErrFeedback("Máximo de 5 fotos atingido.");
      return;
    }
    const filesToProcess = files.slice(0, remainingSlots);

    filesToProcess.forEach(file => {
      const reader = new FileReader();
      reader.onloadend = () => {
        if (typeof reader.result === 'string') {
          setPPhotos(prev => {
            if (prev.length >= 5) return prev;
            return [...prev, reader.result as string];
          });
        }
      };
      reader.readAsDataURL(file);
    });
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      const files = Array.from(e.target.files) as File[];
      addPhotoFiles(files);
    }
  };

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setIsDragActive(true);
    } else if (e.type === "dragleave") {
      setIsDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragActive(false);
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      const files = Array.from(e.dataTransfer.files) as File[];
      addPhotoFiles(files);
    }
  };

  const handleAddPhotoUrl = () => {
    if (!photoUrlInput.trim()) return;
    if (pPhotos.length >= 5) {
      setErrFeedback("Máximo de 5 fotos atingido.");
      return;
    }
    setPPhotos(prev => [...prev, photoUrlInput.trim()]);
    setPhotoUrlInput('');
  };

  const handleRemovePhoto = (index: number) => {
    setPPhotos(prev => prev.filter((_, idx) => idx !== index));
  };

  const handleMovePhoto = (index: number, direction: 'left' | 'right') => {
    const newIndex = direction === 'left' ? index - 1 : index + 1;
    if (newIndex < 0 || newIndex >= pPhotos.length) return;
    
    setPPhotos(prev => {
      const result = [...prev];
      const temp = result[index];
      result[index] = result[newIndex];
      result[newIndex] = temp;
      return result;
    });
  };

  // Create or Update Product Database Record
  const handleSaveProduct = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!pName || !pPrice) {
      setErrFeedback("Nome e preço são itens mandatórios de cadastro.");
      return;
    }

    const payload = {
      name: pName,
      description: pDescription,
      price: Number(pPrice),
      salePrice: pSalePrice ? Number(pSalePrice) : null,
      wholesalePrice: pWholesalePrice ? Number(pWholesalePrice) : null,
      wholesaleMinQty: pWholesaleMinQty ? Number(pWholesaleMinQty) : null,
      costPrice: pCostPrice ? Number(pCostPrice) : null,
      stock: Number(pStock),
      category: pCategory,
      tags: pTags.split(',').map(t => t.trim()).filter(t => t.length > 0),
      isFeatured: pIsFeatured,
      isPromotion: pIsPromotion,
      photos: pPhotos,
      status: 'active'
    };

    try {
      const token = localStorage.getItem('vestu_token') || '';
      let url = '/api/dashboard/products';
      let method = 'POST';

      if (editingProduct) {
        url = `/api/dashboard/products/${editingProduct.id}`;
        method = 'PUT';
      }

      const res = await fetch(url, {
        method,
        headers: { 
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify(payload)
      });

      if (res.ok) {
        setFeedback(editingProduct ? "Modificações salvas!" : "Produto cadastrado com sucesso!");
        handleCloseProductForm();
        loadLojistaData();
        setTimeout(() => setFeedback(null), 3000);
      } else {
        const errData = await res.json();
        setErrFeedback(errData.error || 'Erro operacional.');
        setTimeout(() => setErrFeedback(null), 4000);
      }
    } catch (e) {
      setErrFeedback('Erro de conexão com o servidor.');
      setTimeout(() => setErrFeedback(null), 4000);
    }
  };

  const handleDeleteProduct = async (prodId: string) => {
    if (!window.confirm("Gostaria de deletar em definitivo este produto?")) return;
    try {
      const token = localStorage.getItem('vestu_token') || '';
      const res = await fetch(`/api/dashboard/products/${prodId}`, {
        method: 'DELETE',
        headers: { 'Authorization': `Bearer ${token}` }
      });
      if (res.ok) {
        setFeedback("Produto excluído.");
        loadLojistaData();
      }
    } catch (e) {}
  };

  // Save general Store configuration changes
  const handleSaveStoreSettings = async () => {
    try {
      const token = localStorage.getItem('vestu_token') || '';
      const res = await fetch(`/api/store/${store.slug}`, {
        method: 'PUT',
        headers: { 
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({
          name: stName,
          phone: stPhone,
          logoUrl: stLogo,
          bannerUrl: stBanner,
          primaryColor: stPrimary,
          accentColor: stAccent,
          templateId: stTemplate,
          gateEnabled: stGateEnabled,
          customDomain: stDomain || null,
          physicalAddress: stAddress || null,
        })
      });
      if (res.ok) {
        setFeedback("Configurações atualizadas na nuvem!");
        onRefreshSession();
        setTimeout(() => setFeedback(null), 3000);
      } else {
        const err = await res.json();
        setErrFeedback(err.error || 'Falha ao atualizar parâmetros.');
        setTimeout(() => setErrFeedback(null), 4000);
      }
    } catch (e) {}
  };

  // Test custom domain DNS
  const testDnsIntegration = async () => {
    try {
      const token = localStorage.getItem('vestu_token') || '';
      const res = await fetch(`/api/store/${store.slug}/verify-domain`, {
        method: 'POST',
        headers: { 'Authorization': `Bearer ${token}` }
      });
      if (res.ok) {
        const data = await res.json();
        alert(data.message);
      }
    } catch (e) {}
  };

  // Open forms helper
  const handleOpenEditProduct = (prod: Product) => {
    setEditingProduct(prod);
    setPName(prod.name);
    setPDescription(prod.description);
    setPPrice(prod.price.toString());
    setPSalePrice(prod.salePrice?.toString() || '');
    setPWholesalePrice(prod.wholesalePrice?.toString() || '');
    setPWholesaleMinQty(prod.wholesaleMinQty?.toString() || '');
    setPCostPrice(prod.costPrice?.toString() || '');
    setPStock(prod.stock.toString());
    setPCategory(prod.category);
    setPTags(prod.tags.join(', '));
    setPPhotos(prod.photos);
    setPIsFeatured(prod.isFeatured);
    setPIsPromotion(prod.isPromotion);
    setIsAddingProduct(true);
  };

  const handleCloseProductForm = () => {
    setEditingProduct(null);
    setIsAddingProduct(false);
    setPName('');
    setPDescription('');
    setPPrice('');
    setPSalePrice('');
    setPWholesalePrice('');
    setPWholesaleMinQty('');
    setPCostPrice('');
    setPStock('20');
    setPTags('');
    setPIsFeatured(false);
    setPIsPromotion(false);
    setAiDescOptions([]);
    setPPhotos([
      'https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?auto=format&fit=crop&w=600&q=80'
    ]);
    setPhotoUrlInput('');
    setIsDragActive(false);
  };

  // Side Navigation controls
  const navigationItems = [
    { label: 'Visão Geral', id: 'visão-geral', icon: LayoutDashboard },
    { label: 'Produtos', id: 'produtos', icon: Package },
    { label: 'Estúdio IA', id: 'estúdio-ia', icon: Sparkles },
    { label: 'Design da Loja', id: 'design', icon: Palette },
    { label: 'Marketing', id: 'marketing', icon: Megaphone },
    { label: 'Configurações', id: 'configuracoes', icon: Settings },
  ];

  return (
    <div className="min-h-screen bg-slate-50 text-slate-800 flex flex-col md:flex-row font-sans">
      
      {/* 1. LEFT SIDEBAR PANEL NAVIGATION */}
      <aside className="w-full md:w-64 bg-slate-900 text-slate-300 flex flex-col justify-between shrink-0 border-r border-[#1e293b]">
        
        <div className="space-y-6 py-6">
          
          {/* Dashboard platform logo */}
          <div className="px-6 space-y-1">
            <h1 className="text-xl font-black text-white tracking-tight flex items-center space-x-2">
              <VestuAiSymbol size={28} />
              <span>Vestu<span className="text-[#3b82f6]">AI</span></span>
            </h1>
            <p className="text-[10px] text-slate-400 font-mono tracking-wide uppercase">Merchant Workspace</p>
          </div>

          <div className="px-4">
            {/* Lojista Active Shop name pill */}
            <div className="rounded-xl bg-slate-950 p-3 shadow-inner flex items-center justify-between">
              <div className="max-w-[120px] truncate">
                <p className="text-xs font-bold text-white leading-none">{store.name}</p>
                <span className="text-[9px] text-slate-400">{store.slug}.vestuai.com.br</span>
              </div>
              <span className="text-[9px] font-black uppercase text-pink-400 bg-pink-500/10 border border-pink-500/20 rounded px-1.5 py-0.5 leading-none">
                {store.planId}
              </span>
            </div>
          </div>

          {/* Nav groups */}
          <nav className="space-y-1 px-3">
            {navigationItems.map(item => {
              const Icon = item.icon;
              const criticalStockCount = products.filter(p => p.stock < 3).length;
              return (
                <button 
                  key={item.id}
                  onClick={() => {
                    setActiveTab(item.id);
                    handleCloseProductForm();
                  }}
                  className={`w-full flex items-center space-x-3 rounded-xl px-4 py-3 text-xs font-semibold tracking-tight transition cursor-pointer ${
                    activeTab === item.id 
                      ? 'bg-[#6366f1] text-white shadow-md' 
                      : 'hover:bg-slate-800 text-slate-400 hover:text-slate-200'
                  }`}
                >
                  <Icon className="h-4.5 w-4.5" />
                  <span className="grow text-left">{item.label}</span>
                  {item.id === 'produtos' && criticalStockCount > 0 && (
                    <span className="flex items-center space-x-1 shrink-0">
                      <span className="relative flex h-2 w-2">
                        <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-rose-400 opacity-75"></span>
                        <span className="relative inline-flex rounded-full h-2 w-2 bg-rose-500"></span>
                      </span>
                      <span className="text-[10px] bg-rose-600 text-white font-bold px-2 py-0.5 rounded-full text-center min-w-[20px]">
                        {criticalStockCount}
                      </span>
                    </span>
                  )}
                </button>
              );
            })}
          </nav>

        </div>

        {/* Foot lock buttons */}
        <div className="p-4 border-t border-slate-800 space-y-2">
          {user?.role === 'superadmin' && (
            <button 
              onClick={() => onChangeView('/admin')}
              className="w-full rounded-xl bg-gradient-to-tr from-rose-500 to-amber-500 py-2.5 text-[11px] font-bold text-white hover:opacity-95 shadow cursor-pointer text-center"
            >
              Master Admin Control
            </button>
          )}

          <button 
            onClick={onLogout}
            className="w-full text-center text-xs text-slate-500 hover:text-slate-300 py-2 transition cursor-pointer"
          >
            Encerrar Painel
          </button>
        </div>

      </aside>

      {/* 2. MAIN WORKSPACE ELEMENT */}
      <main className="flex-1 flex flex-col min-w-0 overflow-y-auto">
        
        {/* Top Header info */}
        <header className="bg-white border-b border-slate-100 py-4 px-6 flex flex-col sm:flex-row gap-4 items-center justify-between">
          <div>
            <h2 className="text-lg font-black tracking-tight text-slate-900 capitalize">
              Dashboard / {activeTab.replace('-', ' ')}
            </h2>
            <p className="text-xs text-slate-500">Seja bem vindo à sua conta corporativa VestuAI.</p>
          </div>

          <div className="flex items-center space-x-3 shrink-0">
            {/* Direct Open store link */}
            <button 
              onClick={() => onNavigateToStorefront(store.slug)}
              className="inline-flex items-center space-x-1.5 rounded-xl border border-slate-200 bg-slate-50 px-3.5 py-2 text-xs font-bold text-slate-700 hover:bg-slate-100 transition cursor-pointer"
            >
              <span>Visualizar Minha Loja</span>
              <ExternalLink className="h-3.5 w-3.5" />
            </button>
          </div>
        </header>

        {/* Global actions visual notices */}
        {feedback && (
          <div className="bg-emerald-500 text-white py-2.5 px-6 text-xs font-bold font-mono shadow-sm">
            ✓ CONFIRMADO: {feedback}
          </div>
        )}
        {errFeedback && (
          <div className="bg-rose-500 text-white py-2.5 px-6 text-xs font-bold font-mono shadow-sm">
            ✗ ERRO: {errFeedback}
          </div>
        )}

        {/* TAB WORKSPACES CONTAINER */}
        <div className="p-4 sm:p-6 lg:p-8 flex-1">
          
          {/* TAB: VISÃO GERAL */}
          {activeTab === 'visão-geral' && (
            <div className="space-y-8">
              
              {/* Alert System: Low Stock Alert (< 3 units) */}
              {products.filter(p => p.stock < 3).length > 0 && (
                <motion.div 
                  id="low-stock-critical-alert" 
                  initial={{ opacity: 0.98, scale: 0.99 }}
                  animate={{ 
                    opacity: [0.98, 1, 0.98],
                    scale: [0.99, 1, 0.99],
                    borderColor: [
                      "rgba(254, 226, 226, 1)", // border-rose-100
                      "rgba(244, 63, 94, 0.6)",  // border-rose-500 soft glow
                      "rgba(254, 226, 226, 1)"
                    ],
                    boxShadow: [
                      "0 1px 2px 0 rgba(0, 0, 0, 0.05)",
                      "0 10px 20px -5px rgba(244, 63, 94, 0.12), 0 4px 6px -2px rgba(244, 63, 94, 0.05)",
                      "0 1px 2px 0 rgba(0, 0, 0, 0.05)"
                    ]
                  }}
                  transition={{ 
                    duration: 2.5, 
                    repeat: Infinity, 
                    ease: "easeInOut" 
                  }}
                  className="rounded-3xl border-2 bg-rose-50/70 p-6 space-y-4 shadow-sm relative overflow-hidden"
                >
                  <div className="absolute right-0 top-0 -mt-6 -mr-6 w-32 h-32 bg-rose-500/5 rounded-full pointer-events-none" />
                  
                  <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-4">
                    <div className="flex items-start space-x-3">
                      <div className="p-2 bg-rose-100 text-rose-600 rounded-xl shrink-0 animate-pulse mt-0.5">
                        <AlertTriangle className="h-5 w-5" />
                      </div>
                      <div className="space-y-1">
                        <h3 className="text-sm font-bold text-rose-900 flex items-center space-x-2">
                          <span>Atenção: Alerta de Estoque Crítico</span>
                          <span className="text-[10px] font-mono bg-rose-600 text-white font-black px-2 py-0.5 rounded-full">
                            {products.filter(p => p.stock < 3).length} {products.filter(p => p.stock < 3).length === 1 ? 'produto afetado' : 'produtos afetados'}
                          </span>
                        </h3>
                        <p className="text-xs text-rose-700/85">
                          Os seguintes modelos de roupas têm menos de <strong className="font-bold">3 unidades</strong> disponíveis em estoque. Reponha as peças ou retire-as de destaque para evitar cancelamentos de vendas.
                        </p>
                      </div>
                    </div>
                    
                    <button 
                      onClick={() => setActiveTab('produtos')}
                      className="shrink-0 inline-flex items-center space-x-1 rounded-xl bg-rose-600 px-3 py-2 text-xs font-bold text-white hover:bg-rose-700 transition shadow-sm cursor-pointer whitespace-nowrap align-middle"
                    >
                      <span>Ir para Estoque</span>
                      <ChevronRight className="h-3.5 w-3.5" />
                    </button>
                  </div>

                  {/* List of critical products inside the alert */}
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3 pt-2">
                    {products.filter(p => p.stock < 3).map(prod => (
                      <div 
                        key={prod.id} 
                        className="rounded-xl border border-rose-150 bg-white p-3 flex items-center justify-between shadow-xs hover:border-rose-300 transition-all group"
                      >
                        <div className="flex items-center space-x-2.5 overflow-hidden">
                          <img 
                            src={prod.photos[0]} 
                            alt="" 
                            referrerPolicy="no-referrer"
                            className="h-10 w-10 rounded-lg object-cover bg-slate-50 border border-slate-100 shrink-0"
                          />
                          <div className="overflow-hidden">
                            <p className="text-xs font-bold text-slate-800 truncate">{prod.name}</p>
                            <p className="text-[10px] text-slate-500 font-medium">{prod.category}</p>
                          </div>
                        </div>

                        <div className="flex items-center space-x-2 shrink-0">
                          <span className={`text-[10px] font-mono font-black px-2 py-1 rounded-lg ${
                            prod.stock === 0 
                              ? 'bg-red-600 text-white animate-pulse' 
                              : 'bg-rose-100 text-rose-800'
                          }`}>
                            {prod.stock === 0 ? "Esgotado!" : `${prod.stock} un`}
                          </span>
                          <button
                            onClick={() => {
                              setActiveTab('produtos');
                              handleOpenEditProduct(prod);
                            }}
                            className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 transition cursor-pointer"
                            title="Editar estoque do produto"
                          >
                            <Palette className="h-3.5 w-3.5" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </motion.div>
              )}

              {/* Onboarding dynamic checklists progress bar */}
              {onboardingCompletionPercent < 100 && (
                <div className="rounded-3xl border border-slate-150 bg-white p-6 shadow-sm space-y-4">
                  <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
                    <div className="space-y-1">
                      <h3 className="text-sm font-bold text-slate-800 flex items-center space-x-1.5">
                        <CheckSquare className="h-4.5 w-4.5 text-[#6366f1]" />
                        <span>Passo a Passo de Configuração ({completedStepsCount}/6)</span>
                      </h3>
                      <p className="text-xs text-slate-500">Complete as etapas para colocar sua operação de moda no ar com segurança.</p>
                    </div>
                    <span className="text-xs font-mono font-black text-[#6366f1] bg-[#6366f1]/10 px-2.5 py-1 rounded-full shrink-0">
                      {onboardingCompletionPercent}% Completo
                    </span>
                  </div>

                  {/* Visual tracking progress line */}
                  <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                    <div 
                      className="bg-gradient-to-r from-[#6366f1] to-[#a855f7] h-full transition-all duration-500" 
                      style={{ width: `${onboardingCompletionPercent}%` }}
                    />
                  </div>

                  {/* Flat item matrix */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 pt-2">
                    {setupChecklist.map((item, idx) => (
                      <div 
                        key={idx} 
                        className={`rounded-xl border p-3 flex items-center justify-between ${
                          item.done 
                            ? 'bg-emerald-50/50 border-emerald-150 text-slate-700' 
                            : 'bg-slate-50 border-slate-100 text-slate-400'
                        }`}
                      >
                        <span className="text-xs font-medium leading-none">{item.title}</span>
                        {item.done ? (
                          <div className="h-4 w-4 bg-emerald-500 rounded-full flex items-center justify-center text-white shrink-0">
                            <Check className="h-2.5 w-2.5" />
                          </div>
                        ) : (
                          <div className="h-4 w-4 border-2 border-slate-200 rounded-full shrink-0" />
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Lojista KPIs overview panels */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                
                <div className="rounded-2xl border bg-white p-5 space-y-2 shadow-xs">
                  <span className="text-[10px] uppercase font-black tracking-widest text-slate-400">Total de Visitas Públicas</span>
                  <div className="flex items-baseline space-x-1.5">
                    <span className="text-2xl font-black text-slate-800">{metrics?.totalVisits || 0}</span>
                    <span className="text-[10px] text-emerald-500 font-bold">Unicas: {metrics?.totalUnique || 0}</span>
                  </div>
                  <p className="text-[10px] text-slate-400">Visualizações no período de 30 dias</p>
                </div>

                <div className="rounded-2xl border bg-white p-5 space-y-2 shadow-xs">
                  <span className="text-[10px] uppercase font-black tracking-widest text-slate-400">Interesse no WhatsApp</span>
                  <span className="text-2xl font-black text-slate-800">{metrics?.whatsappRedirects || 0}</span>
                  <p className="text-[10px] text-slate-400">Redirecionamentos ao wa.me de vendas</p>
                </div>

                <div className="rounded-2xl border bg-white p-5 space-y-2 shadow-xs">
                  <span className="text-[10px] uppercase font-black tracking-widest text-slate-400">Conversão Estimada</span>
                  <span className="text-2xl font-black text-slate-800">{metrics?.conversionRate || 0}%</span>
                  <p className="text-[10px] text-slate-400">Proporção cliques / visitas únicas</p>
                </div>

                <div className="rounded-2xl border bg-white p-5 space-y-2 shadow-xs">
                  <span className="text-[10px] uppercase font-black tracking-widest text-slate-400">Faturamento Bruto</span>
                  <span className="text-2xl font-black text-slate-800">R$ {store.totalRevenue?.toFixed(2) || '0.00'}</span>
                  <p className="text-[10px] text-slate-400">{store.totalOrders || 0} pedidos faturados no canal</p>
                </div>

              </div>

              {/* Quick links actions layout split */}
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                
                {/* Store URL share card */}
                <div className="lg:col-span-1 rounded-3xl border bg-white p-6 space-y-4 shadow-sm flex flex-col justify-between">
                  <div className="space-y-1">
                    <h4 className="text-sm font-bold text-slate-800">Compartilhar Vitrine Comercial</h4>
                    <p className="text-xs text-slate-500">Envie o link oficial para redes sociais, bios do Instagram ou grupos do WhatsApp.</p>
                  </div>

                  <div className="rounded-2xl bg-slate-950 p-4 font-mono text-xs text-indigo-400 select-all break-all border shadow-inner">
                    https://{store.slug}.vestuai.com.br
                  </div>

                  <button 
                    onClick={() => {
                      navigator.clipboard.writeText(`https://${store.slug}.vestuai.com.br`);
                      setFeedback("Link copiado de primeira!");
                      setTimeout(() => setFeedback(null), 3000);
                    }}
                    className="w-full inline-flex items-center justify-center space-x-1.5 rounded-xl bg-[#6366f1] py-3 text-xs font-bold text-white hover:bg-indigo-600 transition cursor-pointer shadow"
                  >
                    <Copy className="h-4 w-4" />
                    <span>Copiar endereço da loja</span>
                  </button>
                </div>

                {/* Subscriptions detail card */}
                <div className="lg:col-span-2 rounded-3xl border bg-white p-6 space-y-4 shadow-sm flex flex-col justify-between">
                  <div className="flex items-center justify-between">
                    <div className="space-y-1">
                      <h4 className="text-sm font-bold text-slate-800">Seu Faturamento Global de Assinatura</h4>
                      <p className="text-xs text-slate-500">Visão geral do faturamento e consumo cobrado mensalmente.</p>
                    </div>

                    <span className="text-xs font-black uppercase tracking-widest bg-emerald-500/10 text-emerald-600 px-3 py-1 rounded-full">
                      RENOVAÇÃO EM 15 DIAS
                    </span>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-4 border-t">
                    <div className="space-y-1">
                      <span className="text-[10px] text-slate-400 uppercase font-black">Plano Comercial</span>
                      <p className="text-sm font-bold text-slate-800 capitalize">{store.planId}</p>
                    </div>
                    <div className="space-y-1">
                      <span className="text-[10px] text-slate-400 uppercase font-black">Imagens Usadas</span>
                      <p className="text-sm font-bold text-slate-800 font-mono">
                        {store.aiImagesUsedThisWeek} / {store.planId === 'free' ? 5 : store.planId === 'pro' ? 15 : store.planId === 'pro_max' ? 30 : 50}
                      </p>
                    </div>
                    <div className="space-y-1">
                      <span className="text-[10px] text-slate-400 uppercase font-black">Vídeos Usados</span>
                      <p className="text-sm font-bold text-slate-800 font-mono">
                        {store.aiVideosUsedThisWeek} / {store.planId === 'ultra' ? 5 : 0}
                      </p>
                    </div>
                  </div>

                  <div className="pt-2">
                    <p className="text-[10px] text-slate-400">Quer desbloquear quota ilimitada de produtos e estúdio de vídeo de alta fidelidade? Realize o upgrade de plano a qualquer momento.</p>
                  </div>
                </div>

              </div>

            </div>
          )}

          {/* TAB: PRODUTOS */}
          {activeTab === 'produtos' && (
            <div className="space-y-6">
              {/* Trial warning banner */}
              {showTrialWarning && (
                <div className="rounded-2xl bg-amber-50 border border-amber-200 p-4 flex items-center justify-between space-x-4">
                  <div className="flex items-center space-x-3 text-amber-800">
                    <AlertTriangle className="h-5 w-5 text-amber-500 shrink-0" />
                    <div>
                      <p className="text-xs font-bold">Seu período de teste termina em {trialDaysRemaining} dia{trialDaysRemaining !== 1 ? 's' : ''}!</p>
                      <p className="text-[10px] text-amber-600">Após o fim do trial, sua loja será rebaixada para o Plano Grátis automaticamente.</p>
                    </div>
                  </div>
                  <button className="shrink-0 rounded-xl bg-amber-500 px-3 py-1.5 text-[10px] font-bold text-white hover:bg-amber-600 cursor-pointer">
                    Manter Pro
                  </button>
                </div>
              )}
              
              {!isAddingProduct ? (
                <div className="bg-white border rounded-3xl p-6 shadow-sm space-y-6">
                  
                  {/* Title and Add line button */}
                  <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
                    <div>
                      <h3 className="text-base font-bold text-slate-800">Catálogo Geral de Vestuários ({products.length})</h3>
                      <p className="text-xs text-slate-500">Crie, modifique preços atacado/varejo, configure estoque e gerencie status de publicação.</p>
                    </div>

                    <button 
                      onClick={() => setIsAddingProduct(true)}
                      className="inline-flex items-center space-x-1.5 rounded-xl bg-slate-900 px-4 py-2.5 text-xs font-bold text-white hover:bg-[#6366f1] shadow cursor-pointer transition-all shrink-0"
                    >
                      <PlusCircle className="h-4.5 w-4.5" />
                      <span>Cadastrar Novo Produto</span>
                    </button>
                  </div>

                  {products.length === 0 ? (
                    <div className="text-center py-16 space-y-4">
                      <Package className="mx-auto h-12 w-12 text-slate-200" />
                      <h4 className="text-sm font-bold text-slate-600">Nenhum produto cadastrado ainda</h4>
                      <p className="text-xs text-slate-400 max-w-xs mx-auto">Cadastre sua primeira peça de moda para estruturar a vitrine e testar o editor de fotos IA.</p>
                      <button 
                        onClick={() => setIsAddingProduct(true)}
                        className="rounded-xl border-2 border-dashed border-slate-300 px-6 py-2.5 text-xs text-slate-600 font-bold hover:border-slate-400 cursor-pointer"
                      >
                        Começar cadastro agora
                      </button>
                    </div>
                  ) : (
                    <div className="overflow-x-auto border rounded-2xl w-full">
                      <table className="w-full text-xs text-left text-slate-600 border-collapse">
                        <thead className="bg-slate-50 text-slate-500 uppercase text-[9px] font-mono border-b">
                          <tr>
                            <th className="p-4">Visual</th>
                            <th className="p-4">Identificação Produto</th>
                            <th className="p-4 text-center">Categoria</th>
                            <th className="p-4 text-center">Preço Varejo</th>
                            <th className="p-4 text-center">Preço Atacado</th>
                            <th className="p-4 text-center">Estoque</th>
                            <th className="p-4 text-right">Controles</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-100">
                          {products.map(prod => (
                            <tr 
                              key={prod.id} 
                              className={`hover:bg-slate-50/50 transition-colors ${
                                prod.stock < 3 
                                  ? 'bg-rose-50/40 border-l-4 border-rose-500 font-medium' 
                                  : ''
                              }`}
                            >
                              
                              <td className="p-4 shrink-0">
                                <img 
                                  src={prod.photos[0]} 
                                  alt="" 
                                  referrerPolicy="no-referrer"
                                  className="h-10 w-10 rounded-lg object-cover bg-slate-100 border" 
                                />
                              </td>

                              <td className="p-4">
                                <span className="font-bold text-slate-800">{prod.name}</span>
                                <div className="flex space-x-1.5 text-[9px] text-[#6366f1] font-bold">
                                  {prod.isFeatured && <span>• Destaque</span>}
                                  {prod.isPromotion && <span>• Promoção</span>}
                                </div>
                              </td>

                              <td className="p-4 text-center text-slate-500">
                                {prod.category}
                              </td>

                              <td className="p-4 text-center font-bold text-slate-800">
                                R$ {prod.price.toFixed(2)}
                                {prod.salePrice && (
                                  <p className="text-[10px] text-rose-500 line-through">R$ {prod.salePrice}</p>
                                )}
                              </td>

                              <td className="p-4 text-center text-slate-600 font-semibold">
                                {prod.wholesalePrice ? `R$ ${prod.wholesalePrice.toFixed(2)}` : '--'}
                                {prod.wholesaleMinQty && (
                                  <p className="text-[8px] text-purple-600 font-bold">Mín: {prod.wholesaleMinQty} pçs</p>
                                )}
                              </td>

                              <td className="p-4 text-center">
                                <span className={`px-2.5 py-1 rounded-full text-[10px] font-bold ${
                                  prod.stock < 3 
                                    ? 'bg-rose-600 text-white animate-pulse' 
                                    : prod.stock < 5 
                                      ? 'bg-orange-100 text-orange-700' 
                                      : 'bg-slate-100 text-slate-700'
                                }`}>
                                  {prod.stock} un
                                </span>
                              </td>

                              <td className="p-4 text-right">
                                <div className="inline-flex space-x-2">
                                  <button 
                                    onClick={() => handleOpenEditProduct(prod)}
                                    className="p-1.5 rounded-lg bg-slate-100 text-slate-600 hover:bg-[#6366f1] hover:text-white transition cursor-pointer"
                                  >
                                    <Palette className="h-4 w-4" />
                                  </button>
                                  <button 
                                    onClick={() => handleDeleteProduct(prod.id)}
                                    className="p-1.5 rounded-lg bg-orange-50 text-orange-600 hover:bg-orange-500 hover:text-white transition cursor-pointer"
                                  >
                                    <Trash2 className="h-4 w-4" />
                                  </button>
                                </div>
                              </td>

                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  )}

                </div>
              ) : (
                <form onSubmit={handleSaveProduct} className="bg-white border rounded-3xl p-6 shadow-sm space-y-6">
                  
                  <div className="flex items-center space-x-3 border-b pb-4">
                    <button 
                      type="button" 
                      onClick={handleCloseProductForm}
                      className="p-1.5 rounded-full hover:bg-slate-150 text-slate-500 cursor-pointer"
                    >
                      <ArrowLeft className="h-4.5 w-4.5" />
                    </button>
                    <div>
                      <h4 className="text-base font-bold text-slate-900">
                        {editingProduct ? 'Editar Produto Cadastrado' : 'Cadastrar Novo Modelo de Roupa'}
                      </h4>
                      <p className="text-xs text-slate-400">Preencha as configurações e ative as descrições assistidas por inteligência artificial.</p>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    
                    <div className="space-y-4">
                      
                      <div className="space-y-1">
                        <label className="text-xs font-bold text-slate-500">Nome do Vestuário</label>
                        <input 
                          type="text" 
                          value={pName}
                          onChange={(e) => setPName(e.target.value)}
                          placeholder="Ex: Vestido Midi Canelado Sunset"
                          required
                          className="w-full rounded-xl border bg-slate-50 px-4 py-2.5 text-xs text-slate-800 placeholder-slate-400 outline-none focus:border-[#6366f1] focus:bg-white"
                        />
                      </div>

                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-1">
                          <label className="text-xs font-bold text-slate-500">Categoria</label>
                          <select 
                            value={pCategory}
                            onChange={(e) => setPCategory(e.target.value)}
                            className="w-full rounded-xl border bg-slate-50 px-3 py-2.5 text-xs text-slate-800 outline-none"
                          >
                            <option value="Tops">Tops / Blazers</option>
                            <option value="Blusas">Blusas / Croppeds</option>
                            <option value="Vestidos">Vestidos / Macacões</option>
                            <option value="Calças">Calças / Wide Legs</option>
                            <option value="Shorts">Shorts / Bermudas</option>
                            <option value="Conjuntos">Conjuntos Completos</option>
                            <option value="Acessórios">Acessórios / Bolsas</option>
                          </select>
                        </div>

                        <div className="space-y-1">
                          <label className="text-xs font-bold text-slate-500">Estoque Inicial (unidades)</label>
                          <input 
                            type="number" 
                            value={pStock}
                            onChange={(e) => setPStock(e.target.value)}
                            required
                            className="w-full rounded-xl border bg-slate-50 px-4 py-2.5 text-xs text-slate-800 outline-none focus:border-[#6366f1] focus:bg-white"
                          />
                        </div>
                      </div>

                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-1">
                          <label className="text-xs font-bold text-slate-500">Valor de Varejo (R$)</label>
                          <input 
                            type="number" 
                            step="0.01"
                            value={pPrice}
                            onChange={(e) => setPPrice(e.target.value)}
                            placeholder="Ex: 189.90"
                            required
                            className="w-full rounded-xl border bg-slate-50 px-4 py-2.5 text-xs text-slate-800 outline-none focus:border-[#6366f1] focus:bg-white"
                          />
                        </div>

                        <div className="space-y-1">
                          <label className="text-xs font-bold text-slate-500">Valor Promocional (Opcional)</label>
                          <input 
                            type="number" 
                            step="0.01"
                            value={pSalePrice}
                            onChange={(e) => setPSalePrice(e.target.value)}
                            placeholder="Ex: 159.90"
                            className="w-full rounded-xl border bg-slate-50 px-4 py-2.5 text-xs text-slate-800 outline-none focus:border-[#6366f1] focus:bg-white"
                          />
                        </div>
                      </div>

                      {/* Wholesale active gates based on profile selection */}
                      <div className="p-4 rounded-2xl bg-slate-50 border space-y-4">
                        <h5 className="text-[11px] font-black uppercase text-slate-400">Atacado de Revendedor (Opcional)</h5>
                        
                        <div className="grid grid-cols-2 gap-4">
                          <div className="space-y-1">
                            <label className="text-[10px] font-bold text-slate-500">Preço de Lote Atacado (R$)</label>
                            <input 
                              type="number" 
                              step="0.01"
                              value={pWholesalePrice}
                              onChange={(e) => setPWholesalePrice(e.target.value)}
                              placeholder="Ex: 109.90"
                              className="w-full rounded-xl border bg-white px-3 py-2 text-xs outline-none"
                            />
                          </div>

                          <div className="space-y-1">
                            <label className="text-[10px] font-bold text-slate-500">Fardo Mínimo (itens)</label>
                            <input 
                              type="number" 
                              value={pWholesaleMinQty}
                              onChange={(e) => setPWholesaleMinQty(e.target.value)}
                              placeholder="Ex: 3"
                              className="w-full rounded-xl border bg-white px-3 py-2 text-xs outline-none"
                            />
                          </div>
                        </div>
                      </div>

                    </div>

                    {/* Claude AI Assistant Helper description writing */}
                    <div className="space-y-4">
                      
                      <div className="space-y-1 bg-gradient-to-tr from-[#6366f1]/5 to-[#a855f7]/5 p-4 rounded-3xl border border-[#6366f1]/25">
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-bold text-slate-800 flex items-center space-x-1">
                            <Sparkles className="h-4 w-4 text-[#6366f1]" />
                            <span>Descrição Inteligente Claude</span>
                          </span>
                          <button 
                            type="button" 
                            onClick={triggerClaudeHelper}
                            disabled={aiDescLoading}
                            className="text-[10px] font-bold text-white bg-slate-900 border px-3 py-1.5 rounded-xl cursor-pointer hover:bg-[#6366f1] shadow-xs"
                          >
                            {aiDescLoading ? 'Claude escrevendo...' : 'Gerar 3 opções'}
                          </button>
                        </div>
                        
                        <p className="text-[10px] text-slate-500 mt-1">Gere automaticamente chamadas de alto padrão técnico em Português para suas mídias digitais.</p>

                        {aiDescOptions.length > 0 && (
                          <div className="mt-3 space-y-2 max-h-40 overflow-y-auto pr-1">
                            {aiDescOptions.map((opt, id) => (
                              <div 
                                key={id} 
                                onClick={() => setPDescription(opt)}
                                className="p-2.5 rounded-xl bg-white border hover:border-[#6366f1] cursor-pointer text-[10px] leading-relaxed select-none"
                                title="Clique para copiar para o editor abaixo"
                              >
                                {opt}
                              </div>
                            ))}
                          </div>
                        )}
                      </div>

                      <div className="space-y-1">
                        <label className="text-xs font-bold text-slate-500">Descrição Comercial no Portal</label>
                        <textarea 
                          value={pDescription}
                          onChange={(e) => setPDescription(e.target.value)}
                          rows={4}
                          placeholder="Fale um pouco sobre o corte, cores, embalagem ou use o assistente acima..."
                          className="w-full rounded-xl border bg-slate-50 p-3 text-xs text-slate-800 outline-none focus:border-[#6366f1] focus:bg-white"
                        />
                      </div>

                      <div className="space-y-3 bg-slate-50 p-4 rounded-2xl border border-slate-100">
                        <div className="flex justify-between items-center">
                          <label className="text-xs font-bold text-slate-700">Imagens do Produto (Máximo 5 Fotos)</label>
                          <span className="text-[10px] font-mono bg-slate-200 px-2.5 py-0.5 rounded-full text-slate-600 font-bold">
                            {pPhotos.length} / 5
                          </span>
                        </div>

                        {/* Drag and Drop Zone */}
                        {pPhotos.length < 5 && (
                          <div 
                            onDragEnter={handleDrag}
                            onDragOver={handleDrag}
                            onDragLeave={handleDrag}
                            onDrop={handleDrop}
                            className={`border-2 border-dashed rounded-xl p-6 text-center transition-all cursor-pointer ${
                              isDragActive 
                                ? "border-[#6366f1] bg-[#6366f1]/5" 
                                : "border-slate-300 hover:border-[#6366f1] bg-white"
                            }`}
                            onClick={() => document.getElementById('product-file-input')?.click()}
                          >
                            <input 
                              id="product-file-input"
                              type="file" 
                              multiple 
                              accept="image/*"
                              onChange={handleFileChange}
                              className="hidden"
                            />
                            <Upload className="mx-auto h-8 w-8 text-slate-400 mb-2" />
                            <p className="text-xs font-bold text-slate-700">Arraste fotos do produto aqui</p>
                            <p className="text-[10px] text-slate-400 mt-0.5">ou clique para escolher arquivos do seu computador</p>
                          </div>
                        )}

                        {/* Grid of 5 Slots */}
                        {pPhotos.length > 0 && (
                          <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 pt-2">
                            {pPhotos.map((photo, idx) => (
                              <div key={idx} className="relative aspect-square rounded-xl overflow-hidden border border-slate-200 bg-slate-100 group shadow-sm">
                                <img 
                                  src={photo} 
                                  alt={`Product pic ${idx + 1}`} 
                                  className="h-full w-full object-cover"
                                  referrerPolicy="no-referrer"
                                />
                                
                                {/* Badge overlay */}
                                <div className="absolute top-1 left-1 bg-black/60 backdrop-blur-[2px] text-[9px] text-white px-1.5 py-0.5 rounded-md font-bold">
                                  {idx === 0 ? "Principal" : `Foto ${idx + 1}`}
                                </div>

                                {/* Hover action bar */}
                                <div className="absolute inset-0 bg-slate-900/60 opacity-0 group-hover:opacity-100 flex flex-col justify-between p-1.5 transition-all text-white">
                                  <div className="flex justify-end">
                                    <button
                                      type="button"
                                      onClick={() => handleRemovePhoto(idx)}
                                      className="p-1 rounded-lg bg-rose-600 hover:bg-rose-700 transition"
                                      title="Remover imagem"
                                    >
                                      <Trash2 className="h-3.5 w-3.5" />
                                    </button>
                                  </div>

                                  {/* Movement arrows */}
                                  <div className="flex justify-between items-center w-full mt-auto">
                                    <button
                                      type="button"
                                      disabled={idx === 0}
                                      onClick={() => handleMovePhoto(idx, 'left')}
                                      className={`p-1 rounded-lg bg-white/20 hover:bg-white/40 transition text-white ${
                                        idx === 0 ? "opacity-30 cursor-not-allowed" : "cursor-pointer"
                                      }`}
                                      title="Mover para esquerda"
                                    >
                                      <ArrowLeft className="h-3.5 w-3.5" />
                                    </button>
                                    <button
                                      type="button"
                                      disabled={idx === pPhotos.length - 1}
                                      onClick={() => handleMovePhoto(idx, 'right')}
                                      className={`p-1 rounded-lg bg-white/20 hover:bg-white/40 transition text-white ${
                                        idx === pPhotos.length - 1 ? "opacity-30 cursor-not-allowed" : "cursor-pointer"
                                      }`}
                                      title="Mover para direita"
                                    >
                                      <ChevronRight className="h-3.5 w-3.5" />
                                    </button>
                                  </div>
                                </div>
                              </div>
                            ))}

                            {/* Render placeholder blocks for empty slots */}
                            {Array.from({ length: 5 - pPhotos.length }).map((_, emptyIdx) => {
                              const slotNum = pPhotos.length + emptyIdx + 1;
                              return (
                                <div key={`empty-${slotNum}`} className="aspect-square rounded-xl border border-dashed border-slate-200 bg-slate-50 flex flex-col items-center justify-center text-slate-350 text-[10px]">
                                  <ImageIcon className="h-4 w-4 text-slate-350 mb-1" />
                                  <span>Slot {slotNum}</span>
                                </div>
                              );
                            })}
                          </div>
                        )}

                        {/* URL manual link option */}
                        {pPhotos.length < 5 && (
                          <div className="pt-2 border-t border-slate-100 flex items-center space-x-2">
                            <input 
                              type="text"
                              value={photoUrlInput}
                              onChange={(e) => setPhotoUrlInput(e.target.value)}
                              placeholder="Ou adicione por link da imagem (HTTPS URL)..."
                              className="grow rounded-lg border bg-white px-2.5 py-1.5 text-[11px] text-slate-800 outline-none focus:border-[#6366f1]"
                            />
                            <button
                              type="button"
                              onClick={handleAddPhotoUrl}
                              className="shrink-0 bg-slate-900 text-white rounded-lg px-3 py-1.5 text-[11px] font-bold hover:bg-[#6366f1] transition cursor-pointer"
                            >
                              Adicionar
                            </button>
                          </div>
                        )}
                      </div>

                      <div className="flex space-x-6 pt-2">
                        <label className="flex items-center space-x-2 text-xs font-bold text-slate-600 select-none cursor-pointer">
                          <input 
                            type="checkbox" 
                            checked={pIsFeatured}
                            onChange={(e) => setPIsFeatured(e.target.checked)}
                          />
                          <span>Marcar Destacado</span>
                        </label>

                        <label className="flex items-center space-x-2 text-xs font-bold text-slate-600 select-none cursor-pointer">
                          <input 
                            type="checkbox" 
                            checked={pIsPromotion}
                            onChange={(e) => setPIsPromotion(e.target.checked)}
                          />
                          <span>Marcar Promoção (Desconto)</span>
                        </label>
                      </div>

                    </div>

                  </div>

                  <div className="flex justify-end space-x-3 pt-4 border-t">
                    <button 
                      type="button" 
                      onClick={handleCloseProductForm}
                      className="rounded-xl bg-slate-100 px-6 py-3 text-xs font-bold text-slate-600 hover:bg-slate-200 cursor-pointer"
                    >
                      Cancelar
                    </button>
                    <button 
                      type="submit" 
                      className="rounded-xl bg-slate-900 px-6 py-3 text-xs font-bold text-white hover:bg-[#6366f1] shadow cursor-pointer"
                    >
                      Salvar Cadastro
                    </button>
                  </div>

                </form>
              )}

            </div>
          )}

          {/* TAB: ESTÚDIO IA */}
          {activeTab === 'estúdio-ia' && (
            <div className="space-y-6">
              
              <div className="bg-white border rounded-3xl p-6 shadow-sm space-y-6">
                
                <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between border-b pb-4 gap-4">
                  <div>
                    <h3 className="text-base font-bold text-slate-800">Estúdio Fotográfico Inteligente (fal.ai / Replicate)</h3>
                    <p className="text-xs text-slate-500">Envie a foto do seu produto em cabide ou superfície plana, e nossa IA gera editoriais de alta fidelidade.</p>
                  </div>

                  <div className="rounded-2xl bg-[#6366f1]/10 text-[#6366f1] px-4 py-2.5 text-xs font-bold flex items-center space-x-1.5 self-start sm:self-center shrink-0">
                    <Sparkles className="h-4 w-4 animate-spin-slow" />
                    <span>Conta: {store.aiImagesUsedThisWeek} de {store.planId === 'free' ? 5 : 15} gerações semanais usadas</span>
                  </div>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                  
                  {/* Left settings forms */}
                  <div className="space-y-4">
                    
                    <div className="space-y-1">
                      <label className="text-xs font-bold text-slate-500">1. Foto de Costura/Referência do Produto (Opcional)</label>
                      <input 
                        type="text" 
                        value={aiStudioPhoto}
                        onChange={(e) => setAiStudioPhoto(e.target.value)}
                        placeholder="Insira a URL de um produto no cabide..."
                        className="w-full rounded-xl border bg-slate-50 px-4 py-2.5 text-xs text-slate-800 placeholder-slate-400 font-mono outline-none"
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      
                      <div className="space-y-1">
                        <label className="text-xs font-bold text-slate-500">2. Estilo de Visualização</label>
                        <select 
                          value={aiStyle}
                          onChange={(e) => setAiStyle(e.target.value)}
                          className="w-full rounded-xl border bg-slate-50 px-3 py-2.5 text-xs text-slate-700 outline-none"
                        >
                          <option value="Modelo UGC feminino">Modelo UGC Feminino</option>
                          <option value="Modelo UGC masculino">Modelo UGC Masculino</option>
                          <option value="Produto flutuante (ghost mannequin)">Ghost Mannequin (Invisível)</option>
                          <option value="Flat lay (produto plano)">Flat Lay (Superfície Plano)</option>
                          <option value="Look book editorial">Lookbook Editorial de Luxo</option>
                        </select>
                      </div>

                      <div className="space-y-1">
                        <label className="text-xs font-bold text-slate-500">3. Cenário e Ambiente de Fundo</label>
                        <select 
                          value={aiScenario}
                          onChange={(e) => setAiScenario(e.target.value)}
                          className="w-full rounded-xl border bg-slate-50 px-3 py-2.5 text-xs text-slate-700 outline-none"
                        >
                          <option value="Estúdio branco minimalista">Estúdio Branco Clean</option>
                          <option value="Fundo degradê pastel">Espectro Degradê Pastel</option>
                          <option value="Ambiente urbano (ruas de Milão)">Paris / Milão Urbana</option>
                          <option value="Natureza (praia ensolarada do Caribe)">Caribe / Praia e Sol</option>
                          <option value="Interior moderno (loft minimalista)">Loft Moderno Paulista</option>
                          <option value="Personalizado (descreva)">Outro... (Descrever abaixo)</option>
                        </select>
                      </div>

                    </div>

                    {aiScenario === 'Personalizado (descreva)' && (
                      <div className="space-y-1">
                        <label className="text-xs font-bold text-slate-500">Descreva o cenário customizado em inglês ou português:</label>
                        <input 
                          type="text" 
                          value={aiCustomSec}
                          onChange={(e) => setAiCustomSec(e.target.value)}
                          placeholder="Ex: Fashion showroom luxury background with warm illumination..."
                          className="w-full rounded-xl border bg-slate-50 px-3.5 py-2.5 text-xs outline-none"
                        />
                      </div>
                    )}

                    <div className="grid grid-cols-2 gap-4">
                      
                      <div className="space-y-1">
                        <label className="text-xs font-bold text-slate-500">4. Pose do Modelo</label>
                        <select 
                          value={aiPose}
                          onChange={(e) => setAiPose(e.target.value)}
                          className="w-full rounded-xl border bg-slate-50 px-3 py-2.5 text-xs text-slate-700 outline-none"
                        >
                          <option value="Em pé frontal">Em pé frontal clássico</option>
                          <option value="Em pé de lado">De Perfil Lateral</option>
                          <option value="Andando">Andando dinâmico</option>
                          <option value="Cruzando os braços">Cruzando os Braços</option>
                        </select>
                      </div>

                      <div className="space-y-1">
                        <label className="text-xs font-bold text-slate-500">5. Expressão Facial</label>
                        <select 
                          value={aiExpression}
                          onChange={(e) => setAiExpression(e.target.value)}
                          className="w-full rounded-xl border bg-slate-50 px-3 py-2.5 text-xs text-slate-700 outline-none"
                        >
                          <option value="Sorrindo">Sorridente e Alegre</option>
                          <option value="Séria/editorial">Fria / Editorial Haute Couture</option>
                          <option value="Olhando para o lado">Contemplativa Olhando de Perfil</option>
                        </select>
                      </div>

                    </div>

                    <button 
                      onClick={triggerAiGenerator}
                      disabled={!!aiImageStatus}
                      className="w-full rounded-xl bg-slate-900 py-3.5 text-xs font-bold text-white hover:bg-[#6366f1] shadow cursor-pointer transition disabled:opacity-70 flex items-center justify-center space-x-2"
                    >
                      <Sparkles className="h-4.5 w-4.5 text-yellow-400" />
                      <span>{aiImageStatus ? 'IA renderizando cenário...' : 'Gerar Fotos Profissionais com IA'}</span>
                    </button>

                    {/* AI Video generator tab toggle block */}
                    <div className="border border-dashed border-slate-200 rounded-3xl p-4 flex flex-col md:flex-row gap-4 items-center justify-between">
                      <div className="space-y-1 text-center md:text-left">
                        <h4 className="text-xs font-bold text-slate-800 flex items-center justify-center md:justify-start space-x-1.5">
                          <Video className="h-4 w-4 text-purple-600" />
                          <span>Gerador de Vídeos de Desfile AI (Veo 3.1)</span>
                        </h4>
                        <p className="text-[10px] text-slate-400 leading-normal">Gere clipes de modelagens reais de 5s simulando passarelas e estúdios dinâmicos.</p>
                      </div>

                      <button 
                        type="button" 
                        onClick={() => setShowVideoModal(true)}
                        className="rounded-xl bg-purple-600/10 text-purple-600 text-[10px] font-bold px-3.5 py-2 hover:bg-purple-600 hover:text-white transition cursor-pointer"
                      >
                        Gerar Vídeo Desfile
                      </button>
                    </div>

                  </div>

                  {/* Right result preview viewport */}
                  <div className="border border-slate-100 rounded-3xl bg-slate-50 p-6 flex flex-col items-center justify-center min-h-[340px] shadow-inner relative">
                    {aiImageStatus ? (
                      <div className="text-center space-y-4">
                        <div className="mx-auto h-12 w-12 animate-spin rounded-full border-4 border-[#6366f1] border-t-transparent" />
                        <p className="text-xs font-bold text-[#6366f1] font-mono leading-none animate-pulse">{aiImageStatus}</p>
                      </div>
                    ) : aiResultUrl ? (
                      <div className="text-center space-y-4 w-full">
                        <img 
                          src={aiResultUrl} 
                          alt="AI generated modeling fashion" 
                          referrerPolicy="no-referrer"
                          className="mx-auto max-h-80 rounded-2xl shadow-md border object-cover bg-white" 
                        />
                        <div className="flex flex-wrap items-center justify-center gap-2">
                          <a 
                            href={aiResultUrl} 
                            target="_blank" 
                            rel="noreferrer"
                            className="rounded-xl border border-slate-300 bg-white px-4 py-2 text-[10px] font-bold text-slate-700 hover:bg-slate-50 cursor-pointer"
                          >
                            Download Imagem HD
                          </a>
                          <button 
                            type="button" 
                            onClick={() => {
                              setPPhotos([aiResultUrl]);
                              setPName("Novo Modelo de Editorial IA");
                              setIsAddingProduct(true);
                              setActiveTab('produtos');
                            }}
                            className="rounded-xl bg-slate-900 px-4 py-2 text-[10px] font-bold text-white hover:bg-[#6366f1] cursor-pointer"
                          >
                            Salvar em Novo Produto
                          </button>
                        </div>
                      </div>
                    ) : (
                      <div className="text-center space-y-2 text-slate-400">
                        <ImageIcon className="mx-auto h-12 w-12 text-slate-300" />
                        <h4 className="text-xs font-bold leading-none text-slate-500">Visualização do Estúdio IA</h4>
                        <p className="text-[10px] max-w-xs mx-auto">Sua fotografia processada e integrada a modelos profissionais aparecerá aqui.</p>
                      </div>
                    )}
                  </div>

                </div>

              </div>
            </div>
          )}

          {/* TAB: DESIGN DA LOJA */}
          {activeTab === 'design' && (
            <div className="space-y-6">
              <div className="bg-white border rounded-3xl p-6 shadow-sm space-y-6">
                <div>
                  <h3 className="text-base font-bold text-slate-800">Seletor de Templates (25 estilos exclusivos de alta costura)</h3>
                  <p className="text-xs text-slate-500 font-medium">Altere de forma instantânea a identidade, cores primárias, tipografias e molduras de toda a sua vitrine.</p>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                  
                  {/* Left list select templates */}
                  <div className="lg:col-span-2 space-y-4">
                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 max-h-[420px] overflow-y-auto pr-2 scrollbar-thin">
                      {TEMPLATES_LIST.map(tpl => (
                        <div 
                          key={tpl.id}
                          onClick={() => {
                            setStTemplate(tpl.id);
                            setStPrimary(tpl.primaryColor);
                            setStAccent(tpl.accentColor);
                          }}
                          className={`relative cursor-pointer rounded-2xl border-2 p-3 transition-all ${
                            stTemplate === tpl.id 
                              ? 'border-[#6366f1] bg-[#6366f1]/5 shadow-sm' 
                              : 'border-slate-100 hover:bg-slate-50'
                          }`}
                        >
                          <span className="text-xs font-bold block leading-none text-slate-800 mb-1">{tpl.name}</span>
                          <span className="text-[9px] text-slate-400 leading-tight block truncate">{tpl.style}</span>
                          {stTemplate === tpl.id && (
                            <div className="absolute top-2.5 right-2 h-4 w-4 bg-[#6366f1] rounded-full flex items-center justify-center text-white">
                              <Check className="h-2.5 w-2.5" />
                            </div>
                          )}
                        </div>
                      ))}
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 border-t pt-4">
                      
                      <div className="space-y-1">
                        <label className="text-xs font-bold text-slate-500">Cor Primária (Hex)</label>
                        <div className="flex space-x-2">
                          <input 
                            type="color" 
                            value={stPrimary}
                            onChange={(e) => setStPrimary(e.target.value)}
                            className="h-10 w-10 border rounded cursor-pointer"
                          />
                          <input 
                            type="text" 
                            value={stPrimary}
                            onChange={(e) => setStPrimary(e.target.value)}
                            className="rounded-xl border bg-slate-50 px-3.5 py-2 text-xs font-mono w-full"
                          />
                        </div>
                      </div>

                      <div className="space-y-1">
                        <label className="text-xs font-bold text-slate-500">Cor de Destaque / Botões (Hex)</label>
                        <div className="flex space-x-2">
                          <input 
                            type="color" 
                            value={stAccent}
                            onChange={(e) => setStAccent(e.target.value)}
                            className="h-10 w-10 border rounded cursor-pointer"
                          />
                          <input 
                            type="text" 
                            value={stAccent}
                            onChange={(e) => setStAccent(e.target.value)}
                            className="rounded-xl border bg-slate-50 px-3.5 py-2 text-xs font-mono w-full"
                          />
                        </div>
                      </div>

                    </div>
                  </div>

                  {/* Right Live mock preview display */}
                  <div className="lg:col-span-1 rounded-3xl bg-slate-900 text-white p-5 space-y-4 shadow-xl flex flex-col justify-between border border-slate-800">
                    <div className="space-y-1">
                      <span className="text-[9px] font-black tracking-widest text-[#6366f1] uppercase font-mono">Live Mockup View</span>
                      <h4 className="text-xs font-bold">Simulação de Renderização</h4>
                    </div>

                    {/* Simulated card mimicking store choices */}
                    <div className="rounded-2xl bg-white text-slate-800 p-4 shadow-md space-y-3 font-sans border-t border-slate-200">
                      <div className="flex items-center space-x-2">
                        <div 
                          className="h-6 w-6 rounded-full" 
                          style={{ backgroundColor: stPrimary }} 
                        />
                        <span className="text-xs font-bold">{stName}</span>
                      </div>

                      <div className="aspect-square bg-slate-100 rounded-xl relative overflow-hidden border">
                        <div className="absolute top-2 left-2 bg-[#6366f1] text-[8px] text-white px-2 py-0.5 rounded uppercase font-black tracking-wider">
                          Novidade
                        </div>
                        <div className="absolute bottom-2 right-2 text-[10px] font-bold text-slate-900 bg-white shadow-xs px-2 py-0.5 rounded">
                          R$ 189,90
                        </div>
                      </div>

                      <button 
                        style={{ backgroundColor: stAccent }}
                        className="w-full text-xs text-center text-white py-1.5 rounded-lg font-bold"
                      >
                        Comprar via WhatsApp
                      </button>
                    </div>

                    <button 
                      onClick={handleSaveStoreSettings}
                      className="w-full rounded-xl bg-[#6366f1] py-2.5 text-xs font-bold text-white hover:bg-indigo-600 shadow cursor-pointer transition"
                    >
                      Salvar Novo Design de Vitrine
                    </button>
                  </div>

                </div>

              </div>
            </div>
          )}

          {/* TAB: MARKETING */}
          {activeTab === 'marketing' && (
            <div className="space-y-8">
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                
                {/* Promo Coupon creator mockup tool */}
                <div className="rounded-3xl border bg-white p-6 shadow-sm space-y-4">
                  <div className="space-y-1">
                    <h4 className="text-sm font-bold text-slate-800 flex items-center space-x-1.5">
                      <Percent className="h-4.5 w-4.5 text-[#6366f1]" />
                      <span>Cupons de Desconto Autogerados</span>
                    </h4>
                    <p className="text-xs text-slate-500">Crie regras e códigos de deduções promocionais na finalização de fardos.</p>
                  </div>

                  <div className="space-y-3">
                    <div className="flex space-x-2">
                      <input 
                        type="text" 
                        placeholder="Código: Ex: CHIC15"
                        defaultValue="CHIC10"
                        className="rounded-xl border bg-slate-50 px-3.5 py-2 text-xs w-full outline-none font-bold placeholder-slate-400" 
                      />
                      <input 
                        type="text" 
                        placeholder="Dedução: Ex: 10%" 
                        defaultValue="10%"
                        className="rounded-xl border bg-slate-50 px-3.5 py-2 text-xs w-1/3 outline-none" 
                      />
                    </div>
                    <button 
                      onClick={() => {
                        setFeedback("Cupom CHIC10 cadastrado e ativo!");
                        setTimeout(() => setFeedback(null), 3000);
                      }}
                      className="w-full rounded-xl bg-slate-900 py-2.5 text-xs font-bold text-white hover:bg-[#6366f1] transition cursor-pointer"
                    >
                      Cadastrar Cupom
                    </button>
                  </div>
                </div>

                {/* PDF Catalog share generator */}
                <div className="rounded-3xl border bg-white p-6 shadow-sm space-y-4">
                  <div className="space-y-1">
                    <h4 className="text-sm font-bold text-slate-800 flex items-center space-x-1.5">
                      <FileText className="h-4.5 w-4.5 text-[#a855f7]" />
                      <span>Catálogo Virtual PDF</span>
                    </h4>
                    <p className="text-xs text-slate-500">Gere um catálogo estático diagramado limpo com preços direto da sua database.</p>
                  </div>

                  <p className="text-xs text-slate-400 leading-normal">Nosso motor organiza todas as roupas ativas em formato pronto para impressão ou compartilhamento rápido em anexos.</p>
                  
                  <button 
                    onClick={() => alert("Seu Catálogo de Moda PDF em pt-BR foi compilado com sucesso a partir do catálogo ativo no banco de dados!")}
                    className="w-full rounded-xl bg-[#a855f7] py-2.5 text-xs font-bold text-white hover:bg-purple-600 transition cursor-pointer"
                  >
                    Baixar Catálogo de Coleções PDF
                  </button>
                </div>

              </div>

            </div>
          )}

          {/* TAB: CONFIGURAÇÕES */}
          {activeTab === 'configuracoes' && (
            <div className="space-y-8">
              
              <div className="bg-white border rounded-3xl p-6 shadow-sm space-y-6">
                <div>
                  <h3 className="text-base font-bold text-slate-800">Configurações Gerais de Negócio</h3>
                  <p className="text-xs text-slate-500 font-medium">Controle canais comerciais, links personalizados e dados tributários da empresa.</p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  
                  <div className="space-y-4">
                    
                    <div className="space-y-1">
                      <label className="text-xs font-bold text-slate-500">Nome Oficial Comercial</label>
                      <input 
                        type="text" 
                        value={stName}
                        onChange={(e) => setStName(e.target.value)}
                        className="w-full rounded-xl border bg-slate-50 px-3.5 py-2.5 text-xs text-slate-800 outline-none"
                      />
                    </div>

                    <div className="space-y-1">
                      <label className="text-xs font-bold text-slate-500">WhatsApp Oficial de Vendas (Formato Internacional com DDD)</label>
                      <input 
                        type="text" 
                        value={stPhone}
                        onChange={(e) => setStPhone(e.target.value)}
                        className="w-full rounded-xl border bg-slate-50 px-3.5 py-2.5 text-xs text-slate-800 outline-none font-mono"
                      />
                      <p className="text-[10px] text-slate-400">Preencha iniciando com ddd sem caracteres. Ex: 5511999992222.</p>
                    </div>

                    <div className="space-y-1">
                      <label className="text-xs font-bold text-slate-500">Endereço de Postagem Física (Mostrado na vitrine)</label>
                      <input 
                        type="text" 
                        value={stAddress}
                        onChange={(e) => setStAddress(e.target.value)}
                        className="w-full rounded-xl border bg-slate-50 px-3.5 py-2.5 text-xs text-slate-800 outline-none"
                      />
                    </div>

                    <div className="p-4 rounded-xl border bg-slate-50 border-slate-150 flex items-center justify-between">
                      <div className="space-y-0.5">
                        <span className="text-xs font-bold text-slate-800">Ativar Gate de Compra (Atacado vs Varejo)</span>
                        <p className="text-[10px] text-slate-400">Exige que o visitante declare se compra atacado ou varejo.</p>
                      </div>
                      
                      <input 
                        type="checkbox" 
                        checked={stGateEnabled}
                        onChange={(e) => setStGateEnabled(e.target.checked)}
                      />
                    </div>

                  </div>

                  <div className="space-y-4">
                    
                    {/* Domain customization panel */}
                    <div className="rounded-2xl bg-indigo-50/50 p-5 space-y-4 border border-indigo-150 shadow-xs">
                      <div className="flex items-center space-x-2">
                        <Globe className="h-5 w-5 text-[#6366f1]" />
                        <span className="text-xs font-bold text-slate-950">Domínio Customizado (Plano Pro/Ultra)</span>
                      </div>

                      <div className="space-y-2">
                        <input 
                          type="text" 
                          value={stDomain}
                          onChange={(e) => setStDomain(e.target.value)}
                          placeholder="Ex: www.seudominio.com.br"
                          className="w-full rounded-xl border bg-white px-3.5 py-2 text-xs outline-none focus:border-[#6366f1] text-slate-800 font-mono"
                        />
                        
                        <div className="text-[10px] text-slate-500 space-y-1 bg-white p-3 rounded-lg border leading-relaxed">
                          <p className="font-bold">Para apontar corretamento configure em seu DNS:</p>
                          <p>• Criar entrada tipo <span className="font-mono text-[#6366f1]">CNAME</span></p>
                          <p>• Nome / Host: <span className="font-mono font-bold">@</span> ou <span className="font-mono font-bold">www</span></p>
                          <p>• Destino: <span className="font-mono text-[#6366f1]">cname.vestuai.com.br</span></p>
                        </div>

                        <button 
                          type="button" 
                          onClick={testDnsIntegration}
                          className="w-full rounded-xl bg-[#6366f1] py-2 text-xs font-bold text-white hover:bg-slate-900 transition mt-2 cursor-pointer"
                        >
                          Apontar e Testar Integração DNS
                        </button>
                      </div>
                    </div>

                  </div>

                </div>

                <div className="flex justify-end pt-4 border-t">
                  <button 
                    onClick={handleSaveStoreSettings}
                    className="rounded-xl bg-slate-950 px-6 py-3 text-xs font-bold text-white hover:bg-[#6366f1] transition cursor-pointer shadow"
                  >
                    Salvar Parâmetros e Atualizar
                  </button>
                </div>
              </div>

            </div>
          )}

        </div>

      </main>

      {/* 3. PREMIUM VEO VIDEO PRODUCTION MODAL ACCESS GATE */}
      {showVideoModal && (
        <div className="fixed inset-0 z-[1400] flex items-center justify-center bg-slate-950/70 p-4 backdrop-blur-sm">
          <div className="w-full max-w-md rounded-3xl bg-slate-900 text-slate-300 p-6 relative border border-slate-800 space-y-6 text-center">
            
            <button 
              onClick={() => setShowVideoModal(false)}
              className="absolute top-4 right-4 p-2 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-400 cursor-pointer"
            >
              <X className="h-4.5 w-4.5" />
            </button>

            <div className="mx-auto h-14 w-14 bg-gradient-to-tr from-pink-500 to-purple-600 rounded-2xl flex items-center justify-center text-white shadow-lg animate-pulse">
              <Video className="h-7 w-7" />
            </div>

            <div className="space-y-2">
              <h3 className="text-base sm:text-lg font-black tracking-tight text-white flex items-center justify-center space-x-1.5">
                <span>Esta funcionalidade não está disponível no seu plano</span>
              </h3>
              <p className="text-xs text-slate-400 max-w-sm mx-auto">
                Para desbloquear a modelagem dinâmica do <span className="font-bold text-[#6366f1]">Desfile de Moda IA (Gerador Veo 3.1)</span> de até 5 segundos equota prioritária de fardo mestre, mude seu plano para Ultra.
              </p>
            </div>

            <div className="bg-slate-950/50 p-4 rounded-2xl border border-slate-800 text-left text-[11px] leading-normal space-y-1 text-slate-400">
              <p className="font-bold text-white">O módulo Ultra inclui:</p>
              <p>✓ 5 clipes de desfile real por semana em 1080p</p>
              <p>✓ 50 fotos alta-resolução com IA por semana</p>
              <p>✓ Menor taxa transacional do mercado: apenas 1%</p>
            </div>

            <div className="flex flex-col sm:flex-row gap-2">
              <button 
                type="button" 
                onClick={() => setShowVideoModal(false)}
                className="w-full rounded-xl bg-slate-800 py-3 text-xs font-bold text-slate-400 hover:text-white cursor-pointer"
              >
                Agora não
              </button>
              
              <button 
                type="button" 
                onClick={async () => {
                  const token = localStorage.getItem('vestu_token') || '';
                  const res = await fetch('/api/dashboard/subscribe', {
                    method: 'POST',
                    headers: { 
                      'Content-Type': 'application/json',
                      'Authorization': `Bearer ${token}`
                    },
                    body: JSON.stringify({ planId: 'ultra' })
                  });
                  if (res.ok) {
                    alert("Parabéns! Upgrade operacional confirmado para o Plano ULTRA profissional. Vídeo gerador e passarela dinâmicas desbloqueadas!");
                    setShowVideoModal(false);
                    onRefreshSession();
                    loadLojistaData();
                  }
                }}
                className="w-full rounded-xl bg-gradient-to-tr from-pink-500 to-purple-600 py-3 text-xs font-black text-white hover:opacity-90 shadow cursor-pointer"
              >
                Fazer Upgrade para ULTRA (R$ 350)
              </button>
            </div>

          </div>
        </div>
      )}

    </div>
  );
}
