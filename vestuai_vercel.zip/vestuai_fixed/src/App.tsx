import React, { useState, useEffect } from 'react';
import { VestuAiSymbol } from './components/VestuAiLogo';
import { 
  Sparkles, 
  ArrowRight, 
  Check, 
  CheckCircle, 
  BarChart, 
  Store, 
  Phone, 
  MessageSquare, 
  Heart,
  Smartphone,
  ChevronDown,
  Lock,
  ArrowLeft
} from 'lucide-react';
import { User, Store as StoreType } from './types';
import { Header } from './components/Header';
import { Footer } from './components/Footer';
import { LojistaDashboardView } from './components/LojistaDashboardView';
import { SuperadminPanel } from './components/SuperadminPanel';
import { StorefrontView } from './components/StorefrontView';
import { TEMPLATES_LIST } from './components/StoreTemplates';

export default function App() {
  // SPA Routing state: '/' | '/entrar' | '/cadastro' | '/onboarding' | '/dashboard' | '/admin' | '/loja/:slug'
  const [route, setRoute] = useState<string>('/');
  const [activeStoreSlug, setActiveStoreSlug] = useState<string>('');

  // Authorized Sessions State
  const [sessionToken, setSessionToken] = useState<string>(() => localStorage.getItem('vestu_token') || '');
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [currentStore, setCurrentStore] = useState<StoreType | null>(null);
  const [sessionLoading, setSessionLoading] = useState(true);

  // Authentication form fields
  const [authEmail, setAuthEmail] = useState('');
  const [authPassword, setAuthPassword] = useState('');
  const [authName, setAuthName] = useState('');
  const [authPhone, setAuthPhone] = useState('');
  const [authError, setAuthError] = useState<string | null>(null);

  // Onboarding stepper fields
  const [onbStep, setOnbStep] = useState(1);
  const [onbStoreName, setOnbStoreName] = useState('');
  const [onbNiche, setOnbNiche] = useState('Roupas Femininas');
  const [onbPhone, setOnbPhone] = useState('');

  // Accordion FAQ flags
  const [openFaqId, setOpenFaqId] = useState<number | null>(null);

  // 1. Session verification on boot
  useEffect(() => {
    async function verifySession() {
      if (!sessionToken) {
        setSessionLoading(false);
        return;
      }
      try {
        const res = await fetch('/api/auth/me', {
          headers: { 'Authorization': `Bearer ${sessionToken}` }
        });
        if (res.ok) {
          const data = await res.json();
          if (data.user) {
            setCurrentUser(data.user);
            setCurrentStore(data.store);
            // Auto route based on roles
            if (data.user.role === 'superadmin') {
              setRoute('/admin');
            } else if (data.store?.name) {
              setRoute('/dashboard');
            } else {
              setRoute('/onboarding');
            }
          } else {
            // invalid local token
            localStorage.removeItem('vestu_token');
            setSessionToken('');
          }
        }
      } catch (e) {
        console.error("Session verification failed", e);
      } finally {
        setSessionLoading(false);
      }
    }

    verifySession();
  }, [sessionToken]);

  // Handle address paths manually (e.g. if link contains slug /loja/vibechic)
  useEffect(() => {
    const path = window.location.pathname;
    if (path.startsWith('/loja/')) {
      const slug = path.split('/loja/')[1];
      if (slug) {
        setActiveStoreSlug(slug);
        setRoute('/loja/:slug');
      }
    }
  }, []);

  const handleNavigate = (targetRoute: string) => {
    setRoute(targetRoute);
    window.scrollTo({ top: 0, behavior: 'smooth' });
    setAuthError(null);
    // Reset onboarding step when going back to onboarding
    if (targetRoute === '/onboarding') setOnbStep(1);
  };

  const handleNavigateToStore = (slug: string) => {
    setActiveStoreSlug(slug);
    setRoute('/loja/:slug');
    window.location.hash = `loja-${slug}`; // friendly hash
    window.scrollTo({ top: 0 });
  };

  // Sign in execution
  const executeLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError(null);
    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: authEmail, password: authPassword })
      });
      if (res.ok) {
        const data = await res.json();
        localStorage.setItem('vestu_token', data.token);
        setSessionToken(data.token);
        setCurrentUser(data.user);
        setCurrentStore(data.store);
        
        if (data.user.role === 'superadmin') {
          setRoute('/admin');
        } else {
          setRoute('/dashboard');
        }
        // clear inputs
        setAuthEmail('');
        setAuthPassword('');
      } else {
        const err = await res.json();
        setAuthError(err.error || 'Credenciais inválidas.');
      }
    } catch (e) {
      setAuthError('Erro ao estabelecer conexão de rede.');
    }
  };

  // Sign up registration
  const executeRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError(null);
    try {
      const res = await fetch('/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: authName,
          email: authEmail,
          password: authPassword,
          phone: authPhone
        })
      });
      if (res.ok) {
        const data = await res.json();
        localStorage.setItem('vestu_token', data.token);
        setSessionToken(data.token);
        setCurrentUser(data.user);
        setCurrentStore(data.store);
        
        // Lead newly registered lojistas straight to onboarding stepper
        setRoute('/onboarding');
        setOnbStep(1);

        // clear inputs
        setAuthName('');
        setAuthEmail('');
        setAuthPassword('');
        setAuthPhone('');
      } else {
        const err = await res.json();
        setAuthError(err.error || 'Falha ao processar cadastro.');
      }
    } catch (e) {
      setAuthError('Problema técnico de conexão com servidores.');
    }
  };

  // Complete onboarding stepper
  const executeOnboarding = async () => {
    if (!onbStoreName || !onbPhone) {
      alert("Por favor preencha todos os campos do onboarding.");
      return;
    }

    try {
      const token = localStorage.getItem('vestu_token') || '';
      // Update created default store name and phone
      const response = await fetch(`/api/store/${currentStore?.slug}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({
          name: onbStoreName,
          phone: onbPhone,
          niche: onbNiche,
        })
      });

      if (response.ok) {
        const data = await response.json();
        setCurrentStore(data.store);
        setRoute('/dashboard');
      } else {
        alert("Falha operacional ao concluir o onboarding da sua loja.");
      }
    } catch (e) {
      console.error(e);
    }
  };

  // Logouts
  const handleLogout = async () => {
    const token = localStorage.getItem('vestu_token') || '';
    await fetch('/api/auth/logout', {
      method: 'POST',
      headers: { 'Authorization': `Bearer ${token}` }
    });
    localStorage.removeItem('vestu_token');
    setSessionToken('');
    setCurrentUser(null);
    setCurrentStore(null);
    setRoute('/');
  };

  // Sync session state refresh
  const triggerSessionRefresh = async () => {
    const token = localStorage.getItem('vestu_token') || '';
    const res = await fetch('/api/auth/me', {
      headers: { 'Authorization': `Bearer ${token}` }
    });
    if (res.ok) {
      const data = await res.json();
      setCurrentUser(data.user);
      setCurrentStore(data.store);
    }
  };

  // Impersonating handler callback
  const handleImpersonateLogin = (newToken: string, user: User, store: StoreType | null) => {
    localStorage.setItem('vestu_token', newToken);
    setSessionToken(newToken);
    setCurrentUser(user);
    setCurrentStore(store);
    setRoute('/dashboard');
  };

  // FAQS dataset
  const faqs = [
    { q: 'Preciso saber programar para criar minha vitrine?', a: 'Absolutamente não! O portal foi elaborado com foco em simplicidade extrema de faturamento de fardo. Bastam cliques simples para estruturar catálogos adicionando vestidos e sapatos de forma interativa de alta moda brasileira.' },
    { q: 'Posso utilizar meu endereço de domínio próprio?', a: 'Sim! Planos Pro e superiores suportam conexão CNAME livre para personalizar sites no padrão www.seudominio.com.br.' },
    { q: 'Como funcionam os 14 dias de teste gratuítos?', a: 'Ao se cadastrar sob o ecossistema, o Plano Pro é ativado em fase de testes automáticos gratuitos por duas semanas inteiras. Nenhum cartão cadastrado é exigido!' },
    { q: 'É cobrado algum tipo de taxa por checkout no WhatsApp?', a: 'Não há cobrança direta de intermediações de cartões nas suas transações de WhatsApp. Os checkouts chegam formatados limpos e sem descontos direto para fechar condições diretamente com você.' },
    { q: 'Como atua a modelagem por inteligência artificial no Estúdio?', a: 'Nossos algoritmos do Estúdio IA recebem sua imagem simples no cabide e realizam fotomontagem foto-realista mesclando sutilmente texturas de pano sob modelos humanos no cenário correspondente selecionado.' },
    { q: 'Qual o faturamento semanal de imagens por inteligência artificial?', a: 'A contabilidade de consumo semanal é renovada de forma autônoma dependendo do plano do lojista (5 free, 15 Pro, 30 Pro Max, 50 Ultra).' },
    { q: 'Os clientes finais necessitam cadastrar contas e logins?', a: 'Nunca! Visitantes acessam sites no formato anônimo rápido em 1 clique bastando preencher perfis caso o Gate de Atacado esteja ativo.' },
    { q: 'Consigo suspender ou mudar de plano a qualquer instante?', a: 'Seguramente. Pelo seu painel financeiro é possível subir de plano, rebaixar ou dar cabo com total autonomia sem burocracias de fidelidade.' }
  ];

  if (sessionLoading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-slate-50 text-slate-700">
        <div className="text-center space-y-3">
          <div className="mx-auto h-12 w-12 animate-spin rounded-full border-4 border-[#6366f1] border-t-transparent" />
          <p className="text-sm font-semibold">Carregando faturamento e seguranças do ecossistema...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 text-slate-800 flex flex-col font-sans selection:bg-[#6366f1] selection:text-white">
      
      {/* ROUTE COMPILATION MOUNT */}

      {/* A. VISITOR storefront view */}
      {route === '/loja/:slug' && (
        <StorefrontView 
          slug={activeStoreSlug} 
          onNavigateHome={() => handleNavigate('/')} 
        />
      )}

      {/* B. MERCHANTS panel workspace view */}
      {route === '/dashboard' && currentUser && currentStore && (
        <LojistaDashboardView 
          store={currentStore}
          user={currentUser}
          onLogout={handleLogout}
          onRefreshSession={triggerSessionRefresh}
          onChangeView={handleNavigate}
          onNavigateToStorefront={handleNavigateToStore}
        />
      )}

      {/* C. SYSTEM CENTRAL ADMIN root workspace view */}
      {route === '/admin' && currentUser?.role === 'superadmin' && (
        <SuperadminPanel 
          onBackToApp={() => {
            // Revert or verify current token
            triggerSessionRefresh().then(() => setRoute('/dashboard'));
          }}
          onImpersonate={handleImpersonateLogin}
        />
      )}

      {/* D. VISITS SECTOR REGISTRATION & ACCELERATION PAGES */}

      {/* Landing home page portal */}
      {route === '/' && (
        <div className="flex-1 flex flex-col justify-between">
          <Header onNavigate={handleNavigate} />

          {/* Hero section screen */}
          <section className="relative overflow-hidden py-16 lg:py-24 bg-gradient-to-b from-[#fbfbfe] to-slate-50 border-b">
            <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
              
              <div className="space-y-6 max-w-xl text-center lg:text-left">
                <span className="bg-[#6366f1]/10 text-[#6366f1] font-black text-xs uppercase tracking-widest px-3 py-1.5 rounded-full inline-flex items-center space-x-1">
                  <Sparkles className="h-4.5 w-4.5 animate-spin-slow" />
                  <span>SaaS Oficial de Vendas de Moda</span>
                </span>
                
                <h1 className="text-3xl sm:text-5xl font-black tracking-tight text-[#0f172a] leading-tight">
                  Sua Vitrine de Moda Online Editada com <span className="bg-gradient-to-r from-[#6366f1] to-[#a855f7] bg-clip-text text-transparent">Inteligência Artificial</span>
                </h1>
                
                <p className="text-sm sm:text-base text-slate-500 leading-relaxed">
                  Crie em instantes fotos luxuosas profissionais, configure gates de preços diferenciados para Varejo e Atacado com proteção de blur e acelere vendas despachando checkouts detalhados direto para o WhatsApp.
                </p>

                <div className="flex flex-col sm:flex-row items-center justify-center lg:justify-start gap-4">
                  <button 
                    onClick={() => handleNavigate('/cadastro')}
                    className="w-full sm:w-auto inline-flex items-center justify-center space-x-2 rounded-xl bg-slate-900 px-6 py-4 text-xs font-bold text-white hover:bg-[#6366f1] shadow-lg transition cursor-pointer"
                  >
                    <span>Montar Minha Loja Grátis</span>
                    <ArrowRight className="h-4 w-4" />
                  </button>
                  <button 
                    onClick={() => handleNavigateToStore('vibechic')}
                    className="w-full sm:w-auto inline-flex items-center justify-center space-x-2 rounded-xl border border-slate-200 bg-white px-6 py-4 text-xs font-bold text-slate-700 hover:bg-slate-50 transition cursor-pointer"
                  >
                    <span>Ver Loja de Demonstração</span>
                  </button>
                </div>

                <div className="pt-4 flex items-center justify-center lg:justify-start space-x-6 text-xs text-slate-400 font-medium">
                  <div className="flex items-center space-x-1">
                    <Check className="h-4 w-4 text-[#6366f1]" />
                    <span>Sem cartão de crédito</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <Check className="h-4 w-4 text-[#6366f1]" />
                    <span>Plano Pro grátis por 14 dias</span>
                  </div>
                </div>

              </div>

              {/* Dynamic visual preview cards mockup grid */}
              <div id="modelos" className="relative h-96 sm:h-[450px] border border-slate-200/50 rounded-[2.5rem] bg-indigo-50/50 shadow-inner flex items-center justify-center p-6 select-none leading-none">
                <div className="absolute inset-0 bg-gradient-to-tr from-white via-transparent to-[#6366f1]/5 opacity-60 rounded-[2.5rem]" />
                
                <div className="relative text-stone-800 bg-white p-6 rounded-3xl max-w-sm w-full space-y-4 shadow-xl border">
                  <div className="flex items-center justify-between border-b pb-3">
                    <div className="flex items-center space-x-2 font-bold text-xs text-slate-800">
                      <Sparkles className="h-4.5 w-4.5 text-[#6366f1] shrink-0" />
                      <span>Estúdio de Fotos IA VestuAI</span>
                    </div>
                    <span className="text-[10px] text-emerald-500 font-mono font-bold uppercase shrink-0">4K PREMIUM</span>
                  </div>

                  <div className="aspect-square bg-slate-50 rounded-2xl relative overflow-hidden border">
                    <img 
                      src="https://images.unsplash.com/photo-1496747611176-843222e1e57c?auto=format&fit=crop&w=500&q=80" 
                      alt="Product dress photoshoot mock" 
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover transition" 
                    />
                    <div className="absolute top-2.5 left-2.5 rounded bg-black/60 px-2 py-0.5 text-[8px] font-black text-white uppercase tracking-wider">
                      Modelo UGC / Fundo Paris
                    </div>
                  </div>

                  <p className="text-[11px] text-slate-400 italic text-center leading-snug">"O Estúdio IA gerou fotos luxuosas que triplicaram minhas vendas no Instagram em poucas semanas."</p>
                </div>
              </div>

            </div>
          </section>

          {/* Onboarding steps tracker */}
          <section className="py-16 bg-white border-b">
            <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 space-y-12">
              <div className="text-center space-y-2">
                <h2 className="text-2xl sm:text-3xl font-black text-[#0f172a] tracking-tight">Vender online nunca foi tão rápido</h2>
                <p className="text-xs sm:text-sm text-slate-400">Monte seu negócio completo no WhatsApp em 3 etapas descomplicadas.</p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
                
                <div className="space-y-4 p-4 border border-dashed rounded-3xl border-slate-150">
                  <div className="mx-auto h-12 w-12 bg-[#6366f1]/10 rounded-2xl flex items-center justify-center text-[#6366f1] font-black text-sm">
                    1
                  </div>
                  <h4 className="font-bold text-slate-800 text-sm">Registre sua conta em 30s</h4>
                  <p className="text-xs text-slate-400 leading-relaxed">Crie seu login corporativo na plataforma VestuAI em segundos, sem necessidade de cartões ou depósitos iniciais.</p>
                </div>

                <div className="space-y-4 p-4 border border-dashed rounded-3xl border-slate-150">
                  <div className="mx-auto h-12 w-12 bg-[#a855f7]/10 rounded-2xl flex items-center justify-center text-[#a855f7] font-black text-sm">
                    2
                  </div>
                  <h4 className="font-bold text-slate-800 text-sm">Monte seu fardo comercial</h4>
                  <p className="text-xs text-slate-400 leading-relaxed">Personalize seu design selecionando entre 25 templates, insira sapatos e vestidos rápidos e use a IA para gerar fotos fantásticas.</p>
                </div>

                <div className="space-y-4 p-4 border border-dashed rounded-3xl border-slate-150">
                  <div className="mx-auto h-12 w-12 bg-emerald-500/10 rounded-2xl flex items-center justify-center text-emerald-600 font-black text-sm">
                    3
                  </div>
                  <h4 className="font-bold text-slate-800 text-sm">Envie o Link e fature</h4>
                  <p className="text-xs text-slate-400 leading-relaxed">Seus clientes fecham pedidos na sua sacola pública e são direcionados com os itens prontos direto no seu WhatsApp.</p>
                </div>

              </div>
            </div>
          </section>

          {/* Core Features list grids */}
          <section id="funcionalidades" className="py-16 bg-slate-50 border-b">
            <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 space-y-12">
              <div className="text-center space-y-2">
                <h2 className="text-2xl sm:text-3xl font-black text-[#0f172a] tracking-tight">O que você ganha com a VestuAI</h2>
                <p className="text-xs sm:text-sm text-slate-400">Tudo que uma operação de moda precisa para lucrar em escala.</p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                
                <div className="bg-white rounded-3xl border p-6 space-y-3 shadow-xs">
                  <Sparkles className="h-6 w-6 text-[#6366f1]" />
                  <h4 className="font-bold text-slate-800 text-xs sm:text-sm">Estúdio Fotográfico IA 4K</h4>
                  <p className="text-xs text-slate-500 leading-relaxed">Uma cabine profissional na nuvem. Insira fotos cruas em cabides e receba imagens realistas de estúdios e passarelas renomadas.</p>
                </div>

                <div className="bg-white rounded-3xl border p-6 space-y-3 shadow-xs">
                  <Lock className="h-6 w-6 text-purple-600" />
                  <h4 className="font-bold text-slate-800 text-xs sm:text-sm">Gate comercial Atacado/Varejo</h4>
                  <p className="text-xs text-slate-500 leading-relaxed">Bloqueie sua vitrine sob fardos customizados. Exija cadastro ou declaração de perfil para exibir preços comerciais ocultos de atacado.</p>
                </div>

                <div className="bg-white rounded-3xl border p-6 space-y-3 shadow-xs">
                  <Store className="h-6 w-6 text-rose-500" />
                  <h4 className="font-bold text-slate-800 text-xs sm:text-sm">25 Templates Exclusivos</h4>
                  <p className="text-xs text-slate-500 leading-relaxed">De layouts Luxe Noir a visuais minimalistas e contemporâneos de alta costura, adapte toda a marca em um só clique.</p>
                </div>

                <div className="bg-white rounded-3xl border p-6 space-y-3 shadow-xs">
                  <MessageSquare className="h-6 w-6 text-emerald-600" />
                  <h4 className="font-bold text-slate-800 text-xs sm:text-sm">Checkouts Rápidos de WhatsApp</h4>
                  <p className="text-xs text-slate-500 leading-relaxed">Livre de intermediadores ou tarifas indiretas. O pedido chega detalhado e somado direto para finalização do pagamento de forma humana.</p>
                </div>

                <div className="bg-white rounded-3xl border p-6 space-y-3 shadow-xs">
                  <BarChart className="h-6 w-6 text-[#a855f7]" />
                  <h4 className="font-bold text-slate-800 text-xs sm:text-sm">Painel de Analise Pro</h4>
                  <p className="text-xs text-slate-500 leading-relaxed">Monitore visitas exclusivas, taxas de cliques de WhatsApp e ranqueamento de peças de roupas mais acessadas da semana.</p>
                </div>

                <div className="bg-white rounded-3xl border p-6 space-y-3 shadow-xs">
                  <Heart className="h-6 w-6 text-pink-500" />
                  <h4 className="font-bold text-slate-800 text-xs sm:text-sm">Módulo Opinião & Estrelas</h4>
                  <p className="text-xs text-slate-500 leading-relaxed">Permita avaliações de sapatos e vestidos com aprovação humana programada antes de renderizar nas páginas públicas.</p>
                </div>

              </div>
            </div>
          </section>

          {/* Horizontal scroll templates previews horizontal */}
          <section className="py-16 bg-white border-b">
            <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 space-y-10">
              <div className="text-center space-y-2">
                <h3 className="text-2xl sm:text-3xl font-black text-slate-900 tracking-tight">Estilos prontos para converter</h3>
                <p className="text-xs sm:text-sm text-slate-400">Conecte cores, tipografias modernas e grades profissionais de sapatos e vestidos.</p>
              </div>

              <div className="flex space-x-4 overflow-x-auto pb-4 scrollbar-none">
                {TEMPLATES_LIST.slice(0, 10).map(tpl => (
                  <div key={tpl.id} className="w-56 p-4 rounded-2xl bg-slate-50 border shrink-0 text-center space-y-1.5 shadow-xs hover:border-[#6366f1] transition select-none flex flex-col justify-between">
                    <div>
                      <span className="text-xs font-black block text-slate-800 leading-tight">{tpl.name}</span>
                      <span className="text-[10px] text-slate-400 block truncate">{tpl.style}</span>
                    </div>
                    <span className="text-[10px] uppercase font-bold text-indigo-500 bg-indigo-50 px-2 py-0.5 rounded-full inline-block mt-2">Design Ativo</span>
                  </div>
                ))}
              </div>
            </div>
          </section>

          {/* Pricing plans Matrix */}
          <section id="precos" className="py-16 bg-[#fbfbfe] border-b">
            <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 space-y-12">
              <div className="text-center space-y-2">
                <h3 className="text-2xl sm:text-3xl font-black text-slate-900 tracking-tight">Valores Transparentes de Integração</h3>
                <p className="text-xs sm:text-sm text-slate-400">Escolha o tamanho ideal da sua vitrine comercial e expanda.</p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 items-stretch">
                
                {/* Free */}
                <div className="bg-white border rounded-3xl p-6 shadow-sm flex flex-col justify-between space-y-6">
                  <div className="space-y-4">
                    <span className="text-[10px] uppercase tracking-wider font-extrabold text-slate-400 bg-slate-100 px-2.5 py-1 rounded-full">Plano Grátis</span>
                    <h4 className="text-3xl font-black text-[#0f172a]">R$ 0</h4>
                    <p className="text-[11px] text-slate-500">Taxa p/ checkout: <span className="font-bold">7%</span></p>
                    <ul className="text-xs text-slate-500 space-y-2.5 border-t pt-4">
                      <li className="flex items-center space-x-2">
                        <Check className="h-4 w-4 text-emerald-500 shrink-0" />
                        <span>Até 30 produtos ativos</span>
                      </li>
                      <li className="flex items-center space-x-2">
                        <Check className="h-4 w-4 text-emerald-500 shrink-0" />
                        <span>5 Fotos com IA / semana</span>
                      </li>
                      <li className="flex items-center space-x-2 opacity-40">
                        <Check className="h-4 w-4 shrink-0" />
                        <span>Sem Gate comercial</span>
                      </li>
                    </ul>
                  </div>

                  <button 
                    onClick={() => handleNavigate('/cadastro')}
                    className="w-full rounded-xl bg-slate-900 leading-none py-3 text-xs font-bold text-white hover:bg-[#6366f1] cursor-pointer"
                  >
                    Começar grátis agora
                  </button>
                </div>

                {/* Pro */}
                <div className="bg-white border-[#6366f1] border-2 rounded-3xl p-6 shadow-md flex flex-col justify-between space-y-6 relative">
                  <span className="absolute -top-3.5 left-1/2 transform -translate-x-1/2 bg-[#6366f1] text-[10px] font-black uppercase text-white tracking-widest px-3 py-1.5 rounded-full shadow shrink-0 leading-none">
                    Mais Popular
                  </span>
                  <div className="space-y-4 pt-1">
                    <span className="text-[10px] uppercase tracking-wider font-extrabold text-indigo-500 bg-indigo-50 px-2.5 py-1 rounded-full">Plano Pro</span>
                    <h4 className="text-3xl font-black text-[#0f172a]">R$ 50<span className="text-xs text-slate-400 font-medium"> /mês</span></h4>
                    <p className="text-[11px] text-slate-500">Taxa p/ checkout: <span className="font-bold text-[#6366f1]">5%</span></p>
                    <ul className="text-xs text-slate-500 space-y-2.5 border-t pt-4">
                      <li className="flex items-center space-x-2">
                        <Check className="h-4 w-4 text-emerald-500 shrink-0" />
                        <span className="font-bold">Produtos Ilimitados</span>
                      </li>
                      <li className="flex items-center space-x-2">
                        <Check className="h-4 w-4 text-emerald-500 shrink-0" />
                        <span>15 Fotos com IA / semana</span>
                      </li>
                      <li className="flex items-center space-x-2">
                        <Check className="h-4 w-4 text-emerald-500 shrink-0" />
                        <span className="font-semibold text-slate-700">Configuração de Gate Blur</span>
                      </li>
                      <li className="flex items-center space-x-2">
                        <Check className="h-4 w-4 text-emerald-500 shrink-0" />
                        <span>Domínio CNAME Customizável</span>
                      </li>
                    </ul>
                  </div>

                  <button 
                    onClick={() => handleNavigate('/cadastro')}
                    className="w-full rounded-xl bg-slate-900 leading-none py-3 text-xs font-bold text-white hover:bg-[#6366f1] cursor-pointer"
                  >
                    Ativar 14 dias grátis
                  </button>
                </div>

                {/* Pro Max */}
                <div className="bg-white border rounded-3xl p-6 shadow-sm flex flex-col justify-between space-y-6">
                  <div className="space-y-4">
                    <span className="text-[10px] uppercase tracking-wider font-extrabold text-purple-600 bg-purple-50 px-2.5 py-1 rounded-full">Plano Pro Max</span>
                    <h4 className="text-3xl font-black text-[#0f172a]">R$ 100<span className="text-xs text-slate-400 font-medium"> /mês</span></h4>
                    <p className="text-[11px] text-slate-500">Taxa p/ checkout: <span className="font-bold">3%</span></p>
                    <ul className="text-xs text-slate-500 space-y-2.5 border-t pt-4">
                      <li className="flex items-center space-x-2">
                        <Check className="h-4 w-4 text-emerald-500 shrink-0" />
                        <span className="font-bold">Produtos Ilimitados</span>
                      </li>
                      <li className="flex items-center space-x-2">
                        <Check className="h-4 w-4 text-emerald-500 shrink-0" />
                        <span>30 Fotos com IA / semana</span>
                      </li>
                      <li className="flex items-center space-x-2">
                        <Check className="h-4 w-4 text-emerald-500 shrink-0" />
                        <span>Configuração de Gate Blur</span>
                      </li>
                      <li className="flex items-center space-x-2">
                        <Check className="h-4 w-4 text-emerald-500 shrink-0" />
                        <span>Domínio CNAME Customizável</span>
                      </li>
                    </ul>
                  </div>

                  <button 
                    onClick={() => handleNavigate('/cadastro')}
                    className="w-full rounded-xl bg-slate-900 leading-none py-3 text-xs font-bold text-white hover:bg-[#6366f1] cursor-pointer"
                  >
                    Ativar 14 dias grátis
                  </button>
                </div>

                {/* Ultra */}
                <div className="bg-slate-900 text-slate-300 border rounded-3xl p-6 shadow-md flex flex-col justify-between space-y-6">
                  <div className="space-y-4">
                    <span className="text-[10px] uppercase tracking-wider font-extrabold text-pink-400 bg-pink-500/10 px-2.5 py-1 rounded-full">Plano Ultra</span>
                    <h4 className="text-3xl font-black text-white">R$ 350<span className="text-xs text-slate-400 font-medium"> /mês</span></h4>
                    <p className="text-[11px] text-slate-400">Taxa p/ checkout: <span className="font-bold text-emerald-400">Apenas 1%</span></p>
                    <ul className="text-xs text-slate-400 space-y-2.5 border-t border-slate-800 pt-4">
                      <li className="flex items-center space-x-2">
                        <Check className="h-4 w-4 text-emerald-450 shrink-0" />
                        <span className="font-bold text-white">Produtos Ilimitados</span>
                      </li>
                      <li className="flex items-center space-x-2">
                        <Check className="h-4 w-4 text-emerald-450 shrink-0" />
                        <span className="font-bold text-white">50 Fotos com IA / semana</span>
                      </li>
                      <li className="flex items-center space-x-2">
                        <Check className="h-4 w-4 text-emerald-450 shrink-0" />
                        <span className="font-semibold text-pink-400">Desfile de Vídeos IA (Veo 3.1)</span>
                      </li>
                      <li className="flex items-center space-x-2">
                        <Check className="h-4 w-4 text-emerald-450 shrink-0" />
                        <span>Fardo Mestre e Suporte prioritário</span>
                      </li>
                    </ul>
                  </div>

                  <button 
                    onClick={() => handleNavigate('/cadastro')}
                    className="w-full rounded-xl bg-gradient-to-tr from-pink-500 to-purple-600 leading-none py-3 text-xs font-black text-white hover:opacity-90 cursor-pointer"
                  >
                    Ativar 14 dias grátis
                  </button>
                </div>

              </div>

            </div>
          </section>

          {/* Testimonials section */}
          <section className="py-16 bg-white border-b">
            <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 space-y-12">
              <div className="text-center space-y-2">
                <h3 className="text-2xl sm:text-3xl font-black text-slate-900 tracking-tight">Depoimentos de Sucesso</h3>
                <p className="text-xs sm:text-sm text-slate-400">Histórias reais de quem elevou faturamentos no e-commerce.</p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                
                <div className="rounded-3xl border bg-slate-50 p-6 space-y-4">
                  <div className="text-amber-400 flex items-center space-x-1">
                    {Array.from({ length: 5 }).map((_, i) => <span key={i} className="text-amber-400 text-sm">★</span>)}
                  </div>
                  <p className="text-xs text-slate-500 leading-relaxed italic">"Gerei os editoriais de fotos dos meus vestidos de crochê em um piscar de olhos e mudei pro plano Pro para conectar meu domínio. Muito simples de programar."</p>
                  <div>
                    <h5 className="font-bold text-slate-800 text-xs">Clara Vasconcelos</h5>
                    <span className="text-[10px] text-[#6366f1]">Dona da Crochê Chic</span>
                  </div>
                </div>

                <div className="rounded-3xl border bg-slate-50 p-6 space-y-4">
                  <div className="text-amber-400 flex items-center space-x-1">
                    {Array.from({ length: 5 }).map((_, i) => <span key={i} className="text-amber-400 text-sm">★</span>)}
                  </div>
                  <p className="text-xs text-slate-500 leading-relaxed italic">"O bloqueio do gate de atacado é simplesmente sensacional. Meus revendedores agora compram lotes no atacado com fardo mínimo direto com faturamento formatado no WhatsApp."</p>
                  <div>
                    <h5 className="font-bold text-slate-800 text-xs">Rodrigo Mendonça</h5>
                    <span className="text-[10px] text-[#6366f1]">Sócio da Denim Urban Co</span>
                  </div>
                </div>

                <div className="rounded-3xl border bg-slate-50 p-6 space-y-4">
                  <div className="text-amber-400 flex items-center space-x-1">
                    {Array.from({ length: 5 }).map((_, i) => <span key={i} className="text-amber-400 text-sm">★</span>)}
                  </div>
                  <p className="text-xs text-slate-500 leading-relaxed italic">"Diferencial indispensável do Estúdio IA. Nossas criações de sapatos e sapatilhas têm iluminação de agência internacional que impressionou toda a concorrência."</p>
                  <div>
                    <h5 className="font-bold text-slate-800 text-xs">Bruna Albuquerque</h5>
                    <span className="text-[10px] text-[#6366f1]">Fundadora da Brilha Couros</span>
                  </div>
                </div>

              </div>
            </div>
          </section>

          {/* Accordion FAQ sector lists */}
          <section id="faq" className="py-16 bg-[#fbfbfe] border-b">
            <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8 space-y-10">
              <div className="text-center space-y-2">
                <h3 className="text-2xl sm:text-3xl font-black text-slate-900 tracking-tight">Perguntas Frequentes</h3>
                <p className="text-xs sm:text-sm text-slate-400">Tire todas as suas dúvidas operacionais de faturamento de fardo.</p>
              </div>

              <div className="space-y-3.5">
                {faqs.map((faq, index) => (
                  <div key={index} className="rounded-2xl border bg-white p-4 font-sans select-none shadow-xs">
                    <div 
                      onClick={() => setOpenFaqId(openFaqId === index ? null : index)}
                      className="flex items-center justify-between cursor-pointer text-slate-800 font-bold text-sm"
                    >
                      <span>{faq.q}</span>
                      <ChevronDown className={`h-4.5 w-4.5 text-slate-400 transition-transform duration-300 ${openFaqId === index ? 'rotate-180' : ''}`} />
                    </div>
                    {openFaqId === index && (
                      <p className="text-xs text-slate-500 mt-3 pt-3 border-t leading-relaxed">{faq.a}</p>
                    )}
                  </div>
                ))}
              </div>
            </div>
          </section>

          <Footer />
        </div>
      )}

      {/* Sign in credentials block */}
      {route === '/entrar' && (
        <div className="flex-1 flex items-center justify-center bg-slate-50 px-4 py-16">
          <div className="w-full max-w-md bg-white border rounded-3xl p-6 sm:p-8 space-y-6 shadow-xl relative">
            
            <button 
              onClick={() => handleNavigate('/')}
              className="absolute top-4 left-4 p-1.5 rounded-full hover:bg-slate-100 text-slate-400 flex items-center space-x-1 text-xs cursor-pointer select-none"
            >
              <ArrowLeft className="h-4 w-4" />
              <span>Início</span>
            </button>

            <div className="flex flex-col items-center text-center space-y-3">
              <div className="p-3.5 bg-[#a855f7]/5 rounded-2xl border border-[#a855f7]/10">
                <VestuAiSymbol size={48} variant="light" />
              </div>
              <div className="space-y-1">
                <h2 className="text-xl sm:text-2xl font-black text-[#0f172a] tracking-tight">Acesso ao Painel Lojista</h2>
                <p className="text-xs text-slate-400">Insira suas credenciais cadastradas abaixo.</p>
              </div>
            </div>

            {authError && (
              <div className="p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-600 text-xs font-bold leading-normal">
                {authError}
              </div>
            )}

            <form onSubmit={executeLogin} className="space-y-4 font-sans text-xs">
              <div className="space-y-1">
                <label className="font-bold text-slate-500">Seu E-mail Corporativo</label>
                <input 
                  type="email" 
                  value={authEmail}
                  onChange={(e) => setAuthEmail(e.target.value)}
                  placeholder="Ex: demo@vestuai.com.br"
                  required
                  className="w-full rounded-xl border bg-slate-50 px-4 py-3 placeholder-slate-400 text-slate-800 outline-none"
                />
              </div>

              <div className="space-y-1">
                <label className="font-bold text-slate-500">Sua Senha de Acesso</label>
                <input 
                  type="password" 
                  value={authPassword}
                  onChange={(e) => setAuthPassword(e.target.value)}
                  placeholder="Mínimo 4 dígitos"
                  required
                  className="w-full rounded-xl border bg-slate-50 px-4 py-3 text-slate-800 outline-none"
                />
              </div>

              <button 
                type="submit" 
                className="w-full rounded-xl bg-slate-900 py-3.5 text-xs font-bold text-white hover:bg-[#6366f1] transition shadow cursor-pointer text-center leading-none"
              >
                Acessar Workspace
              </button>
            </form>

            <div className="p-4 rounded-2xl bg-indigo-50/50 border text-slate-500 text-[10px] leading-relaxed space-y-1 text-center font-mono">
              <p className="font-bold text-slate-800">Contas Demonstrativas Ativas:</p>
              <p>• Lojista: <span className="font-semibold text-slate-700">demo@vestuai.com.br</span> (Senha: <span className="font-semibold">demo123</span>)</p>
              <p>• Admin: <span className="font-semibold text-slate-700">admin@vestuai.com.br</span> (Senha: <span className="font-semibold">admin123</span>)</p>
            </div>

            <p className="text-center text-xs text-slate-400">
              Ainda não possui conta?{' '}
              <button 
                onClick={() => handleNavigate('/cadastro')}
                className="text-[#6366f1] font-bold hover:underline cursor-pointer"
              >
                Criar conta grátis
              </button>
            </p>
          </div>
        </div>
      )}

      {/* Registrations dynamic screens */}
      {route === '/cadastro' && (
        <div className="flex-1 flex items-center justify-center bg-slate-50 px-4 py-16">
          <div className="w-full max-w-md bg-white border rounded-3xl p-6 sm:p-8 space-y-6 shadow-xl relative">
            
            <button 
              onClick={() => handleNavigate('/')}
              className="absolute top-4 left-4 p-1.5 rounded-full hover:bg-slate-100 text-slate-400 flex items-center space-x-1 text-xs cursor-pointer select-none"
            >
              <ArrowLeft className="h-4 w-4" />
              <span>Início</span>
            </button>

            <div className="flex flex-col items-center text-center space-y-3">
              <div className="p-3.5 bg-[#a855f7]/5 rounded-2xl border border-[#a855f7]/10">
                <VestuAiSymbol size={48} variant="light" />
              </div>
              <div className="space-y-2">
                <span className="bg-[#6366f1]/10 text-[#6366f1] font-black text-[9px] uppercase tracking-widest px-3 py-1 rounded-full leading-none">
                  14 dias Pro grátis garantido
                </span>
                <h2 className="text-xl sm:text-2xl font-black text-[#0f172a] tracking-tight">Criar Conta Comercial</h2>
                <p className="text-xs text-slate-400">Abra sua loja de moda e fature sem intermediadores.</p>
              </div>
            </div>

            {authError && (
              <div className="p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-600 text-xs font-bold leading-normal">
                {authError}
              </div>
            )}

            <form onSubmit={executeRegister} className="space-y-4 font-sans text-xs">
              
              <div className="space-y-1">
                <label className="font-bold text-slate-500">Seu Nome Completo</label>
                <input 
                  type="text" 
                  value={authName}
                  onChange={(e) => setAuthName(e.target.value)}
                  placeholder="Ex: Amanda Oliveira"
                  required
                  className="w-full rounded-xl border bg-slate-50 px-4 py-3 placeholder-slate-400 text-slate-800 outline-none"
                />
              </div>

              <div className="space-y-1">
                <label className="font-bold text-slate-500">E-mail Corporativo de Negócio</label>
                <input 
                  type="email" 
                  value={authEmail}
                  onChange={(e) => setAuthEmail(e.target.value)}
                  placeholder="Ex: contato@sualoja.com.br"
                  required
                  className="w-full rounded-xl border bg-slate-50 px-4 py-3 placeholder-slate-400 text-slate-800 outline-none"
                />
              </div>

              <div className="space-y-1">
                <label className="font-bold text-slate-500">Sua Senha de Acesso (Dígitos)</label>
                <input 
                  type="password" 
                  value={authPassword}
                  onChange={(e) => setAuthPassword(e.target.value)}
                  placeholder="Cadastre mais de 4 caracteres"
                  required
                  className="w-full rounded-xl border bg-slate-50 px-4 py-3 text-slate-800 outline-none"
                />
              </div>

              <div className="space-y-1">
                <label className="font-bold text-slate-500">WhatsApp de Atendimento (Com DDD)</label>
                <input 
                  type="text" 
                  value={authPhone}
                  onChange={(e) => setAuthPhone(e.target.value)}
                  placeholder="Ex: 5511999998888"
                  required
                  className="w-full rounded-xl border bg-slate-50 px-4 py-3 text-slate-800 outline-none"
                />
              </div>

              <button 
                type="submit" 
                className="w-full rounded-xl bg-slate-900 py-3.5 text-xs font-bold text-white hover:bg-[#6366f1] transition shadow cursor-pointer text-center leading-none"
              >
                Cadastrar e Continuar
              </button>
            </form>

            <p className="text-center text-xs text-slate-400">
              Já possui registro ativo?{' '}
              <button 
                onClick={() => handleNavigate('/entrar')}
                className="text-[#6366f1] font-bold hover:underline cursor-pointer"
              >
                Logar-se
              </button>
            </p>
          </div>
        </div>
      )}

      {/* Onboarding steps layout display */}
      {route === '/onboarding' && (
        <div className="flex-1 flex items-center justify-center bg-slate-100 px-4 py-16">
          <div className="w-full max-w-md bg-white border rounded-3xl p-6 sm:p-8 space-y-6 shadow-2xl">
            
            <div className="text-center space-y-2">
              <span className="text-[10px] font-mono tracking-widest font-black uppercase text-indigo-500">
                PROCESSO DE CONFIGURAÇÃO • PASSO {onbStep} DE 3
              </span>
              <h2 className="text-xl sm:text-2xl font-black text-slate-900 leading-tight">Configurando seu Espaço Comercial</h2>
            </div>

            {onbStep === 1 && (
              <div className="space-y-4">
                <div className="space-y-1 text-xs">
                  <label className="font-bold text-slate-600">Qual o Nome Comercial Desejado da sua Vitrine?</label>
                  <input 
                    type="text" 
                    value={onbStoreName}
                    onChange={(e) => setOnbStoreName(e.target.value)}
                    placeholder="Ex: Vibe Chic Vestuários"
                    className="w-full rounded-xl border bg-slate-50 px-4 py-3 text-slate-850 outline-none leading-none"
                  />
                  {onbStoreName && (
                    <div className="text-[10px] text-slate-500 font-mono">
                      Seu endereço provisório: <span className="text-[#6366f1] font-bold">{onbStoreName.toLowerCase().replace(/[^a-z0-9]/g, '-') || 'loja-nova'}.vestuai.com.br</span>
                    </div>
                  )}
                </div>

                <button 
                  onClick={() => {
                    if (!onbStoreName) return alert("Favor fornecer um nome comercial.");
                    setOnbStep(2);
                  }}
                  className="w-full rounded-xl bg-slate-950 py-3.5 text-xs text-white font-bold leading-none cursor-pointer hover:bg-[#6366f1]"
                >
                  Ir para próximo passo
                </button>
              </div>
            )}

            {onbStep === 2 && (
              <div className="space-y-4">
                <div className="space-y-1 text-xs">
                  <label className="font-bold text-slate-600">Qual o nicho de vestuários prioritários comercializados?</label>
                  <select 
                    value={onbNiche}
                    onChange={(e) => setOnbNiche(e.target.value)}
                    className="w-full rounded-xl border bg-slate-50 px-3 py-2.5 outline-none font-bold"
                  >
                    <option value="Roupas Femininas">Linha de Vestidos & Roupas Femininas</option>
                    <option value="Roupas Masculinas">Camisas & Moda Masculina</option>
                    <option value="Moda Infantil">Infantil e Juvenil</option>
                    <option value="Calçados">Calçados & Sapatilhas</option>
                    <option value="Acessórios">Bolsas & Acessórios Premium</option>
                  </select>
                </div>

                <div className="flex space-x-2">
                  <button 
                    onClick={() => setOnbStep(1)}
                    className="rounded-xl bg-slate-100 px-4 py-3.5 text-xs text-slate-600 font-bold leading-none cursor-pointer"
                  >
                    Voltar
                  </button>
                  <button 
                    onClick={() => setOnbStep(3)}
                    className="flex-1 rounded-xl bg-slate-950 py-3.5 text-xs text-white font-bold leading-none cursor-pointer hover:bg-[#6366f1]"
                  >
                    Próximo passo
                  </button>
                </div>
              </div>
            )}

            {onbStep === 3 && (
              <div className="space-y-4">
                <div className="space-y-1 text-xs">
                  <label className="font-bold text-slate-600">WhatsApp oficial de recebimento dos faturamentos:</label>
                  <input 
                    type="text" 
                    value={onbPhone}
                    onChange={(e) => setOnbPhone(e.target.value)}
                    placeholder="Ex: 5511999992222"
                    className="w-full rounded-xl border bg-slate-50 px-4 py-3 outline-none"
                  />
                  <p className="text-[9px] text-slate-400 leading-snug">Insira no formato internacional com o código do país do WhatsApp sem hifens ou símbolos.</p>
                </div>

                <div className="flex space-x-2">
                  <button 
                    onClick={() => setOnbStep(2)}
                    className="rounded-xl bg-slate-100 px-4 py-3.5 text-xs text-slate-600 font-bold leading-none cursor-pointer"
                  >
                    Voltar
                  </button>
                  <button 
                    onClick={executeOnboarding}
                    className="flex-1 rounded-xl bg-gradient-to-tr from-[#6366f1] to-[#a855f7] py-3.5 text-xs text-white font-bold leading-none cursor-pointer shadow"
                  >
                    Ativar Vitrine e Ir ao Dashboard
                  </button>
                </div>
              </div>
            )}

          </div>
        </div>
      )}

    </div>
  );
}
