export type UserRole = 'superadmin' | 'lojista' | 'cliente';

export interface User {
  id: string;
  email: string;
  passwordHash?: string; // and plain passwords for simple mock auth
  role: UserRole;
  name: string;
  phone: string | null;
  createdAt: string;
  updatedAt: string;
  emailVerified: string | null;
  tourCompleted: boolean;
}

export type StoreStatus = 'active' | 'inactive' | 'suspended';

export interface Store {
  id: string;
  slug: string;
  name: string;
  ownerName: string;
  ownerId: string;
  email: string;
  phone: string; // WhatsApp: e.g. 5511999999999
  physicalAddress: string | null;
  logoUrl: string | null;
  bannerUrl: string | null;
  templateId: string; // one of 25 templates
  primaryColor: string;
  accentColor: string;
  fontFamily: string;
  status: StoreStatus;
  isPublic: boolean;
  planId: 'free' | 'pro' | 'pro_max' | 'ultra';
  planExpiresAt: string | null;
  trialEndsAt: string | null;
  customDomain: string | null;
  gateEnabled: boolean;
  gateTitle: string;
  gateSubtitle: string;
  gateRetailLabel: string;
  gateRetailDescription: string;
  gateWholesaleLabel: string;
  gateWholesaleDescription: string;
  gateWholesaleRequiresLogin: boolean;
  gateSessionDuration: 'session' | '24h' | '7d' | 'forever';
  aiImagesUsedThisWeek: number;
  aiVideosUsedThisWeek: number;
  aiUsageResetAt: string;
  totalRevenue: number;
  totalOrders: number;
  createdAt: string;
}

export type ProductStatus = 'active' | 'draft' | 'archived';

export interface Product {
  id: string;
  storeId: string;
  name: string;
  description: string;
  photos: string[]; // up to 5 URLs
  price: number; // retail price
  salePrice: number | null;
  wholesalePrice: number | null;
  wholesaleMinQty: number | null;
  costPrice?: number | null; // never returned to public storefront
  stock: number;
  category: string;
  tags: string[];
  isFeatured: boolean;
  isPromotion: boolean;
  collectionId: string | null;
  status: ProductStatus;
  createdAt: string;
  updatedAt: string;
}

export interface Collection {
  id: string;
  storeId: string;
  name: string;
  description: string | null;
  coverImageUrl: string | null;
  productIds: string[];
  createdAt: string;
}

export interface AiUsageLog {
  id: string;
  storeId: string;
  userId: string;
  type: 'image' | 'video' | 'text';
  prompt: string;
  resultUrl: string | null;
  success: boolean;
  creditsUsed: number;
  createdAt: string;
  note?: string;
}

export interface OrderItem {
  productId: string;
  productName: string;
  quantity: number;
  price: number;
  photoUrl?: string;
}

export interface Order {
  id: string;
  storeId: string;
  customerName: string | null;
  customerPhone: string | null;
  items: OrderItem[];
  totalAmount: number;
  platformFee: number;
  status: 'pending' | 'completed' | 'cancelled';
  whatsappRedirectedAt: string | null;
  createdAt: string;
}

export interface Review {
  id: string;
  storeId: string;
  productId: string | null;
  customerName: string;
  rating: number; // 1-5
  comment: string | null;
  isApproved: boolean;
  createdAt: string;
}

export interface SubscriptionPlan {
  id: string;
  name: string;
  priceBrl: number;
  transactionFeePercent: number;
  aiImagesPerWeek: number;
  aiVideosPerWeek: number;
  productsLimit: number | 'unlimited';
  templatesAccess: string;
  virtualCatalog: boolean;
  gateModal: boolean;
  customDomain: boolean;
  analytics: 'basic' | 'advanced' | 'advanced_plus';
  trialDays: number;
  badge?: string;
}
